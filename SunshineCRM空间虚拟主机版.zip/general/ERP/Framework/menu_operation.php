
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" type="text/css" href="../theme/3/images/style.css">
<title>�˵�ѡ��</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>

<script>


// <!--��������Ҽ���ʼ-->
if (window.Event)
  document.captureEvents(Event.MOUSEUP);

function nocontextmenu()
{
 event.cancelBubble = true
 event.returnValue = false;

 return false;
}

function norightclick(e)
{
 if (window.Event)
 {
  if (e.which == 2 || e.which == 3)
   return false;
 }
 else
  if (event.button == 2 || event.button == 3)
  {
   event.cancelBubble = true
   event.returnValue = false;
   return false;
  }

}
document.oncontextmenu = nocontextmenu;  // for IE5+     
document.onmousedown = norightclick;     // for all others    
// <!--��������Ҽ�����-->

</script>

</head>

<body topmargin="0" leftmargin="0" onselectstart="return false" onload="parent.init_menu()" style="background:#000 url(../theme/3/images/side-bottom-bg.gif) repeat-x;">
<!-- 
<table id="03" width="170" height="107" border="0" cellpadding="0" cellspacing="0"  background="../theme/3/images/panel_bottom.jpg">
<tr><td align="center" valign="middle" >
	
	<TABLE class="small" cellspacing="1" border="0" cellpadding="0">
          <TR valign="middle">
            <TD width="60" height="28" background="../theme/3/images/button_bg.gif" align="center" id="menu_1" style="cursor:pointer" title="���˵�"   onclick="parent.view_menu(1)" onmouseover="parent.setPointer(this,1,1)" onmouseout="parent.setPointer(this,2,1)" ><span class="button_text">���ܲ˵�</span></TD>
            <TD width="60" height="28" background="../theme/3/images/button_bg.gif" align="center" id="menu_2" style="cursor:pointer" title="������Ա" onclick="parent.view_menu(2)" onmouseover="parent.setPointer(this,1,2)" onmouseout="parent.setPointer(this,2,2)" ><span class="button_text">������Ա</span></TD>
            <TD width="60" height="28" background="../theme/3/images/button_bg.gif" align="center" id="menu_3" style="cursor:pointer" title="ȫ����Ա" onclick="parent.view_menu(3)" onmouseover="parent.setPointer(this,1,3)" onmouseout="parent.setPointer(this,2,3)" ><span class="button_text">ȫ����Ա</span></TD>
          </TR>
        
	<TR valign="middle">
            <TD width="60" height="28" background="../theme/3/images/button_bg.gif" align="center" id="menu_4" style="cursor:pointer" title="������" onclick="parent.view_menu(4)" onmouseover="parent.setPointer(this,1,4)" onmouseout="parent.setPointer(this,2,4)" ><span class="button_text">������</span></TD>
            <TD width="60" height="28" background="../theme/3/images/button_bg.gif" align="center" id="menu_5" style="cursor:pointer" title="�ڲ��ʼ�"   onclick="parent.view_menu(5)" onmouseover="parent.setPointer(this,1,5)" onmouseout="parent.setPointer(this,2,5)" ><span class="button_text">�ڲ��ʼ�</span></TD>
            <TD width="60" height="28" background="../theme/3/images/button_bg.gif" align="center" id="menu_6" style="cursor:pointer" title="����֪ͨ"   onclick="parent.view_menu(6)" onmouseover="parent.setPointer(this,1,6)" onmouseout="parent.setPointer(this,2,6)" ><span class="button_text">����֪ͨ</span></TD>
	</TR>
          
	  </TABLE>
	  
</td></tr>
</table>
-->

</body>
</html>
