<?php
require_once('../include.inc.php');
page_css('hrms');
$lang=returnsystemlang();
$html_etc=returnsystemlang('hrms');
$common_html=returnsystemlang('common_html');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE></TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312"><LINK 
href="./style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>
<BODY class=bodycolor topMargin=5>
<DIV align=right>
<INPUT class=SamllButton onclick=parent.close(); type=button value='<?php echo $common_html['common_html']['close']?>'
</DIV></BODY></HTML>
