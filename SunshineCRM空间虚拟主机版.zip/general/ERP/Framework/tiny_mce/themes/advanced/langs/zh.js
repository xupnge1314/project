tinyMCE.addI18n('zh.advanced',{

style_select:"\u6837\u5F0F",

font_size:"\u5B57\u4F53\u5927\u5C0F",

fontdefault:"\u5B57\u4F53",

block:"\u683C\u5F0F",

paragraph:"\u6BB5\u843D",

div:"Div",

address:"\u5730\u5740",

pre:"\u9ED8\u8BA4\u683C\u5F0F",

h1:"\u6807\u9898 1",

h2:"\u6807\u9898 2",

h3:"\u6807\u9898 3",

h4:"\u6807\u9898 4",

h5:"\u6807\u9898 5",

h6:"\u6807\u9898 6",

blockquote:"\u5F15\u7528",

code:"\u4EE3\u7801",

samp:"\u7A0B\u5E8F\u8303\u4F8B",

dt:"\u540D\u8BCD\u5B9A\u4E49",

dd:"\u540D\u8BCD\u89E3\u91CA",

bold_desc:"\u7C97\u4F53 (Ctrl+B)",

italic_desc:"\u659C\u4F53 (Ctrl+I)",

underline_desc:"\u5E95\u7EBF (Ctrl+U)",

striketrough_desc:"\u4E2D\u5212\u7EBF",

justifyleft_desc:"\u5DE6\u5BF9\u9F50",

justifycenter_desc:"\u5C45\u4E2D",

justifyright_desc:"\u53F3\u5BF9\u9F50",

justifyfull_desc:"\u4E24\u7AEF\u5BF9\u9F50",

bullist_desc:"\u6E05\u5355\u7B26\u53F7",

numlist_desc:"\u7F16\u53F7",

outdent_desc:"\u51CF\u5C11\u7F29\u8FDB",

indent_desc:"\u589E\u52A0\u7F29\u8FDB",

undo_desc:"\u64A4\u9500 (Ctrl+Z)",

redo_desc:"\u6062\u590D (Ctrl+Y)",

link_desc:"\u63D2\u5165/\u7F16\u8F91 \u94FE\u63A5",

unlink_desc:"\u53D6\u6D88\u94FE\u63A5",

image_desc:"\u63D2\u5165/\u7F16\u8F91 \u56FE\u7247",

cleanup_desc:"\u5220\u9664\u5197\u4F59\u7801",

code_desc:"\u7F16\u8F91 HTML \u539F\u59CB\u7A0B\u5E8F\u4EE3\u7801",

sub_desc:"\u4E0B\u6807",

sup_desc:"\u4E0A\u6807",

hr_desc:"\u63D2\u5165\u6C34\u5E73\u7EBF",

removeformat_desc:"\u6E05\u9664\u6837\u5F0F",

custom1_desc:"\u5728\u6B64\u8F93\u5165\u60A8\u7684\u81EA\u8BA2\u63CF\u8FF0",

forecolor_desc:"\u9009\u62E9\u6587\u5B57\u989C\u8272",

backcolor_desc:"\u9009\u62E9\u80CC\u666F\u989C\u8272",

charmap_desc:"\u63D2\u5165\u7279\u6B8A\u7B26\u53F7",

visualaid_desc:"\u7F51\u683C/\u9690\u85CF\u7EC4\u4EF6\uFF1F",

anchor_desc:"\u63D2\u5165/\u7F16\u8F91 \u951A\u70B9",

cut_desc:"\u526A\u5207 (Ctrl+X)",

copy_desc:"\u590D\u5236 (Ctrl+C)",

paste_desc:"\u7C98\u8D34 (Ctrl+V)",

image_props_desc:"\u56FE\u7247\u5C5E\u6027",

newdocument_desc:"\u65B0\u5EFA\u6587\u4EF6",

help_desc:"\u5E2E\u52A9",

blockquote_desc:"\u5F15\u7528",

clipboard_msg:"\u590D\u5236\u3001\u526A\u5207\u548C\u7C98\u8D34\u529F\u80FD\u5728Mozilla \u548C Firefox\u4E2D\u65E0\u6CD5\u4F7F\u7528",

path:"\u8DEF\u5F84",

newdocument:"\u60A8\u786E\u8BA4\u8981\u5220\u9664\u5168\u90E8\u5185\u5BB9\u5417\uFF1F",

toolbar_focus:"\u5DE5\u5177\u5217 - Alt+Q, \u7F16\u8F91\u5668 - Alt-Z, \u7EC4\u4EF6\u8DEF\u5F84 - Alt-X",

more_colors:"\u66F4\u591A\u989C\u8272"

});