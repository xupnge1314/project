<link rel="stylesheet" type="text/css" href="inc/xtree.css">
  <div id="xtree" class="xtree" XmlSrc="inc_user_tree.php?MANAGE_FLAG=&DEPT_ID=0&PARA_URL1=1&PARA_URL2=user_newai.php&e=&PARA_TARGET=main&PRIV_NO_FLAG=0&PARA_ID=&PARA_VALUE=">
  </div>
<br>
