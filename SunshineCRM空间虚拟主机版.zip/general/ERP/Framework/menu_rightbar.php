<html>
<head>
<title>�˵��ұ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>
<body bgcolor="#FFFFFF">
<table id="__01" width="6" height="100%" border="0" cellpadding="0" cellspacing="0">
	<tr><td height="100" width="6" background="../theme/3/images/rightbar-top.gif">&nbsp;</td></tr>
	<tr><td background="../theme/3/images/rightbar-bg.gif">&nbsp;</td></tr>
	<tr><td height="8" background="../theme/3/images/rightbar-bottom.gif"></td></tr>
</table>
</body>
</html>

