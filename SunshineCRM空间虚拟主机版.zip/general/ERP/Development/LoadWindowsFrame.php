<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Frameset//EN">
<!-- saved from url=(0036)http://localhost/module/user_select/ -->
<HTML><HEAD><TITLE></TITLE>
<META http-equiv=Content-Type content="text/html; charset=gb2312"><LINK
href="./images/style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2800.1106" name=GENERATOR></HEAD>
<FRAMESET id=bottom1 border=1 frameSpacing=0 frameBorder=YES cols=*>

<FRAME name=framework src="LoadWindows.php?action=Detail&sectionName=<?php echo $_GET['sectionName']?>&parentName=<?php echo $_GET['parentName']?>&SYSTEM_MODE=<?php echo $_GET['SYSTEM_MODE']?>" frameBorder=auto scrolling=auto cols="*" rows="*">

</FRAMESET>