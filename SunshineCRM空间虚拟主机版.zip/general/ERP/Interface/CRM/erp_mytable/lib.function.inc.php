<?php
require_once("../../EDU/lib.function.inc.php");
?>