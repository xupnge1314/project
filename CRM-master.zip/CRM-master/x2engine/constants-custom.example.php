<?php

// Enable FTP File operations by setting the following constants accordingly:
defined('X2_FTP_FILEOPER') or define('X2_FTP_FILEOPER', false);
defined('X2_FTP_HOST') or define('X2_FTP_HOST', 'localhost');
defined('X2_FTP_USER') or define('X2_FTP_USER', 'root');
defined('X2_FTP_PASS') or define('X2_FTP_PASS', '');
defined('X2_FTP_CHROOT_DIR') or define('X2_FTP_CHROOT_DIR', false);
// Set to true to enable updating to beta versions
defined('X2_UPDATE_BETA') or define('X2_UPDATE_BETA',false);

?>