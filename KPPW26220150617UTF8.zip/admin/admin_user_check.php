<?php	defined ( 'ADMIN_KEKE' ) or exit ( 'Access Denied' );
require $template_obj->template(ADMIN_DIRECTORY.'/tpl/admin_user_check' );die;
