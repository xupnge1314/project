<?php
define('KEKE_VERSION', '2.6.2');
define('KEKE_RELEASE', '2015-6-17');
define("P_NAME",'KPPW');
define("KEKE_LASTTIME",'2015-6-17');
define('KEKE_ANDROID_VERSION', '1.0');
define('KEKE_IPHONE_VERSION', '1.0');