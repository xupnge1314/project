<?php
//eval(analytic($str));