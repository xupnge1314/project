<?php $compressed = gzcompress('Compress me', 9);
echo $compressed;
?>
