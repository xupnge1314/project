<?php defined ( 'IN_KEKE' ) or exit('Access Denied');
header ( "location:index.php?do=user&view=message&op=feed" );