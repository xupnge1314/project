<?php	defined ( 'IN_KEKE' ) or exit('Access Denied');
$strPageTitle=$_lang['brower_up'].' - '.$_K['html_title'];
require  $kekezu->_tpl_obj->template($do);
