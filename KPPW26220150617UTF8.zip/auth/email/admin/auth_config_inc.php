<?php
$auth_config=array(
  'auth_code'=>'email',
  'auth_title' =>$_lang['email_auth'],
  'auth_cash' =>'1-2',
  'auth_day' =>'1-2',
  'auth_dir'=>'email',
  'auth_expir' =>'0',
  'auth_small_ico' =>'',
  'auth_big_ico' =>'',
  'auth_desc' =>$_lang['email_auth_desc'],
  'auth_show' =>'0',
  'auth_open' =>'1',
  'update_time' =>'1306142382');
?>