<?php
$auth_config=array(  
  'auth_code'=>'realname',
  'auth_title' =>$_lang['realname_auth'],
  'auth_cash' =>'0',
  'auth_day' => '1-3',
  'auth_expir' =>'0',
  'auth_dir'=>'realname',
  'auth_small_ico' =>'',
  'auth_small_n_ico' =>'',	
  'auth_big_ico' =>'',
  'auth_desc' => $_lang['id_card_auth'],
  'auth_show' =>'0',
  'auth_open' => '1',
  'update_time' =>'1306225128');
?>