ALTER TABLE  `zt_effort` ADD  `consumed` FLOAT NOT NULL AFTER  `date`;
