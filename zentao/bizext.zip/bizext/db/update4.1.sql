INSERT INTO `zt_grouppriv` (`group`, `module`, `method`) VALUES
(1, 'datatable', 'custom'),
(2, 'datatable', 'custom'),
(3, 'datatable', 'custom'),
(4, 'datatable', 'custom'),
(5, 'datatable', 'custom'),
(6, 'datatable', 'custom'),
(7, 'datatable', 'custom'),
(8, 'datatable', 'custom'),
(9, 'datatable', 'custom'),
(10, 'datatable', 'custom');
