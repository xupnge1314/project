ALTER TABLE `zt_relationOfTasks` DROP `company`;
ALTER TABLE `zt_repo` DROP `company`;
ALTER TABLE `zt_repoComment` DROP `company`;
