<?php
$lang->dev->tableList['datatable'] = 'Data table';
