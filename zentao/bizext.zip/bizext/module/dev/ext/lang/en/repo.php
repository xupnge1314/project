<?php
$lang->dev->tableList['repo']        = 'Repo';
$lang->dev->tableList['repohistory'] = 'Repo history';
$lang->dev->tableList['repofiles']   = 'Repo files';

$lang->dev->groupList['repo'] = 'Repo';
