<?php
$lang->dev->tableList['datatable'] = '数据表格';
