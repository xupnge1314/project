<?php
$config->dev->group['repo']        = 'repo';
$config->dev->group['repofiles']   = 'repo';
$config->dev->group['repohistory'] = 'repo';
