<?php
$lang->datatable = new stdclass();
$lang->datatable->common = '数据表格';
$lang->datatable->width  = '宽度';
$lang->datatable->show   = '显示';
$lang->datatable->hide   = '隐藏';

$lang->datatable->custom            = '自定义列';
$lang->datatable->customTip         = '勾选需要显示的列';
$lang->datatable->switchToTable     = '切换到简单表格';
$lang->datatable->switchToDatatable = '切换到高级表格';
$lang->datatable->required          = '必选';
