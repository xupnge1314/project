<?php
$lang->datatable = new stdclass();
$lang->datatable->common = 'Data table';
$lang->datatable->width  = 'Width';
$lang->datatable->show   = 'Show';
$lang->datatable->hide   = 'Hide';

$lang->datatable->custom            = 'Custom columns';
$lang->datatable->customTip         = 'Check columns to display';
$lang->datatable->switchToTable     = 'Switch to table';
$lang->datatable->switchToDatatable = 'Switch to datatable';
$lang->datatable->required          = 'Required';
