<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPstedfs5UsFIw2SBlWkXj3Ql6xg2fuW2/JPOuzE13afBWjqMseG3EwzmHFTb5e0FsH9lpWH6
ZlNWkyUmx8VGeveZD8HGCMlnoMvOp+kRoUF0BD/hyNJYvldz2r8HfGXt7GyfTMbKOa9vr8fockf7
Z7irvHcGdanKdK+baUPnLVyPWrQoIVnboYAqBQw71AC+Pwvs8M8l6kxxLgUyTvnv7MhPHezhNwUY
XD3e8YlOa9l5/QFTfLJT2n3A48Mm1CotAmdFuujQPTMGu1cafen37Bja+oKWOIPyPJu/7uijVnBE
3My/vRKMmNnUyaIhG+ogeNCmY7zorqBdW9Uyy2A27NryHnSJajPGT1H4jhNhKKS5qVPEsCYqw+TM
lmEI/evwCNXANmpaUTCsUojEjGOM8kLnMMJi2AKbnG+Cf6qOpX8oW+PVPORZAkXiw2nUSgpr1FkS
nS6hnxwnwLAGpa0pBrImVfD9JfugqJgx8TfgItGT81ae+MYtYNu+tUmIwjL5VWYxrf1IPCANOUZC
ovueu90mviQsV8I8URtiNsSszWO47nZVzGb5S2rVZE14BMJXsvlUn1k8gBECumkwjyBgqZPAAwYZ
tXmJqCrAM+hUxKUHxh7GRFSQsKrB+auJRW2n/1aq7C2T7rLH6wS+/r6hC+bYIVxnfPndEQLctqVQ
wMwT1jeEu+vLbfmZyUYuwqfLIz71uNNQmRT7/TSSR6suXHdmkeXdM42VhwPfR0L4ZfhQQvz/6yi2
eHGoKg3l/TYwCGlzJdE7uJCPdkvlG6HYeRorqzBBp4mwWCj8nkN2jBnMWt0V7YelraUxdWPjt1/B
bDtlnq60eir2VciUL4TlVXoBnyaLHW/9PzN+jic+xyrl8QWz4C48L5KXK1ygYbN7O9dcLTFjEELZ
6M1lmZBts03fBS/4wXEiEbBRUZ5I9EI9OUcxVyGAL/QHvioIzuBdbD+BS3vV7bH/ScuEYcNZb5DU
l3hRDbMzv2sJKHokyeHMaNZF+bXqC+Ar2b1IwPMf/9+Zn0dbMrORkqOTrBvuWkzH78+yrR+D53uK
vmh7N5ricQ6/AkpdJvz9bFPa37iFWDFKFm9a/y8CSFSCT6p7oTq/dphUbkKoEO1C+WppSE7j/JPE
8vrfZiNFy7x4Qut8uclYcm8DRjKmVX1DJr5aQP59q1VpvReUG/mEZ+YkcbVx1deGMz/c5/ude4Y6
JitYYS+pkVmaOTiej52kge9rMs6sar+tPdo6upVOdq/jK7gv7J7WgleEaebsmSq3a1jx7JLjZBYV
rcT0T+JNKIGc+xWduW3yMNpjIdQqqbhYVdc/Mw3kl7c4+MTnkcS1gFqU+yw+CUTHsxfXfRxv7dS1
x1rLiGrvxBMyr8S1Kyl4GNbrx1H9I2y9+FR/elG04mAKDIGcocPSnW1uGLLlLeK0EXu76a0D5Zfu
W/nId88XUE9jSQFb378+0qEVn8kJPFSc7m53RTJrSbDXweXgh8MLQiFvgfAnLWSop/VuWyZdPUGV
Q4SbkfxRG37+8a+KValCJ25pmE61Dz/2q+1tsRcJniVcW2v+9+f4TpL21xc6/TYAyHxiA+3R9B68
EwRS25AAcdb4SPJBjo8eYT/y/UMDRfxuwxCl/Eqwv0envmPjs2VAIzT7qV9T5Q6sajcgO1v9687f
WwkAijQSi6UZ6sm/PWSdjXlylZEp5E6W4VqSa3bTJjNjvpfQXNX+yPMacHwKikMfugpZdT8ZgF5F
9nJ5WvXzu3EMX6PA52AnBOD0sA2wxumksmfkc+Vsk8RlR5hC/wYrI90Z9qNes59/OBlI7SVOEE7i
yZ5GFvj6k1GOr/Ndk8wKUOvhtzN5MAT8qbnyC+YR/Aa2c/WsTvC5od5i849n6VbVYL+u7DzSbIIS
RQZnloHRgNgGQosCd2UYNevGwThXPBmmtFI/sA6rdD6DfNLZ1ViKXr4iePpVYe+k6+hmUYW3CfTn
hedKQ4Bo0VYVbGvIBfcTMfz6tQVoL2qtF/WHYcmLKUdvzGp47KXvILJ2wsL5+yB+kr6xZGKWRcKV
lTtBCkBlMBzs+9w8l8CEaWCcddt7noDt+BvcN4mT88RxGqlCUzKfSFDyCm3WxCmRvpt7kX8834/E
7MloEoNpXpPK0Rve/qavwCIBq/DvSitmrRQPsWMtfzbzWuvS2K1DKIJrWT2R8RTLBsKpC2ikO57o
rPM0PJLSqnWmUguDcwXWw6muWcMDYd/6Kp4lCSUl3K7N/3C2mXXa12L5iU6qZogOiPvazuknp9dN
rQXpupFGMpTWPGYJKzYWsKiG5JPCJhiM0XB89vGbW4hr9zZPYJ5zAh9BvuoH1up51Iigdd0+oUln
5O23G7yWfuTzBHYdbWvNTjWOMCISstg8p8lsgSe9Byh8Ngl6HqS6XnOQ4K+hxBSH2Zy5VyjXq6md
8rJocCgE/GhpxJHI25kotI5lhXvpt78Ynip2eJKRqnB0BFkYzfDEK7ZvD9qwohysc9ByH7nS2F9w
zKC5yQxSAEkSQZbcRFP9PS2odrE4O0rHiFDRLMISgDjg47g1PB9M18A+gXDgS+C61ZDwE+2tXKq7
v9khaYBH9skLAdsDttUvezJhMVgLOOq7eVuw17McJ3/8NNL9PnYY85jx4gYBYJYPH6PLJpTxqp58
SRc4PZvTt/sipNTguR7TGSWSuJNEbypnoofb6CF4dnNf9LT6VMRPsefl/NNmmE+oQtUpZ2MO9Nia
Ur5KM4Mw0TRHlyZfHNooDq7UnReJTgRjvl9lvPRKCJM7VgDASMvtWUbmU1HNvCaOFwfRg7sdeEv+
u4NBi0akc39e1M/9Log9SbmtWeHgiPWn1eMuhyQbm+6OKLNnNkR6JZGnLgvN966/V28HlKvtELRj
Kii9W7GBqTSTCt0toM2nJJfcqdyO0OEtFuctOErjKvYpB6iaET3Lhi8jXGWuKSyoonLJmvBtRQB6
4ceSSjpTJBW1q5Mo1Gqspm51ZOgia4+slqFKxnX2IXhRO5MKKz6++9NVQVLD6HhT/S5lvUhRpPVg
cAMeMlcSfg8PJGLv5s9XmtaHpOkAoh8pWjPYruJ+bqCj7vKhh4pEDvKE9/b7N36TtGtqYo0Ujkar
5DCTWzu+0jZ50fv2jG+l6+eV1WAdbtVmy9CE92MUmDvPjR9jvA11QBMbw9Q0zBjqbVVg3SZeHN+G
3RWiE6hJgsiGhWN0/KDpqDonwpB3JfQTb0KY65T3EUFoFvX20e5waAcsxb/v0rr+aAaGS9Y1qb51
cpyEAEQCuhI6TXzkG/lElq2KxiiwCLPUte1p9WF3qmyccnkJPeyRPyfzEfwGsHLf8UiK3ymJaAje
oyRUs1EYHcBdCPJfr77Hm1bHJaBSEZqr3EoQbFavQLCub1zyYOfp0sy8K82LqAYMuTrB1rv0o0Sf
GTLPpwh2UV/VhOq1iuW9NLTy4zZ2J8oHc2+4D5eXY24QQJDmMshLCgLRI+WRvmJXrbe1NFlAgpvZ
7qqC2b7uNSGQKfbg7E4SEHAP3QSr/7K610stVroZbLTvMBAX0PGwij6uIcPrHa/qnd8EKvI/V9uo
WGsx963qx6yCN/znDXWkzF/NKN8Zeeg2RlvqDvO+HTFhIzm8PB9wx2SA8bhw/81TKF0UulWYkm/i
GOq9C+Q1qlgP7KrtitSUqop/TlyEaG7jibKwD3x0U8Jk5hIztHThRMC+B1B2Uh3zMXIFDzPbksWO
9BR5o/sd53xtNWgrhhHODphvA+G83DqdjtHgngI7zfVO2degBh4t+hWEtYUlLvS3iadmMm4F93i9
hTnXayynLwmpstgdTpB5yi6D4tWdBjZEQxLYbAlY9SzH+OoZmkMCrGSNjPP6eJf2wrOsMfxsRrUR
q1vwDlzJNvVy5Ut3ahjlWutLpdxLu+IIXlzFhfynvK0ZVtUCSyQZESp+8Xh4O8VjCmSjg8WsvHRo
MKzv/DIgXgv2FjSD24caX24niJyXLRkgAMMx/fHlHlhqhMY8+hw40ZaJ//RfeKB0AfeiUJF1IM6u
n3X4PsIouaZf9/eQjvzgt0ZWrALnCp7fdrgcNHH2BwIRcmQVln2F4VmoUqxzrqSStsjxK73emdGD
+p+X/lYEmt5+uF0ihkUSFHhjjv4C7OZ1VLWjiUUSo0xx4bcLjuSHA0EhJthSVkm4wGIhwJP+oO8e
YsxekWA8a8mEC2dL0ds92D+HlUiiBauL9tk5c9FVc4Dn44aM0X5qFguRdLADQnds5PAHO3K/wRCH
dkSro7axh5OLFc2/1z4ZoqCrOcvpgQq/PFVwVDfOQYvrvXGqHmUXXjDYa7LaxR9kT9HONMs/FfAM
42HUisl9VP0=