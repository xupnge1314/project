<?php
$lang->project->effort = '日誌';
