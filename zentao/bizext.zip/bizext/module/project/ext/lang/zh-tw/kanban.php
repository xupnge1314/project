<?php
$lang->project->orderList['pri_asc']    = "優先順序正序";
$lang->project->orderList['pri_desc']   = "優先順序倒序";
$lang->project->orderList['id_asc']     = "ID正序";
$lang->project->orderList['id_desc']    = "ID倒序";
$lang->project->orderList['stage_asc']  = "階段正序";
$lang->project->orderList['stage_desc'] = "階段倒序";

$lang->project->kanban      = "看板";
$lang->project->printKanban = "打印看板";
$lang->project->bugList     = "未解決Bug列表";

$lang->printKanban = new stdclass();
$lang->printKanban->common  = '看板打印';
$lang->printKanban->content = '內容';
$lang->printKanban->print   = '打印';

$lang->printKanban->taskStatus = '狀態';

$lang->printKanban->typeList['all']       = '全部';
$lang->printKanban->typeList['increment'] = '增量';
