<?php
$lang->project->orderList['pri_asc']    = "需求优先级正序";
$lang->project->orderList['pri_desc']   = "需求优先级倒序";
$lang->project->orderList['id_asc']     = "需求ID正序";
$lang->project->orderList['id_desc']    = "需求ID倒序";
$lang->project->orderList['stage_asc']  = "需求阶段正序";
$lang->project->orderList['stage_desc'] = "需求阶段倒序";

$lang->project->kanban      = "看板";
$lang->project->printKanban = "打印看板";
$lang->project->bugList     = "Bug列表";

$lang->printKanban = new stdclass();
$lang->printKanban->common  = '看板打印';
$lang->printKanban->content = '内容';
$lang->printKanban->print   = '打印';

$lang->printKanban->taskStatus = '状态';

$lang->printKanban->typeList['all']       = '全部';
$lang->printKanban->typeList['increment'] = '增量';
