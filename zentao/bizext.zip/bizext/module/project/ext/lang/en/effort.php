<?php
$lang->project->effort = 'Effort';
