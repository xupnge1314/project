<?php
$lang->project->orderList['pri_asc']    = "Stroy Pri Asc";
$lang->project->orderList['pri_desc']   = "Stroy Pri Desc";
$lang->project->orderList['id_asc']     = "Stroy ID Asc";
$lang->project->orderList['id_desc']    = "Stroy ID Desc";
$lang->project->orderList['stage_asc']  = "Stroy Stage Asc";
$lang->project->orderList['stage_desc'] = "Stroy Starg Desc";

$lang->project->kanban      = "kanban";
$lang->project->printKanban = "Print Kanban";
$lang->project->bugList     = "Bug List";

$lang->printKanban = new stdclass();
$lang->printKanban->common  = 'Print Kanban';
$lang->printKanban->content = 'Content';
$lang->printKanban->print   = 'Print';

$lang->printKanban->taskStatus = 'Status';

$lang->printKanban->typeList['all']       = 'All';
$lang->printKanban->typeList['increment'] = 'Increment';
