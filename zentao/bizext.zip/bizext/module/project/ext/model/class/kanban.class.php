<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPpKVh9eqpnJTUT8vkRcyhokUBeoBpy1UhMrN3Z8+fmnOPB0SZHQnUKlEx+s+oalNXWgAR8Zm
+R2p41H6sY9ZhCWFQ7edFxwzX1RHzWdwdD+ZQkpQE+SRg1Y6abZZfV/hKbFOFrToH3MLqiBRuVPy
F+hIeB9ACEtiypFyXsm8X0Pv8uBY+lk+Ug8pEQssT1hG2V+qJcL9PqIVkbQ97hY7iMBDRNjgwJjt
jY2OwmqVqu/Q5EzhQftxOAxKYN28M08YBq70pLOaaXmUNcP60EjuM+u4AK06wAOHMVqvJrbI+t8f
jUH2ytyBdfjk8bZFLKH5PWODXD7lYGF/WVqMadY27JGaT01rydqnjt2I9WVhKKS5qVPEsCYqw+TM
lmEI0Owetawcx7zE7V3L8pes66Z/xFw9VxOwANW3BAXsdeF0FaOA+sBowKXm/X5gR9dMyrOmIAYe
Se6aWzYmAJ8RvfJiHfBWpiWS1LSuy/iSWeDd9ElZbp9TeL4Kd1Jj8hThsBaxcYvEbMgNQRUIIQEi
3osriAeIv5rWxRwzrfr3dIDgsTAAbCFTpdc1MRrmYb70dOPvcRb/CqTYki5Qt0xtaQ2WL063DgKv
fxExYQe7Q/mtT1rJMVt1d/drNMkNu3lQ/G0sy3sNsu5ezEa9DizwMHhogQnd+dsRckkiIj610MPS
0o6paPHHLYxnTz4L1y3cm5GupWI1lT9Ri9DkjERUpuHNnn7erp1dfA+csjEdbtmA4oWWthLKq/eY
ZgKP1Tbak5IPrIOlwKn+Ljloh+4wg2I9rWgbuLmT7ho2aqz81HCNqOOYYDv/V2liYPAEKWXGl8hc
rSorqlwzccwMq9obe0oetG79/RKirIKegYTULJ8IfGlRer5z/wxCOa4wOlTMxy3zYUlw2Z4IcKC2
rPLRVq0UUpLqBHaC56JlRnFIVKW9pJBTZo3Ljapmm/RH9aCoEGmR6x7rli4HESXBEkPxe7V1n+kV
qLXJwxUEYToUmPk+wNzyDI+aEWLmek2YBm6CjhhYs3AS0pg1PwGH+UW+NqY0MpgYY91mwuJjsu6U
5cg8zlmEFhMKRPSmBXWlWwqGngurci49iWoY5fmLIPVOAEc/IKKMlnMFsc7BnVJOgyAljrD++aLh
OPGF45sihp3NyzDB+xhk1tfTYOEWJO8MpzYtI9fO7Ojsfg1Op7hR7jnQ2CeqCMgLAqArX6cDDYZI
gNbWl/LmVJTRBmvw/GJWytYQeBuiJqszW59Z77xbT9bIYuk4fBs4If/B87nNEJSoXf1EK+H3iKVH
R8gLzVDy+OoHSyobiUt8ZckpQFtXDXfwfycRwteLIhUZ9ro7/CklOwHS1TIYiW7govUdChfW8Y2A
fTkbdYGw7Bu9e902EC/la50pXH+CHNcgAEZ+Afqxdtzz8oALCIEfUL4qBXH4uTpdGXXlgmO/b2Go
WfhkYHrneOTFWKO8eB11gtmLQEZlyJTHbUf0vyPcsdHID87wRfpunhWSD6dMYNg2xzLwjuYlquDJ
3CYNId400i/tqKR0hPTODdQuoEtAsgzx/Xk91FVd9/6LuX5uzThv0N1LC2nq1at/wqiecGVbvNlg
rTlG/VoTZo+DplaKl2L3jLE+D+WMXtxefp2pgkKc/a2MqApjXjXliKKwNtvP3klMmUUXwWLw+hwY
0cd8Xno+UHYdOeeHSsNKI4qvK/DZ1rMvA5jZyLaRXLum1okRrWjXb8GXWlbukjtD9LSQOmzfbJdp
C2qH7or37JTxn04mbGw4klL7fvAdNODTiYYSj4ZIxH/gvcMKCV+9Gy57WLzZKARMwX1hFY0oOmeD
t7IBSygaC0Ko6J9kBKoAxcsBfbTxlw09TUoy1QAlGfwT4CdkOTjSEShxvx7HwCabASC6UnFILa6S
ODi5Dm6D7DKCo7g0fOL/9VS1QhYvkus6l0fVJPjAc+3TfGmm/Qejd7lAtK7sazlHROoaqXNb7rPz
cBNiOz+wfC0MxrtKecPGdaFCcS9/b823+b9UIZ6sZy6qOk8HGMTyC+iwGuiTEKmY56uOmLuPH7+u
/IbZ9xXUihXtnjcDSEFdNY5zE3xXY609BiS0tEVPowczCefhI0Yz3IZErvrVyA/KsVx8+IcIKC7Q
5WCvr/I+5XCP/riocDmIvw7oo9E1hCyVxnR8dh13EBFKbNlxMEN86F/8XFD2OQjYSCuda8oisda4
l92ILhR82d1ZGFP+IEiCeq23q7DZPbvMitVANR+d+eLcc7euiDFTQWPjXtTSGlSNLXHeqx98lPvh
XCpRQkB+Ow5cKtltHPcNBxuk0ziB+xjsJlfj9K+Xqo0mi+Oa6+uIq+yJZlpNTmprvON0lt2En5Rn
DCpyE7WRegT3NigwvhcEyPWm0RFRFzEiKg0Gr+7I0CGdJz9IqiqJvchUEdn2mbOBVUKQOTfTnJSX
ix8fbRAyIBi4FmjVeLtCWOZzVgIVvVmcaNMKvgTF/UPGCoI1lWl/7+yokrYIPf6/cyt3aTnmd5Uo
+CgRdgI5mJ2fjn4nV/oXAa+Oq/kBFjYPUOAMiR6bwCfx/52JGhPQ/+/0gFacBM3MuV6HsERTZXe5
Fs4iurtUeuPF4Olh/qr5U+D3nqojHf+Io3R6NzpD3N3gdjYTQKN50BYcTXcT99qxVsQRrmQljW62
Kox0OsJxBzw3X0NRfdy/sQw1YiRiEQlJFtj8gL8PJ/OJi6w8e9XrBUSbIGkia2khdYz7PlHdo7HR
exzGjdEy7SF2OLcXUoETXAuG/ezZxtqrro38dwkvrGT1r+i/RTQW+vqomjtC9RjiEdG9XouIThRt
Fl7J4nIpw++G0/yIvv9KXX8pAnBUvr++bbvUJzVXsxrZlreqPRL70ryfnL2gRkHchtFYBffo6sx/
HldoY/vYFLAq/3a62kKNE1z6VOVf6rYzFKHnoe654BDRDEtwsJKJklBXDO3X+9nCg+IjrGmNLaFf
kS3rxr3GjAgV9pyhZAPiqCSSW+Eb8xdrtCvjNWb+smq3KVrgmE03uTJ82U2tXBdI6TsQEZuw3xzl
I5jEcucuw6voK3yWYlosO6fSkodGC7qQHwHpMwwAQ+GDiAXivJ0vizWGqr40IJFqp+27MBclSVUU
9makPvlcJtBLhrp/VGCSLIP+t/9GQrFC+0HNH9++gt6DuF33+aTt/yaVpHxU9omD40EJron342go
ZbnOJkjqMzWUyxUpcyj5UuLbMlda19airShPbMXVopa1m8zsKExZfDJTYH571k/73UsnclZBDSn+
eiGHtQeYubh9FNDxqsUBFxlAkmqKKUyP4OKITfWI5qazScHZezvkj5yJjCFzKeV61+9kiG7ufWfe
zH3hNMhJwcTnNfsDx76QA3SZkG56uxZzjKQiWhlIoWvvne7puvRvAcCuG2qXfqS3Gm2en5ql58EY
jDwpwqvlUSKRd9P6fxCrCUupUZc7+VQMLo6Rmu/PhT60hbYffeJ4JPi93BX7/MlX0pECxsoc8K7F
9Eum8xsQ//xpaZCU9Fqxii6kzADGtvWzd4CD+Zu391Od3plMaxHTPlgganKxKIuuQWxSJd6MQYnQ
+PVOWVtjj9x3A9IIWxX+rLNtixZQwQVvXiaHpgr9N+KOODoPHqeM6rhfniw1r3baoy8/7Hd8/4D/
BDHxTRFM3rvZq/rasPia4IhdU8UoY0MH0NaqdZ7A9fi0SHHI9crXsRAUuSfLzj1Us/tLtT/I1uf1
dmEzLGHBvG==