<script> $('#allTab').after("<li id='ganttTab'><?php common::printLink('project', 'gantt', "projectID=$projectID", $lang->project->gantt->common, '', '', false); ?></li>"); </script>
