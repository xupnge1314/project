<script> $('#allTab').after("<li id='calendarTab'><?php common::printLink('project', 'calendar', "projectID=$projectID", $lang->project->calendar, '', '', false); ?></li>"); </script>
