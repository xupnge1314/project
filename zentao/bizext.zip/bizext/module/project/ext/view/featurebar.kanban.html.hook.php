<script>
$('#allTab').after("<li id='kanbanTab'><?php common::printLink('project', 'kanban', "projectID=$projectID", $lang->project->kanban, '', '', false);?></li>");
</script>
