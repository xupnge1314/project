<?php
$lang->resource->datatable = new stdclass();
$lang->resource->datatable->custom = 'custom';
