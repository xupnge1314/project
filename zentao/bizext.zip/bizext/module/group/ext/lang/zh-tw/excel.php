<?php
$lang->resource->testcase->import        = 'import';
$lang->resource->testcase->showImport    = 'showImport';
$lang->resource->testcase->exportTemplet = 'exportTemplet';

$lang->resource->bug->import        = 'import';
$lang->resource->bug->showImport    = 'showImport';
$lang->resource->bug->exportTemplet = 'exportTemplet';

$lang->resource->task->import        = 'import';
$lang->resource->task->showImport    = 'showImport';
$lang->resource->task->exportTemplet = 'exportTemplet';

$lang->resource->story->import        = 'import';
$lang->resource->story->showImport    = 'showImport';
$lang->resource->story->exportTemplet = 'exportTemplet';
