<?php
$lang->resource->user->importldap = 'importLDAP';

$lang->resource->ldap        = new stdclass();
$lang->resource->ldap->index = 'index';
$lang->resource->ldap->set   = 'common';
