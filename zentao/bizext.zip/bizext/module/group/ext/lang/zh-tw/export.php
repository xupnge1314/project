<?php
$lang->resource->report->export = 'export';
