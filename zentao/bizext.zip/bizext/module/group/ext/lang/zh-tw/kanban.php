<?php
$lang->resource->project->kanban      = 'kanban';
$lang->resource->project->printKanban = 'printKanban';
