<?php
$lang->resource->my->effort      = 'effort';
$lang->resource->company->effort = 'companyEffort';
$lang->resource->project->effort = 'effort';

if(!isset($lang->resource->effort)) $lang->resource->effort = new stdclass();
$lang->resource->effort->batchCreate     = 'batchCreate';
$lang->resource->effort->createForObject = 'createForObject';
$lang->resource->effort->edit            = 'edit';
$lang->resource->effort->batchEdit       = 'batchEdit';
$lang->resource->effort->view            = 'view';
$lang->resource->effort->delete          = 'delete';
$lang->resource->effort->export          = 'export';

$lang->resource->user->effort = 'effort';
