<?php
$lang->resource->sms        = new stdclass();
$lang->resource->sms->index = 'index';
$lang->resource->sms->test  = 'test';
