<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPuUXqmDB82Wqgcz688lKWw50dRgYeQyH43waB8UKfqntOeQJFdpkrV+PHMZi8kQQoPEf6epY
LcufVIEddNSqXEa6MjAUw5taM8V9aAEYsw+cXvR1MzJ0kjHk1X4F2OUgdyfPkR/A65FJIfd5pEsY
KdKHDhBhOUnWGIP+QCikyH/+RcjsEHPq0BmVUKBQvElJqvsmINU4IJ/OhLDZCk+fdvOv7tVTqRq8
WIWKcdtUdxtHKU9/zA3yc/SnE1NtRgf0yxwZmnEeg4LUaKML7sULRak4CoWP/M4LmBkF4KG6/Xv2
jpbAOYZeCA3MGtaCztYRwsBcWVaope9Nta1qv4YH7GTM909y8V+vjEcvTW7hKKS5qVPEsCYqw+TM
lmEIr93HU0ZA16r3aSWS2pNak3b9dDWXsLJwtU9aZngPDebnW/Bd0nnQ8caStC5kh0mQorl2O0Zo
Nzv+Fx0qn+2rFx2wVUKsLWt9i7NrC7AfltMxl+2AA52d7ZVdufd90xMH0p4WaB+sBOw3/6J1N/uQ
F+92Okypc1XQkhzRqYmIPfbiSLmdd46IY7W7EwLZrTQgkHvUvL7OKnyUpwrNZHEkPlEKBd69SfFz
Yo8oKpiEPT69Eh110Q7/b69qvM4dLvaHW5W/QmTiMk62xR/U+Y5hVB0MEMo5E3JBHG4KX8HMHMc0
tSfWiw48Lh9GXpFd0OPU9kXZN7MYKG4z8WCClQqU1ABNPcqV05qxijkRK81fo5xPRC6KNZYTZxNp
MDL8LpNQEPN+g+WnRS+T6mdUYaDfDq0YCcZ9TAVis+gpZhxbCuV2fjMXOCiAQ84zkHVkOfvoAyR+
iolyMMCa8JTu/zw812mMpCeg35lP5dkfzDTCmewJDyeIk5IoFrcpHzIZSCDmr8BjpSuqDZq2nT9+
ng4d996/TVxFGY5DEvyDJ0Gz1MTvCR2zZQz6H1nrowkxQIrM7BU8cRVwQzukG/dGpnpE7Ys5xLma
7iaZOh+32vB3LKsSNVnMgBbuyFL9ksmx05ZuTND+UHLsyN482Oylr58TXVnuXi8ADHv0upk3pbEZ
svrWdNr7BIhOq/cZnScBbhkzSZSi/FyuPa0A/nzryOyrOV2R74QdpMturDQeWOPB+pDSZH7erQQf
GhMRpQLIx6m3Y7uY7jgVphlGRCS81pN2vrDjuIwZybxrZtoux9ymjqHLtMOpIvBYiWLb/O9rcZ8m
D+QBDi13NsakX9w4KXDeRFllmXZfxipxlo3GMcMFKsrZExxjIG9PxmIwWtjM42gFNNc/4Ej82R/c
QDF6NtfMg+OARF+MdJfTgWwUMu6E4Z+X+6awoF5ynAbFBUwq7fEnrJ9OaP8wYPNSO7Cx3Ug3z3iX
uEXLfAafjTC2EDvq1hMnBFNRxuRV+Q2uDHipKYEZgFLN8DmWp45h5W6kKQ7g5puM/cgQNKihW5dM
vW9S/bUU0+PnSc2n0EQ5ac8q9mBIoPc7DB60iq07udxo/+Z+fARVBmWUDzbz7v+PdTUXPq5LwKF8
mvxlyojtVL4pRTz9ZfmAo77JqTIQrEzKTI+/lSl6an2/IMhXoMS9OthVqe1bLOri9bMPsJhhLLG+
WPezdMxbNaQRtp+tmlKipjs4wWBv3Hgqbhf4O5p0q+FMkqQ+XX0tS2y5bRS+AxCQFPjsftYQzm4N
IZ8R7d49ESY0Ngnr46Vt6XAxL3apV00eeOS6RicNCDvQercgfxgA8rMOQPb412ZyK4TU/YqMkvFD
QApSuWXtCewYsTCBHcJnoMNeYWee06Qeb/TnMCKcHV+AhNAZLDwzTMAHrZQ6ENGWhgkxPZcZSKxy
Ov91PrmtcbAjlAza4ntK9UI4EreafyNLAagiK4aZsiy7NOOAruRHEi3KuIdV5kS/8EEBv037qesQ
obOK8x7ffPhkWRFqnjoBvYKxhSAMnhOKsWqdtOpjLNPBxzNPrrGCcowhLaNenYOW+Mxkp2Cbt2sM
UyFKBW/PsXkHymGdLzKPaiVKnMTL8m4gi2diQuzXZfnrjgjLNGp2W284H98Tqwcp+mAIW+1yHFA+
Kcm7eL989kWsGTkykw46tcSnoniUo4G1xzxk4dhov0ncAJuu3ICY732dmDJTTwg4EHtL6HdRT4DP
q94a/y8emKwi+LkHSqLH9cO18uUces8Vvo+cCIf68sapaYVpYP59LvBbWY0UHgQV1D/Z6nTENMtk
FzJf1/WIytm3WS8I78136zgV2rEozdLsGWe53Vf5gEA72A02jhc7351v3LsaO0/ETXXDm/aDb6jA
sNuh9PE2/He0XYun8GQYwPo0wfQIBYITqQbqcDp+LbH0KX2BaKewlPIHEc/cOOFlhLyKJdxERhqY
lQyoOoo6TNaGcHj+k+tMNY0ZD//tEY5BRIcCQGC8lUd1DwXWsrdp4tO0Tj606c2Hs+lND91m/h24
NH6almzitvBxGsa5S/haApzHPFK40VR7LlqPFpYcUr6/75ocoNVVNjIpxdZ6CO1wL82q+j46Paom
KKN+frucvpZA6NCoH908MQUFqrAlR4nrCtK564M68BXvHPd4Lg3EXAxrt3M3v0hMukDTIfAX6H2I
I4XJjWzAr6iLN2//G9eV8d5rhOltfAxKdULhq8zCtQERsynlxXSaVeBKg7KQrPE/b9taTcphO7Oq
WV9L++oRS/dOIKUG2duwY6hnjd5fD1iI2vGKCqwBdpXmOHW2FXSmVe5CbNcSkwp5LQ2Yia6HPXG/
QVEYBQo2wssOtqmFwlKxbaJJDk69+rj67IaiuJA62dD5Hbmryhm9Z87RS3Cxiri1S9GM2VKSHY70
g6ZdatZJHf8tMw6jr4vq+cJUgL20LFhyNPdsats47pVqRoqUC+U+ukVv+SDZ2fpru6LvDfhKevPh
xm1VU11iDAdToa24sT7VBE5IQ1iQautIzUM96PLDCBvh3gHDfePx2HzixRBba9AMlhtep4/pvCTa
NMz3YTDC3l2MebOPLjfnMaIHIXy5GdRjQjsBddWwWpLw8WaiNkKAjuPh3ZJE3TwXe0GGU5ohQde/
LvABK6ApJLegJJled4NY17cGjkhbWXIva/FNAQr6SfwfEPgMoxNAZXzWDzYOoTIlxB089J3w3KBD
OMd7bMxdi4qC9GdVLtvB1Z3TPaPZq06j8TWZoPrrf4CIsqcQqdvWH2eABtev/c8/H9yTB3S5hGmr
55lKvCdbrMZDUSrq90NmmcOAm8APh9/Kp71fehYzdXBdYYXgppgWlIJvfdRHGRG8ob1PXSh2DNGq
v6yR21DDlTg5C/etIrhh9uG5BswrJpCKS7DWjfKc+4jaBULu5NhcgTZCka1IlpVqPUFeab+tJy7b
GBDvd6PeCdQAdhUf7srDQ+8sJccaKdyP7t9ADOaL1tCKEvC9ghrQInYfp3zjn7Zf/EwxVYISWJfL
e1VDVS09vHmvnII74+CqycgS6fdOPXZr82jR8P8oMPJ65bDIYkA5+GMjdCxnqYHqlq/U/p8fTYYb
wXcdbXQIZQ9TJILXJQlja0DOwezDxAJe9RsG2rXnMS/AhVY9UmPZDw3zJbQqIzvI/wZ0v/8xySSx
qfT1KIBcbX/jYZfRBeD3+3cALj7WzDmuSdHONytlRqP3jTGwGu026JDfs0neCwGqfuDDDnzooirH
tHop3lmHjQyLp+GtXYQCE1JVsITeJzSTs6hMb+PiXiMhFygryru/bB0cW8nQQJ8r4mSRscJOv/La
uNFn6Dou6+qwKkYeM9mJgd/0vm5PJbIhDDw0ICGWCmplDG/jBwZPR/PHoZxp9N7hLGlDrdIJP23x
K3OkVISht6OOO7DTUgILHD+oOZUGfcOGdFxzE8DXwLPJ2sO752xyANOx8zKkyYSXooe4DA6k5Lx2
kGWA1sQecYHRbgN5kzk+KK9w3nVoyT+mIAGaaKs7hRuXqmnmc+8vvZlkatWzDBjm6HLfT0q5kK2Y
EzMVGyLD5Vz9x0+LDyQe6b/7rc9mQrDJmAMbNnoM2LZF2kpn1lFYJHI4wvAtHBydMs460edIpktd
bMOXtwvPKQKE4G3SL1uGhihI6X6GDSWbgen4+hy+Yk7KQIc6cKCImwoTzvI9Cb2wOkyM3S/iJZyu
JfylTaIauxptirK2tnHSImwi96pymXQREDu2uAP8LJQ7gF6608q7t1/9J5WFKB4Abbs28Ah2tetq
RY2/3/PVUqjFnm2+axy2Q+9Z