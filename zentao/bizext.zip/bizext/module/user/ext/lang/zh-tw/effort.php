<?php
$lang->user->effort = '日誌';
