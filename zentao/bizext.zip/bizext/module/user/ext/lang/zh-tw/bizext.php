<?php
$lang->user->expireWaring = "<p style='color:yellow'> 您的授權將在%s天后到期，為避免影響使用，請及時續費。</p>";
