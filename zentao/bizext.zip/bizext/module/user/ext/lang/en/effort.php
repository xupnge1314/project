<?php
$lang->user->effort = 'Efforts';
