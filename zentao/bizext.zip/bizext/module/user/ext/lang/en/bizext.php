<?php
$lang->user->expireWaring = "<p style='color:yellow'>License will expire in %s days, please renew.</p>";
