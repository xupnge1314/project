<?php
$lang->user->expireWaring = "<p style='color:yellow'> 您的授权将在%s天后到期，为避免影响使用，请及时续费。</p>";
