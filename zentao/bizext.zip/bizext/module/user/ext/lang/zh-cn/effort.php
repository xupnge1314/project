<?php
$lang->user->effort = '日志';
