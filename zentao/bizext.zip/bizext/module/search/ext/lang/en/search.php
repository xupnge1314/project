<?php
$lang->searchObjects['todo'] = 'TODO';

$lang->search->index      = 'Fulltext retrieval';
$lang->search->buildIndex = 'Build index';
$lang->search->preview    = 'Preview';

$lang->search->result            = 'Search results';
$lang->search->buildSuccessfully = 'Initialization search index success';
$lang->search->executeInfo       = 'Find the relevant results for you %s, consuming %s seconds';
$lang->search->buildResult       = 'Create index for %s, add %s records';
