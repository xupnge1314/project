<?php
$lang->searchObjects['todo'] = '待辦';

$lang->search->index      = '全文檢索';
$lang->search->buildIndex = '重建索引';
$lang->search->preview    = '預覽';

$lang->search->result            = '搜索結果';
$lang->search->buildSuccessfully = '初始化搜索索引成功';
$lang->search->executeInfo       = '為您找到相關結果%s個，耗時%s秒';
$lang->search->buildResult       = '創建 %s 索引, 新增  %s 條記錄；';
