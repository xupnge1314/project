<?php
$lang->searchObjects['todo'] = '待办';

$lang->search->index      = '全文检索';
$lang->search->buildIndex = '重建索引';
$lang->search->preview    = '预览';

$lang->search->result            = '搜索结果';
$lang->search->buildSuccessfully = '初始化搜索索引成功';
$lang->search->executeInfo       = '为您找到相关结果%s个，耗时%s秒';
$lang->search->buildResult       = '创建 %s 索引, 新增  %s 条记录；';
