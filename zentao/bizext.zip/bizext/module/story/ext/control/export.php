<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPrJdNHoKPAPJsIZ8FuT8Jb/XewAwYM41ymXJe8qx3OWmdJ0qRMJ9Wn5kyjGUci4Vn4C5yor8
52kmeIU5yDimZkxoDfGYoTRxau4INYO2RGtAITPbSXLwKqCRQbHoH+aniqgOBKtB+yZTcyz3c/YS
TsgD+p91DXuJIUPySnABzTJ40raVxmMwBufAcQp51A4ad+LpMbMkvaXtxD3pOX405Ms5lSfdRLoc
CtLjQW/uVaghcmXtWEATImd/nNVfDTZ88W2AlcVL3RrPCXzEbyduYLjZOHqK1asJPae5VPbt90RU
unoczgiJ/0U+k/Ub6R8IHK1fVupw0owjvVeNEu+O7Gj2gob0Q6ZM5yXuOmxhKKS5qVPEsCYqw+TM
lmEIA8RPDdxiyusT1JxOYtFSk2Gpg4ZrCXMFvt83Hm4we+0wdiD5HNZMmD2mhmr4YhsRO1Fvhk7T
ky92KPX2nImhlH+ACUtlX59j6EGsmPKaNtGx6walN46d0oDO1q5fvmWVVOsdCs0lkhiSxW5EBJFr
OI8t43weLgOQI5Yc3eV6k4AEPB/fgMVcgOMQnpH897NRVL3uQYAlIBGqZbl0z4IV2yjQIt/w7B3E
kL6TpNz+FSVrdh7sAYNmAYai26ocQcJgHoLNG3sJP39Huf+PGQEGAKBEroEWMqthiPJUBcAFpHPK
efKwbCya7hpDniVxk84m73gyQEn8l3ZMa4hjl/hX8GyiSAxzFzxPOM8pG3Lbf2o6NM/jQoX3tb2B
El+9ldp8zJd2JXS6RdezR8vyyiQMqTtFgPUzSjwvH70wkmqlnTYaZUT0ieeomovEAJN4lH53DZhG
yDJmgSIbVr3sxD+wGoF0ZacUO6AsPNKDjSPTxeaSPH3+RuWUnvWNBrJl3txUgPtqGmbgw0DPe5E0
0nKjmYWrEhP8WxJtmYr7NqNTVrZwFNWomUn0qnwdIvX6a+lpyNr9yv1UqS++c+EUTX8z3SwNK9yh
52cat92VKmZuMBRu7C7OgxMtDevfuc9CZmP68T78NNVWJBavRW9gHaD/E9zugfj0tSU0iiA0RjJ8
M12Es/H8epMv4R+i6za7Xiwcrp29xk0Q0EHTFkzc/x+ME2BWneJ0J/SUb/ySWI2zrKIaruvNTTBb
iDCMLtmudbGKR4RiU+IEGyqmS+R4oSWixD+uhGYch2hh1jYDRv+glC7qwKXkAlY0l2wymhabhmDw
DS0Qk8JieqDBv5P1tQjkBd0gxpf/ucTpEiwTGZ0AcPhHnRCuS/6nQ5FT1XcKsRUBEvQmcJrDTt/u
Ycx22RqkblNuwrBNKjk76KUJJs036hojinQ8XWlBOJ79qNb015bC8W6FnFumAPh2ZQeijclIoBb9
ego/+VS9b0U+XPCsX5HXbst+qv5iUpbureg/9lhsjzzYpyahJRyz21+BPVeKHJzFZUWxrAmRwrDC
X5x/mcrO6/NjzXDE+asWkFCfWP1jRb7yJwmzY2qeIBK82+Y3mT3UkAJqo5Yqo9xMnzIzAjq0B4D6
xcOblwge+gUxok+iLdS/kj0Zl0wKXuKUO16mffo3Fu4e2ekw32GsIheOonm5e5XMiW65NZGUQEMU
RCQBwpYDzO9tQF0aIOBdlkTMKwLjItGhbbKwzoMfSe1CKzN2dU3zcp71LEOPCz+nNX/d0aZikNLO
AYlyFfLt7tB9tr4c7QAVrhoabkfHWCkMlSSC8mokUfcDLKosZ1ij4/H41OaoWfWa8a9d3krnHfjJ
QD3V6z8BKXK/ByLBYwaM1vfguASfAkM5y+EXfUdRVFzgq8zPyl6iRkLpOvx4ZM7mI6tWYvPD4As+
h3a1pEsxPOL+nn7CYjm9r8THOIjfI0XiYjRJ6wga8bnTt0bVkcx5Nnpjn+K1hnjRgRoHLs03iy6H
s3gF0VEUAw6nhMpk78S7cVHD+p2wqu/P706+1yAm73kud/Hh0g+GjJwgDaiNvGFgyWQ80E4+O0Sd
YMYPHvEt9ZT/h+n4ZPiMxXWC2toWFcGFl5d08Ky5NMNyFbL2LW5CUFfIBkX86pMKHuof14iv8dtr
hNwqT4wH4MCcUYdmPWD52xaULocJAhyoAH2PQ/BiFswEi3qkknyHCT08pd/zcmE6srmOJJsJy8pS
BXGt/nMcc/UlXEXQ9+86UNnzUsC0FYo0wwP1X577zBdXggt0AOCZD2MYP53BlPqB+3beR4X8YEpR
JESzzS+HU+6eOApOg83LI9bGCU/eXLwBdBNBk7ZJR3lYtS8WOx5tMcIR8mBqf115Dp5bUSFNl0Yy
da7aGa5lkM467pG+r6LNurCPMoA7/GkHK+RUnuzi1B6JAa4p0kREmMjgZfB2tIGLj1FUEux1n6se
/45uuMIV5eF5/bs5+SLqhHIGgjbpPqR13KRSDorrq5mzaEJWhROreoV70qKmjVSpk4fxEsBBv+MH
D5LS0Ez9pGqOHV61V43w56zF/OB0rE8pe4na7cZ9/JiET7vyL9ekcfpePJ8PCL2RYK5yYFUqyigi
YIUl690gRxdrz9IxImtom5WCqLOvB92lCoUNIagrKxdIQDvDPsoyi7ku+12KdaWReyOtqAhovO9c
WOyvkOQaZ0pNlOCaDntjZRwAwR5t8vtuL/8eaA6OxQao6wKSVi0VN155ZpWi4P77pncDvp+Zxd+E
gu07NO5UQ6CLJOjHbOwkwYhMULu/o0FcP7+cXhRaRxT9Cg+V7mNiuHC/eP3mH2uXn/nXuUU/okv/
UqnRVf7he5MqZklREDtVBkUfS5G+DjNkFwgau11Z5BAFZxgICJXog/PstVD/OBg5MFA8p5iFWJvs
12ZIb95K5i6IunjJCB4BV1C7DfIg9sYe7B6Gp4IoVSE7fpxRjGv2bfzJBS4EtmIPs5gnxRPrcRAu
WKIwRC7kRyvLFrFF9glJE2H+Fmbuly4SbOwuLxXhZHVDzAktzjojaR3kVdbduYh7p/dgXwJBspB5
k9/lDd4qqBYzLKaEAyMt1lyPDn/yXVZrgERI4fgoyxC6+0Ywp9W/O9utb6voq6ccq1lUH7TstNrC
LYoQ+FaEl8nY2mENrjBzM5p+xXoGfr4/tHONxc4aU8hjbfQJG6CnstiRnuOiVRvF3PMtOK5W9mAa
8u2GBfKaQ8Q5tuJEWF78sg9+DcgdP9tZd+6aDhpjaKKr3Nnk35oVNkc/O9ms8EnwCc/o71Cu+e4o
VEQYsKmOrdAD2IJLOPnPO/uILbTguKMpO/alus5M/hWljXYq2ffIT5EncbiFp0IE2sifFNpbK238
YLGf0jkDKUowmJBdENg45C44v6UY1rXiRbxUrWfbB29E1D1Cz6vb2zfBbLD4cPZdldF1C56yHeLl
uAxuiN01iy5BLTaGbwF/ETHQdtn9g3DcX+IQ3y4OgayE3MOcpP/JLu70RuQb2W2z8KLPXPe48MJJ
hFo1b8JP9YBAGJUfnEggfSSGai/xY2KQxwqWqK4tXzKlxgpHg6cHWBuch+xy7l/8tzZDmvOonxkY
UAImcbrKsWDamyOIfKqIBSIvyp+7KdB/DritWcPovU2zuzRO0n4VtAbR8Yj8ShSTzmHQlH3iz9h4
SRsnQ0Oa8wzIcqc+75lFD9ZZv6bxy/lY+wc+VZFAWjf/k/WooJOTHsqRF+A1FaSQfhgM+5AHl95I
bZK3+wbEntJvDBDZbs4U3T3qRThFk96m+b/BqXq8C/2IQpHT9pEq0Kj6/XfwXaJEhZtDlzF48zsj
HlfMZSj7lbGeMYff/djHhgJ0AWWvq5tbhREwy04gM97CEQ0MpRvK9W8bKoN4mV1esQKBZbkjHTmd
Q3PtvRo+O+yzWiULjqj3gYjVYDZU8jctB73BsTe4PVIXCv6DgLzZvaabowW+YfvdK278IdjkT1Sg
xNv7yRTDvdpYKmZBGvG4Q3N1OVlr2dt0BAZvkqxl0wx5A/oOZRklgWOqwpw/Q7L1CoXKmKZaUaZW
LGISdqPYuy5n8V13ZXnl1HhubP+k+6Ep/lD7SCTXXtpozZX5yKRFEoOnuvzdyJ0sA4IEoO1MkXit
q1+XrwcAutc3i3rcEIbNxDPs4Ecacz40wY/UccCLDq+SNn85ob3h4O8etvz2K1ZDXUvDjFbZlaeE
joIv74xKaLMvlR1Ehp7FU2xsl6YQQB0+MA9pbsJFVKMHOHVqq5eE3GkXc2krgM4rxq0xrs6woBmp
z6rR35GF7tPPhaJDZq8arIk08txIHt2eOU5bKTX2qlOUTP7NQfMn+AodHXPS0BdxVg9TxVKtlk3P
LYhEqvllMuZZ5BL1JqQWBmx4LxiLIpjjtf0cNaol2Wlh0XHFECeW1HW23d302lBmuTbMtAkFmTHG
