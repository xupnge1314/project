<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPqRJ/UPzFiR9m6LenK+xn/U6wKXb+jY2eyL4OQLLFMjMwPqoAED60fa1QD4TlB9iSRQEfAZx
RniW0Kpo2VWjgDkanR1oU/8v6i53V4z8PD+UA9ttNHzNcb8V+QGgB+V5WndN+yBv6AguwuUhc8yD
N6Q2JBz42YQBjrT19O7NuKa+1/ejcTLTdWKCxbhy6GKeeUuFxE0rGmyH5RV9x1JwdNrMALFHEotq
Y7aBCG9CvMVjvweNXf74opx8tAyn1L2JwcXcb7vUQgjYdruA2Dg3+15RBhwisVHUSSlfnZx1vG+W
2D+ph3Tr+7pj+lij8++YBstB0yLyXSTutFlNpIrTl4jk2ofj73cpMmZhGgFhKKS5qVPEsCYqw+TM
lmEIwf7kKI1Snna+mlQX+o7Dk4h/rgZ2Eh6wy8z0Zmp9NWzsmrMunIzoTilmwa8zhjpf+oZn55IN
/wwNPxyAob85WOMywVI1coVZhbrznv7evoKslwMfK84Z0MxZ1nY4VJyCiEhyP4bBs2eQAs4llG86
1BQHm8NvA7k8y1k+4zIttYur/hmpPGfPypVXNjjwVx5L9kYqNZT87nchbn0Ze47lIKyOJCg7d9AY
X83Xo3VO+RP75k53WZ5/J+WuVCnJRlpC/GwA4rdEkmPfB+er/MFXBhmW9LwFM10ljjlvfSASXGFX
gk3OHafbH2odfxO35ogLsHnSjTioyAanQh1t4B/GYq9ZJk3DbNr+8odlO498szvw1qTXfGjsXNmp
ofhccZHMTFniuxGRYoy5FOlZcgV7DIZx4hxy3mwJe3P8jPMDev/bFG/ewF6OBXIOgTtgon/vEjYO
nQVE4eu6IOVd3cAAU/HSlXIy/mumAAcl5fO7lJfgs300x3qGdskQZ/ZrHBybZC+ptmTm0UJaaIFD
/nAEhhq3CDMkjb8kv0BG0S6bSn9oCvNQSv8AzswfKT1l27EvK1gbFY2wyrxkaNAOY71lxOwWLrGI
r5V/i8AWQ9i+uH/Df23nXdIbscJ2fbVl9/kvpGmFKGE7ZR8zC8jUgHgzJ4jVX/X40C2EkoAcVW9v
e86gpVUKrhjdgIyDJtjQvNJg4oBwCOCslVexTt3tUxTHBHgqx+RqXhVtB3ht9ou8WcYz8hSThey1
WgsNacs+ULVe81j1+1NF2pffPlJNqsVSEKGf9vJ38eRMieof5lcp0Ni7GyTs0OPeZ2yba/kv3Mgh
/fY4A8nWFUE4FcXH/2VDuo1AIcqjPPKX+l+HjAdJ0bxfjLr1KhW=