<?php
public function getLicenses()
{
    return $this->loadExtension('bizext')->getLicenses();
}
