<?php
$lang->api->failLogin    = 'The login timeout, need to re login!';
$lang->api->failNoFind   = 'None of the records.';
$lang->api->failDeleted  = 'The records have been deleted';
$lang->api->failComment  = 'The comment can not empty';
