<?php
$lang->word              = new stdclass();
$lang->word->fileField   = '附件';
$lang->word->headNotice  = '该文件由禅道自动导出';
$lang->word->visitZentao = '访问禅道';
$lang->word->more        = '更多请点击';

$lang->word->notice           = new stdclass();
$lang->word->notice->noexport = '目前没有该模块的导出功能。';
