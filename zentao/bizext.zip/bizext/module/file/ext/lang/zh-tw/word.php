<?php
$lang->word              = new stdclass();
$lang->word->fileField   = '附件';
$lang->word->headNotice  = '該檔案由禪道自動導出';
$lang->word->visitZentao = '訪問禪道';
$lang->word->more        = '更多請點擊';

$lang->word->notice           = new stdclass();
$lang->word->notice->noexport = '目前沒有該模組的導出功能。';
