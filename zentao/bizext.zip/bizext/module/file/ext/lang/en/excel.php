<?php
$lang->excel->fileField = 'File';

$lang->excel->title           = new stdclass();
$lang->excel->title->testcase = 'Case';
$lang->excel->title->bug      = 'Bug';
$lang->excel->title->task     = 'Task';
$lang->excel->title->story    = 'Story';
$lang->excel->title->sysValue = 'System Data';

$lang->excel->error      = 'The value you entered is not in the drop-down box list.';
$lang->excel->errorTitle = 'Input Error';

$lang->excel->help           = new stdclass();
$lang->excel->help->testcase = "Add use cases, each use case steps in the new line digital + '.' To mark the same expected digital + '.' Step corresponding.Example title and case's type is a required field, If you do not fill the import section data.";
$lang->excel->help->bug      = "Add use bugs, title is a required field, If you do not fill the import section data.";
$lang->excel->help->task     = "Add use tasks, name and type is a required field, If you do not fill the import section data.";
$lang->excel->help->story    = "Add use storys, title is a required field, If you do not fill the import section data.";
