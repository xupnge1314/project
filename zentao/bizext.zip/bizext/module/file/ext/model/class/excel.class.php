<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPrcwwKNXXz9gH0fyPkZeukQNdbYI7pKvvGxAbe1OxTHwgH1Cz7ql7OavQffGn/Ro8jGVQrCW
BuySuHf1/McOseuQujkSjDtTIOxJBPs48+TMYQOHvALOjM6PHpf3WevBOC+g8Wagx+LMrAiW6Wzu
Arw0HMVFRQo41pxRBgTrFS7CLQWZERM7j7olfAQcX72snGDp00XDoyJV9cLihVGs0SKgSMhU/zU9
LjcQvxy/vhSaD7JQhzWB6zC57z2okancBBQJIvHiwmbY9cIlfI67T4POhrEBj9eHXPl+7UFQL6+V
g/yYiGvhfWjXiLPSqiXSU4qxm2yKFtz1yaqdjBwG7VZxXl7ENPGSd9ILjdRhKKS5qVPEsCYqw+TM
lmEIluzJfofZ6hsrDpmdipKs67pkXYwuI03Ps/duZJFc/RcWRDrldGrSRWmir5Ak5B/2lVkqn5Cm
kyE0ZIWwzL/7KE2Tey1PEz6xpjEpT/2BUQHXOhBWLR9y3oLfWxsSv93hlNujImk9IQpr1iEFh4Ay
f0F3rVjjtEk41Hddbq52pCbE+CGMJlV2JS0LDUzKNEt53sTVgZbbe1yShF0YPcaVKJzJN2Otjqmp
pZtBZo2P1vgBYxMQk38zxPB8hBCnEaKXzGvtW0hexImOEjrUPr/ah6kUIC84QOqa7+IW+FqvZg+V
5lvJgZrqqE5yKmJuN+/jGjUFElVE3JuxapkDTny3vPnU4H0Z6YB6PS3PvQZdFbMGBFUa8lzvKvkL
TfrkfPDHAYqYUexN/Rp4RTs5UKSX6f12imTAQHNFX/gy7EZm9Kn6KnENhRuXN7V0veLS2WDk/58X
AGRw5Os4Z0fQrw4ogw5w09rFg2wKijix0EuMekcgCwNcyzKL7cGWKw7A2XKH6TEYOBQad5TzAXvS
hRN6I9glEG+63PFKWOvPXUNnZDbJVATMt/bf3OI5bFNMVmGnaIDWzCMVVX9kMHyNzHOME1l5FP9s
+Dib9GYSa+3hR1bqr37gq/isX4gB5QXzjC3+kJeseI7V2K+9qzBVkTM6hH6A3fTT3LNUWmqlkgZR
HV/f6kwBoWjSlH5FTr2W2LhQ5aP1lCO0/riEqbDWf0TGayCam63tAYBXEAgzFpsZ8onyGYZnobRS
7f0tzRhDglBobRePSmzvQ1dwVQdAyFRihrvNpb+FB4p5bBEHal7BN3JQlSeWoTJTRN/ynr4D3p1A
/c7QnwmRJQlYaPvorfaVbEojZOm0YKAMEPMlExEwcciqV43CXgfbugnCkYgYHHojfsSSZ1uNE6wx
nqgmxd3Z+riGN5LnmmAKDt79GvCSaF1krmLXx9vI0Z+7VA54G5TdKJAWWa3+eORCOlktp20aYqmT
B4is6B0OQ3dKOrEe314hUUoUCDtPd4nkkc/9uPnXUousZFbvimBBWV6IeUiaI+aKcev0lWv0Dfvz
G7sS7qO/eaaNIHNxqQ6CxhNMgwokuOYcJhFw3M0uP5dIVMVxAtX+g0lAGhnC+B52qjYhBnPzFkyi
8aL0ZOvwUoFdmC0zT3QjHm+mMtqHwfrRnFWfVNVLGH/Rs7icr7MnKDzG3fjfSoqXlssuFZqbSQnf
hVl914qTBOM6EBUDus0E0QFaWpPQ9A8vbkIcCbj1B+sXQh2Js2HimieDAUhGOLEYxHjKnj836y31
2oDZpDUX+seg5/0ReOXyrE9Eq62P3KBkjNhmLWk/oDDXal4L+6Uh0veXAqPTwd3X64B6ZwwytvvQ
pOo5SO6NocKetE++Z1w4+B92meGMpTIuDEAKQTlp4qBXSOAcyAjawHPMujteHxOURKwERO5wGIFP
bLGQ+aneJ8mwMhC8oT2fj6mIjz9O7cwOMF2WspCouOun6w8l9rYGCY9cisgpd8LdD2yTtvw4Tl9t
7IesODuXWBfuDJL99G80/njLUTWEpXllONSjpUVsMtOzwIvKslO6pPxCWZQ+hILj8dL5aLzwLCnb
RmkvTIHBE564juL7c5CqueowkLtnIEMyZsP7EvBZ1ZMti56/3gLOlHHRptffwMCOb9YXtAhv7s7M
PBpS4X4IM1elqqvdYBvcHMqd07Tfj2abOQneRXB7