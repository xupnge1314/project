<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cP/j1xCeKhzJjMV9vwIia9L6Ykp1x1G8vibpDqQCXk8i2/582tC0f3pD5/hFHmgu6/u3DmuTm
8lf0IXwn1K+jKK/WbGrMrHZPS0qcwWfROmOjvLbHvDl0jmbBCV6GPHunK/4l+InTFcKq8jcHzBhU
q5Nq8ON1lRQcWLANAOHopvitqPn+ZRvGH41ZE6CBam4K1T3rK9J43STCkik7dWsN+0rgJcBs/q0M
ekUFYgAkRs7Bp9/CqFmvpqIjZoXhC71wpIjZfFcMy/xsW8N6E4GMnSJaU9ibdzJGey3YWA1yGkgR
FKuP4kjvLBRFFm1lT4XMGmqbWCQoZ8Ts0R9P8/Q17GsnvOXUjwLIiFXvkJ3hKKS5qVPEsCYqw+TM
lmEIE92TtLAR3zn+gkmXitvIjJMyttyty6q2kzv9DY2HX4iEirx0TsWNNsoSqo3roLDJ13cDrQC7
17fTCNyUgXCzg6GHejhhfrr9dtmp8fyG8js0WssD9bThklHQXtzIKYPrbrR7pViqsRBF1Vy4dKZT
RgrGjKlbzH8q939vRDh7HLTylzvk1IFQjQDlaTz3A4oyEQoooEP4AqvVJnIhGJjjCrq8Z8bYpd8Y
H2Z2PRjPRuCT0vBfKzkOKedXl+39LzDeh3RwUW6FZinSTwwx/9ILKKL2xALh0ybbSbMfwb+dbaln
c9OTMqf5M5aKIRjx68O2bj8F9BBdcX/TNI9Ehbhz9HSBd0/OvDmJ1g5eceF1KlrU1oUn8XzhyDvA
fzpqwwUTB1GoIctGNhIigtB/up+64VzN7MqVWcqYnc/UkVBkPsgpFhyxv8pZ8hsAOSezmktk9VhJ
1OBAdSM0jbg0gdl37EKiHkmJttK7CyrOR1DUvAgmZyvC64KUmJ8I16glXrVr3Lm7b+vrZEgdXpac
5z91vrZ+/K8mhPRsWB75QJdtOt9AjVcC4zZZj9JLOhXE2RxVHQ88Dew80EKXoO+ZdkD/Li2+8ziX
ACD5/QYiqSITt+7iZKBj1c84l2utegt6hu2mFfbapNUamBuvGBSBHaeGd0N49xzhOzGvxR8eFpAI
VO9SG1ZBuTH1mnG057IVsGJPrRrZRa/QX3fZ8PPpluQv0ocrk2YcX8uJ7tJJI5zviKuzBjYZbLq5
snz910y0gsv881uC2XoDtkmgyl6MYgB92PEemJbphxTCFt6eouJcfOtv9BL6ponTbA5SDqthf/FB
/THd52KD1Qbntdn8nMiXcyzgs8OpUUd6ETo1xKvR6MfDIFp5V+NT8nFBZEt7X84CjW/gXPLjxurs
fnnE7E6Fw/Sq6UU5J3AVHtGZ63a5VuOxB+WqCQvzfqdAVA1aMQhdtd4OSOm9e6cF2Leqap4AFvuX
JNJ3WHjVFb8mUEtuP1EMsA9SNxB6gBAxSr09w1msUE8Hsr8/I1B1xaOH4bJEmNmEFV5xfTXnMhWh
066p/bCefq7xW3P7lULmvH/tuERFKohZQvj/rZYJdYJaJ3TToT27nhhOThk+VfEJ2nShQCeDoG+J
mT004K+CoG33N73i1ZbUjujp7xwDJfyrZIJb00dMTlLsFRb/MzjBn8HCyeR/R5ZlCYyXiXw6/O8Q
YP2vj9YT1wuOKA9LImr64hKde8JrwvaOJm/a1CyLraWW1U9pnbotd/QcnUMb75qF9dIGjTHfzc3h
yBK3lGHUObBS+T9Le4kjpb0IcqeK3nuw0dCn4sJY34VWEzyoBZyz4CdarhVw+z6nlBHBf0MGsaT3
l91vfVsqk8WAShnWzr0aOiLSDfysIKMnxWiDEILbrdhbMJLTNHj7TVzuJUxuPqx51fcxVVhosuCO
WVO7LHLYzbGaihZzPaJTTRpVlqjcHbcdMilcVCejxBRodikWecrHslNUzIqZyy9l9bCWj2suMei7
dGL0+TYPE77S8XhpUuaH8LEIMtMutz6moAI07YJw5XmfBW32gwiueQFbVRwqTMbqelMNPQtArEEM
lfPC9AtCUovJiZc5fruJcjtCnY00IEsPjIEBDGA9O0HNaSHbd2BbvDuQfCkUx49OWjW+5a3JV4Qr
tPwPrw4WGCuE6Xyo6+fw3WJXGGxiiZRjcnwcfB6ffZgn5gtbbe70HYuEMVzNZPhhvlhLSr9blQyo
xjIeun0tTBWwcr4HoTubxFY3Ey0BfMsHVCzWBs+8ZNziAe7bHq+UfbJbVGAbTWihxjqGbZh/jcab
TNTOQX9K8Wu38OeKdAR1O2HP3VuNrAcphd2kPrYMngguuJHdUEXdBv9vMEE1oiSYniSVkb6ojBIN
CHEfLryRPZT3k0fjQRKLfwOV1GQrMj3b5SPpEZsvWezidRnOBItrNXaIYcYhaKuj4iOg9L6hC7dn
3Gzhk8nq0WKMFQ4qG3wOvW18EML4qqN5Ws1ordIRhdOYYvJEIWtrxAhEB95rQJLEZMD02A24D53E
FIOn1bi7V1GJMkJvGDhl7fxtXQdIiilP/XbwoKv7JCcayfJuOopCGC9osYl+QIlLL+UiItelT5N4
VLxbkL3cQZfefeWJLR0Rc4HrWh88pU6Y3ISXEimp+TgT9g4r21/cQBVnQL7U0/UWgDk4qJ4N4bSu
YqkVTxiaFkBv+FzVZKX5O1tVnISklD0iS1UHk/LOU+KIdrMklZdIQrxAwM9XUklz1AsIJ8+eJHuJ
9uBjK5bh/Dl4YyERvk2Bq0NCBn3/hWRh/RXKDamCXbBJGY61hASvPYnuq7jOD1BVpP059S/vnXMC
5Jza0p+T/blG8iZhOZ1c4PeWSo8xRk80hclPilkP5OtzWmQrw06p5kRcUeYA4NtC3aTRCjftlPOO
1+820LeMnroEvBKdjasBK6w6lmkpoiz44CLhsO8HrnMrqygpD0UrWQU4OI2uqXkB6qrcsbPQNiEF
OuFxdbN2+3bYN0hU49lYqHK8sP9OrE8E+Atay5aWMOZH8Gb/1E/RofgGPBC2FnP0l/u3kAuiy/Ip
p2nfBUjco9urgeRBaC4UPU+5fDjuoDK2/xidQlbgIz+kOgrJxhEakC6XLG==