<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPx340XiTclTSO0cNE2CkkDq3KzqrHm/RICIZH1wr+9hAzc+3e5pUKzEHr+wclOkAP6H3sUN2
buUN12FwmRsxNhjndF9IK1cRa9IAstHAjKE86yje8/Y6Z47a9mvKW6AbuIV68p+a6XNboYdV4cXC
2KrT8FwzA/e1QqOFPKZXsOPIFn/aAT+0VRL+/ZDQMLXuESxxY50VXCK+DWxvncuABrXDl+8J+fH+
3CWDuQjInsTRXgcowZdVAHiX3MdsMyiLvxVXQM2aoh9f/w8/X97sPcux9RmMeaPkOARqZ8RVRbMv
ytvaRcLnCf5ZIPTsGxS+gmfbmrhxpEE/v7DzqAsOos+uWzodKRerxNT9AC3hKKS5qVPEsCYqw+TM
lmEIy91ElL5pZApXaVA0w/h7k2gn4lR9BzX6bg21HDo7ukZPlE93zNRHguBSFz3tLsseg+DmQV6b
6ApsbPquRGK/9JJEYJ7iK4Tz6hhJZy7nfcXlUsmcbZw+OxppVQW4ohU00UFJz9CTrO9Q1fT7VO/P
dpNPvRB2fphcl7W9oDQ2lkxgjdEigomXp7Br+U8hS0BtwEvnErMCKDuTpFSLcNvnE0rxyeq4h71L
6wWS0uJRDfYxdgBwu8nyUsT8A0cvGCcXUBD+YfnnJN0qQq2HeFrGFKRjvwjGSwvX573+f2QG3hR8
HYB/cLIMQK+80F1arnOkxu9GEJXjC6CEuwCfLcZi35SIXVKPbyXUecUgocGNO7TcJR+cMFz2gCev
CkuldEhn5k4c4gUFo8YGwx4t3hETvQH70tTzJjQpIWToxGWOSSTuCAV9GZYalIBgNAeq4bh5wMlO
4jcNumLp+iK34srttJ39a6s374z3j8U+RymLwpqK5dWiM/CgLYKo7rTSQwjKs89E3KkdHuqsLnGY
Bcvh9dVuimDfVgRxQIo2KAd7yaXLjin7NQxqHDt+MHbUstNOsTWLUypPWezcuLAbVir9agfwhX87
9xcre+mfrp5KB93FsuYtzZ4vs/Pd6Bd1gRCEc9qcnvwoSbGYNU1zOhof7rIoDW0e93DjuDqWgTLU
7d0jdv3xON1MxYyOK3ceId18EYELe81p/yk2JN7N6QZIJHNup8l71JOf2KUGXLSE0w6H5ZaKamgn
w7/AEztgprK6hYJL/+Nuqe9+9spCQA0o889daoBTDPMO/J2XM1C/I/Y+3O6XtR+ZskI5fsi3ahaX
zUkONClVLtURGN9g9NfT5T4S8hancgWRdZfL/sqf2EkQ/zdTVrOb7gvqEkyiLBzfIgjt2c8Q7EU8
UF4jsIKg/jK0zHVd/LRuWaLdko1IYMr5osltUF7QKasvreJQ2QuxZkVUcoxvDIujPe8Y0xB9w62U
2EZFLzqkd+oRGMz0GqXOfHtLPHMcVS0qHvFtAdC0xwBiNuHXe0slymGGxxDrmu+FFN/80nZ3AVdJ
CHvk39OMcvBPm48467T4Y2HteQFCX2iiGkz9ZaWBjrjrMGeqhSNS16arq7/yhoSv2/BesuGLf+Ab
EpxwI0Arj20WRhZWNMw5EbQWtoKv+1z1X9qDxVKD1rBBZSf9s/1kP0f3Bj67fHorLo6jv8akIPoZ
XKl7vP559ssv3/PU+997AXzUF+6mFhCUObvQxS9kCVL5pxTj+K6E6uoHi/kdKUH3Bs5brsng+Rci
ExPetgVuV/EkdPRKKTfG98OYmDHvc54g7J1PEpd4wc5aeGwswnDxkQNob9SrtvWQl73gMNQEYhiu
7HFRG/MxNmcTEwcAuBA6pphdCvAkPBTQFbawYTvLDAH7e4BSsscbCOKSRvR8BysuM2Eqz64Pm3tJ
98BXytgaFN4JxIEt4/tRpRQePsq/TLL/Wou+J2iaTz8e8OpS1b01QtsF6l2A5T7lCxp+otOeVy6o
gYYfoxmNOOnfhjdKWTD1BU5Ux6YFIH1FNoj2YUjnU6hie8DutcJib3hBPjGsmdGShUyXyxihay4A
c4+pVSnmjwO2RoONGk2FzRJh1d53XPQ3YvGvSrgw8DuxjjLeNd+NwcaxCdqMKVTWW1QkI6Qdx1fC
ca+dxTQ+uCtNdJZz1LI9eb9QdTz5L9ZEJNlJZWK5XR5uk+Z7xM+R/VZQyHrYWWUGHL4cG8iY+1A0
Eg+cIferJlB/feGRJiaOlgUDC5p9taSF3I2N2yDfe6M5P0+epemWnKzbUm3HkjX1d3OjYAWXDNby
TkzuIZBkEFhlnqa6jOxy8BLe7+86VtFGeecZnfLT1nIbrYxynWGz93ZWIYPtV/SabfTRZuUyP9ik
8FYYhF17vri+9cklOycm/F9/Z3k74T86Rj7Udwo8/9EwcblhuDVG/PdEUgEbt37ebwn/+cm89MYc
p6DBlBgzli1M7TDxMhFq/5wvaqXsOZtg1FSdoePTO26KfhfEzXRFegTZo4VmdX9tqqlgj87UCcuK
OuY1krT4AZgOCBESuF7BizTS8PZTmlogLJ977Wpqjt7BOlDmxR8Oy05OSGliMfwYa0unjEvAHvC+
GEtaoYTpj5Q3pY3FMKOlxbZBnUg0elBjojLXMI82sPA10I2b4PYLcVIIfahP7Ah2TNoL5slEiiuk
PzNJ1+Tus0pbvz+xKexd6e7V7o1kXTm60Gkp1b4PFviGk/HRLI0JKQ1dbYBjzI9YBQx18v/D5Krz
zzN+Fmz1VS9PKH2jjKQAfCBnHUoWhQ15QfnT2uCg9G7NrJwUsOfuNaKpfmQdIjQzLB4f6N7ccZvh
SRQpTObFCMXB2401qXZ1wqYS+PKF43SWsKGDDyo1rQgrtbTQZW5AqHvXq02R4UkazQHrrqnoeoWf
IygMkcKSjGM+ZJ0S+qNnHRB9HtbDJF//y9IBNGIzHrVyqfEcjFZmENZl7Vm/PxeSaAAJ7DrUZzW1
7KgwDT0If9+rrVAt/pwd/K9wwCTiSTDFLCwsJQs/dLNp9TflsyUgdhPaonm7yMRC92gL/sothlpZ
cTsbmmv1zLml5PHrCTqSZhAYJg+S6V+9RyBNozuOJEfDXdaZVLL5RrNCkrq2b/MyR31kRBOAWyAO
ToA/5PnfudUM7VNl+eZg16nAB2dKbLMrPSLlktpH5antX+ULY8afYRp/4u7/cn1JpYSYpn+JYY2J
kxJX9foQMmGCf8Sv58ZNHGJpztdu5LV4mJUWg2W4WDTYRt1Qm3Q9q2p7d/3O+Mnrra5Mp6M+ISBB
jkacdXBqsh1b1OJ9WHppnYz+dCi8SWZBd7aZcgB+UdSg8tqCA7aVDNVEMpzdMT6Yt/Btvr17iGr6
oYJOgi56VhdNi9Zt4i8HtauZ3GOJoaQ0Aq9jCYScpRl8B0Bjr7tqbVFPUn0PxJSNYfMgRWNH1S9L
CcWDi5ErRVKlCBzxu2v1EumNryhSEgx1XiwPL5RbA8uUp+E/sgqMcR59HC8i7nYvUS2IwQjlsUV4
GZ9VgtUIH7rUW3AnSgZ76GxsR+Soxlykw76vCvP4MZ9BrDXXkYBPjJOa3312gQMwwsoxARoZbmRj
Lcc4RoyA7qb2M0m4fvpGe0elotSi11CqPcaEEpYG9rj8eKQpwzgXJuQuRA4xRG==