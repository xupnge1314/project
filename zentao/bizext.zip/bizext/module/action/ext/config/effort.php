<?php
 $config->action->objectNameFields['effort'] = 'work';
