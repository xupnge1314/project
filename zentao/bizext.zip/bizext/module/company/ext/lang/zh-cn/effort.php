<?php
if(!isset($lang->company->effort))$lang->company->effort = new stdclass();
$lang->company->effort->common        = '组织日志';
$lang->company->effort->selectDate    = '日期';
$lang->company->effort->projectSelect = $lang->projectCommon;
$lang->company->effort->productSelect = $lang->productCommon;
$lang->company->effort->userSelect    = '用户';
$lang->company->effort->timeStat      = '本页总消耗%01.1f小时';

$lang->company->companyEffort = '组织日志';
