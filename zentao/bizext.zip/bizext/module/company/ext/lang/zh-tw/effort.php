<?php
if(!isset($lang->company->effort))$lang->company->effort = new stdclass();
$lang->company->effort->common        = '組織日誌';
$lang->company->effort->selectDate    = '日期';
$lang->company->effort->projectSelect = $lang->projectCommon;
$lang->company->effort->productSelect = $lang->productCommon;
$lang->company->effort->userSelect    = '用戶';
$lang->company->effort->timeStat      = '本頁總消耗%01.1f小時';

$lang->company->companyEffort = '組織日誌';
