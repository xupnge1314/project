<?php
$lang->bug->importCase    = 'Bug导入';
$lang->bug->import        = '导入';
$lang->bug->exportTemplet = '导出模板';
$lang->bug->showImport    = '显示导入内容';

$lang->bug->new = '新增';

$lang->bug->num = 'Bug记录数：';
