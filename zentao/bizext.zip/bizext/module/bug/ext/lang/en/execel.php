<?php
$lang->bug->importCase    = 'Bug import';
$lang->bug->import        = 'Import';
$lang->bug->exportTemplet = 'Exprot templet';
$lang->bug->showImport    = 'Show import content';

$lang->bug->new = 'New';

$lang->bug->num = 'The number of bugs';
