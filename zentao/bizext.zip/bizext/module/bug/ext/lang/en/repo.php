<?php
unset($lang->bug->typeList['others']);
$lang->bug->typeList['codeimprovement'] = 'Code improvement';
$lang->bug->typeList['others']          = 'Others';
