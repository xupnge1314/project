<?php
unset($lang->bug->typeList['others']);
$lang->bug->typeList['codeimprovement'] = '代碼改進';
$lang->bug->typeList['others']          = '其他';
