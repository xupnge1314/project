<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPmfL5jECyEhayPo3y6hpxO+3AzQyTR/xiEQAiI8h7TIjIPYmeruTwHUKuSbFk0paGn6yFmnx
28ZHvNjs92YhGOI1r+sELtC6XEcIhBHp4W/U0pIof3v0T3/RY9dlXo09rV8LYEnQKaCcshIxVj0l
k9hdPH0eroP74ZeJQXmfNVKM01oDAUr6ogbK79EnodH9GfVPoJDdJrkluloiAnppcjNm5uZIYtLv
3kUCwdrzuo7mGxJ2LJ7qznQWFS6RxccUHVfzjmHYKJ2pH6Y3exyI8FDT0Pw6KaLPnpRTc+wR+kTA
T6VbBBiLIdmvqXbS2ltXeDJJLFo0DgEjNBogB6iaEqf/8pxV+dQWkUDPW+jHHmNHzaxOoBJhvrQ/
0v9iaPry/q9yUNuU6ue3gCYuHFF40HUGAVezjr4Td9DBo6ejD/ctUbJy2+th9VWv2N6ksP84ciQW
mx50s9O2moXIIvr+gosErsRptAlH/hvBgZZLksBRg9wtqt3M5lVUzDz8vYlrGqws3iKhnz/C0Qg6
0fWsq+A8WC+A8vC9WYhu3NQO+DNBjFJ/2JcALXKHSWn0IjG8ypHZ+JNgwfETwxPwRKH0eQeqCrg2
D6utInquxj3TN6glqdvxJNhXl2KrpDPPKCd5tRBdieBws4r+nWUsRbStz+0Zehx2sdGFE31yUwmu
c0e6fb0m/+bdRxYLx680UkZNIqoFc68kxOVecdbTdAuTzgI42NGBM3jvY7mwxfAPObPrgNeofYTC
pqBGOy9Y7BVMOm3JNQBlyOvseyJNYVuIyEbYforG0YkH6ClWGdcjxnS5xomAHMNjrHhW3wauQgSB
mBThls/vQY4GJPNb6EA4db9hS8GtFhqp1jyEBF7Wyp9ze+Hu3KEErb6bfxuB/HrflzYXqGcZv+/l
YnVm30VHQ/30lLpyXBaJyhdC0G+qBVhs36TgUYqcBILPTNDzvpVZsWsfNEWn03QNoQcL9rDKBv1J
5P4gKWhJkKU8Cm27kZQuU4mVDGab7/FClbeq6F3QJ9f9R+s1LDPfVWrptG8pOORB1Sqja07fgZwF
Ku2FS7fTlTXAX4VAoBLUmLHhr5EnAa0datvYrcC4oEjzFV3kQvDeY6PoBxjyEm+gntKsacexGfJ5
rC5hsQRwof0Xg8+nTpDNmKSXO2S3Img/XVZZsys68uDExvs5VSUJbC2k8h9EdnCQ8PXWQNBfniqF
vlGo/hn/4QMHJf28dYcM5mzsfTEN8lH0TxkVsUyNUfL5woB/RY04FHHkoIm2HziT4gBmG8GCySPu
YjI9UL+UYogOV/nnvBvUwdIu+eDE/ZRrcv0YEs/TMXP3UvcdJMtKeOdomaOw4r4WteiNkGU2FxJZ
k9B9RU/jvAd9oIMakZE2SsKeFz/f6MtHRjCVlYpfVdeVaj4YgarjxSaXGw0R0GY6koL94q2Qjwpc
paBdHdKS2LYtcAVIHGoE3+7rv/leqDSkl015EC8p3xIbgq70Q1e+omQaLY2CnG+m8aNmLImIhuSl
YWDUB6fch5loBCJwjl5BsRsTMxNeInrX72fld1YV1DuO/Uur4FwbRrjEEAZ+xLWz1wA3nM3m5NJV
yt/1t0Qo/6W1+YLmisy1mATy0o7s0DjrvINZgo4+8cox885kmIF5h4I/rCD9dO/I282M3wzW5Xxv
WUzpswQD1bPfxsFSPBgRS/D6FfO70n+hf4cqWS9gpLcn5fQpTTpeQztU4wJU48aOZtCPWHoCvo/G
82kU3oNwWYuI5to8WygiDxMnoFnRxC9STh2WB2pxJkuXDVzDLc5dg2cvesJUbhv/RoPtUxllA6Zv
lPpK/L97XIcsTrRB/7EciDhS3rNHKCaCaodUGa5HqFWiA9ADu8GqEwRlheNlpfDq5Q7+pYZboa23
Mjj/MrrO2hiCPY7cLdrJPjBYU32xAmT2WYIlAaSmgTrXanqs1wnGk0afMwE3pkZ+i1NlCCcSXDiM
ZYtVS6BDQUqJhK5BYzJ0x3eQ8YIpg/Fk0XeFbM00omY1e8ulplq/6tm1sPy6/0t+rcX/iVk45st4
JEJNtJ8J3yKv2nx9HM2Uq5se3Iy7lTUTmV4f9vcl89XuLVbBKuL3zXd1CDtxuq73gXqO9aLYJPlx
7jNqjh00/p41H7gP+bMOFfUwUwGt8kcpU8KjN/Vsv6HSCKsdufkI0tP9VthaeSrayyDKyIP95R+K
6XDrW4hIrFi+Y3rQJZq03Yb9EcHPjHTlK+gowvHgyGDHQFDAlbhdwVbI2APZkuaT5rQ4fgMIMubT
+IFgPNSVQew1AmCUzrYMpkZM/yuZROn5MtxYYaLrFiMeeihNkwGQchGisCIRa4ds1TexcG+zSVIj
VYGstmxyrpQ57rxDwHbh49ef1x5AOEHkvd5Z+9evyIyUQthnyihfEB92J8zS6fmWl4gCejI9FHyL
PcKY8VXhrql+BFUcp2rzEQO783Z8o+AdffIa9ozoEqgZma87hnd+VOqO0e98OlV/RxtqiKfqtQfI
SUr6VNrMzLp96BvzraxEPxiQ253g9AvFWMkowZe/Q0YgpNZy+QKt/bbOlXwPzoAJ1TmalhnTr2jQ
CahmqE7MpNWD4LroObl0TQZfPM6Nm/Ju1rvQ9ziUktqOBYQNE5Gq3HgW97VZLqt5yhCjngHxgH1C
MGleEKJObVttjev8jQ+XNucnd9O5XW0QUGpJsiBc6ZNnfsSDI3Jy8ZKKNZj2uuLdEW6R4ao5VE/o
03Cpg7aLiV9CeuNfWRd5dCSz1V+rIOBZ75uW0O5wsJQP4e+J22HrTuJJaE8DQ0VfXMe1XSsLXJw4
60X86VqViBoi6FzSRRxk9mD1Uai8tJGbRkK8NExxbQwu/OY7hzIXPBb8kpR3sbYyXuN0ObWqfUkL
l8/pH+yc6upBiet6C3Ur3CueZMRDdywf/aUwu/J2nE6yYDOeTfRavibP6EgGtIz+hoTfhqp150RK
v2ncKc3k/6mfk4Ol5rIf0ASo9Tvu2Ptc//Joj1Lj2qszK3dWMwEOw1sf+EvP71qctPFX9vqkCuhz
1eLkr+jhvocxHOWSba9wVxQ+mijs1FN3fXufKJEgeC97ukV0ua5Rdishsvu4psrkfgR40aU2wc9n
53e+VD9PdfY8KwODllPegUi46QLrRTJCtvYuapKgsjINp38ilNHcO9TENUx+EspF6NVRG4rUb6z/
FWfZMzuEq9K6ul9CwXMGvN41lqqrUKSBV9tHjM3rzbaYtU+sLTwF20nuVybtofC/DkNA5xmJFyDl
J98Pc2KnwlWb6eFHiRJqRT8NUL0XFeQxPWiKfaZ2CMJWsEpCk8Q6K9AHZ3UJfuKZFnfijkySRmm0
tr/w8QkIuR+6SezskeWI90bDuY5yoHKUXiKXTjoJEAPTbnsDaHVWq3LyLvyazSPyK2ZWDtS0okfY
RbT+alDkV5r442wEXqlx7CxSGEPoY271JAbSSC8OXYiIaVWN04o1p8W14AEE4HHbpPTAbOtBdGDk
XorKUjwI62XTVxmJ4VNQ41oFg1kbEnpH0fGYsLmt9KGkl1IcxvmBOJASuRp7XU3KxpPheU/D6+FY
yfZ6DWyF460KV4ihCcAFSNUJMaxYjjJbZS6rBiOlN6nlXzPGDgvR5GThflkr7PNBYPEnr/xw1boX
7GJvvWzIBfPLTk8rdNb4nWLg+wvefCi4umIx5mlEEpHk7RHyTZ08y7ItMAuUUIgSCsXlRqyWE+hj
fDNauzAC1X3+snBc2D8K0nNKTQ9EOPgFnMi/hvHd4qt9D9m9fXy5ptQf55p6KawIv8XDo0TGEN0K
qom8cV5RrLq3qIKW2ogz0P3t98afOWcpwoIJ7umNuDf0I921iF9kQlS4WjDByf/9QWiYwEoRR7dy
OnCp+OgBduiBGKsmBjMbwW1VCA0UUPS7nI7h7scfcbozeqM4adTS/ZtPcWlBuoqQ8TqwWI8LqxVo
TnGYVgaIsiPQQKMVwnurKgs0YveRi44VCGRJy8KDbQLQwzyj7JCBmvVH0nqm+0GRwgTS2y9VSWFe
DWM5eS6156jK7wCqCyI3sARTb7wOJXrKzsvPjnN4KM6G0VlCdYA7Cq3fixqOonznvJg0IfSwnUK7
UHTyZTvKFurHCevRfSzxSxql6fhfymYaxtK/EoKDHoYpdte2wa/CLPpdMx+EbBfRfNy3gK7DvONx
GmwHEVEkG6/hpfwkjM1xCXS7FhaZ9l6C6zVrGY8azoAjSCeZpkwqvWMNgKOHwFUzvDN0GfaxkN0P
NphkMYVQWYTN13JENv2NxqmIVUJgW5uv9GYAbE/WCRWSEbiqZ4Tcn0q5989u5hrkGtC4o7Mn5la9
XJtnhpZQhcO+vzlHhNH7Gzmgf6kfV74pA+dz8nDB73JYy2rV7HKTRLNQW+nVe8sKE4iSVr4hdLbP
alob+otirJEAhH+f4ZCcMqQe9m/ynzQFofOQRbz55Ys3JjJQHm2o3xE+jrR9lyO4OsTtFQ4gaKNJ
wt6X+ywHYtMo5TzRSOlExnfAH4IVTa1u4Wj/Qpe5TeI50+CM+DooNowZ5XCQoJHv+KWB5eR0G5gi
2uTorQiVAi1V/vn9RWXPpn/z5jYG8NKQiPKbNED19t6AIlQHG3DDwF9Nps0Yremev3rLmLC9y6ga
bZqsptgZ5w1ejGPSKJ9CeG6v7r0sMCoTE1Ug/DOU9Aj9yKxxhnJQIwPDKUm6P4vkO6yRFssDORwy
QEA4KDBH2LDeY2onZ4eSnC1hPEAzbiqn3AfO8paEaH5Q7mm3ik0Fiimp6KBUarFSxr2k6SrrILQj
xTiTb43RijktVFQxKXqIZsBIqVO++xFxgly7z6eGf/SSJ93Hcp3wd0M0lRdsgb6MKIK+GT7LU3dn
CliiPuIV7QPhOk+uzHGxiS0Z+tnHXqvIydO4K1miEzfs4k/4DMKNYG5ehLSht8ZHUsin716eN3RR
5VeGQa2tQuKui0==