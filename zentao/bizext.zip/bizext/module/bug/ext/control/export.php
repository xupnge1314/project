<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPw7mHpRxKBmvEZ/I5NRJ8kaJWCG+vtAr7KVP5bR95Px8a7vgoPXdj2hvlmcLFiib9HxSQAkO
DLc8VFuhbyTzsX/tQaKZSTh1sEgsidZvIm+mMYQxIJ/LTkvloznAhQVwjZLRHk6vnKU8L+hLKWVK
dl2V8fwyfgFCc4MvDFiiYMqBFdzKlALPSB+ntQFVwm0sv8fI6WJ/aHV1T54YMx1LL8Rv/fpC1xhl
T56JJZKVUETigk0z67Egu8NMx3Sfg+eUHJXAs/Ed05kZh7u6POyOoL31gHCsLJcWgDJAdnwHAKBq
MGF/K1pz5m2oiS3nCMqG0+RmEOworv09gchNKVcC7NPjHONIS5egcltqlURhKKS5qVPEsCYqw+TM
lmEIkPC9ogGgWBX4lDp30pJDk0LWxzn3MVIDrheEtHrLSpq38h1mHXJcz8bn74TycFNLvokcIh4O
HxyxmaLApc2JO8HTPbFqksZDavDJvnlJYrWXgs+iWh53cf6xBa+kmuIaZ7QdZiF/6B1/kaiHAEWj
hWqvXNaUPZwBeU/N8BSVXYXzD2yWryje8hNZljNznqrTRQGaLlX+2Nf7yPZ+gIzLu86KLg8djR/7
N9S2WqdkaO5Yxs6vAo4MNDPLVpY879FBzJhQOpaMW/xIuT0WtBIp1YiosOG6MXgPJGNblfwk5ZUx
7U+fRxRjSbxv6fYjn43hSKrUu+LTqysaqenrMnF8tVrp9IRGXFh9Pqcl/0i/5Pp+ggB1D7FKI5B9
VI3jRpFyu3TtSb9ogMNiUn3R+3PyJSUj9Axkxaufkl7lExMODhNd+S+r5214yzQB7lWz8E4QPpPw
9UrfBIRY+7QYEgXDeNSDNw6ruo4GqEz2Y2PsJifqxgzq2eP8EV1shEGJHPVCQFpZlaM9qLiNYEHV
mNv4ztzUHTcOp5ncLeY/3vEuH+SOWIyV0Ytyht301qWgGkNmd1Uy/ShwuzMM8aKWD9R1BrsdOlO9
HoMx03/FKdKHfuBjmXQN5w7hrVGsocLzsMzrlVmkRhcT78ySoh/c759elGzmYN1ZcQMveQWicPjj
QHDuzhQnxLYMM8A53vCq967zHy5SP3JUJX5WG1f0QHXF/v0hmo0j6pXXV+XyGA1YL242N8qL2b8B
KOG/SHHsXURwC0gZYzrXjn7ffzpx0PMhvcoB/pdJiSf24g2RmUKRbdubM+n1ZjMVrgvxB41kO/Nk
/7U875L99Q1/yIqDLqph3NaI4tC6aV5PAf50ZGB0Ry7lavdN06Vou2IELJsFId0kuFrdQq6XbZHP
Gv4hOrk53v13UNQCE0bV1YmNkX5Tr+OJoyghqPkJRMrkLMfZj6Q31xht6J+KJ1BP6QsygspagsSa
xfs6wpvPBsIrblMLRjIzoVY8+zMqyc4WNvoBeUbz2YH3JUVdEWnQv6dpcxKHsY/c0U1ONfI0mssf
VldzaK2ZfbdfeTQcDzulVJK2Q3VU1N1JA+aaofXzBa1lJRSN7N+7sdYAFUtO2+u2bN+gtPE6B1tz
8+2HHJ5ELnuh8pCpan552w0zPAClWOPYFnXl1epYKTDG/f15clYRvDUph2Le9IKsywKjStX5atK3
RMhm3miOyoR88u1UQM8zcqtZosNXwN9QBJipIbu0Hhs/u71bL03e3jAvOvlPIDZBJ+s7KhOTqu2F
E5iqebJhjaKEOtk5OE6GR160fWTRCqSOFhREYzzuZyyoQiQMndHS1AITmuTfDjkGf0Bv8RB9GYhl
wPSCz4ZnnZII++ebQfMW7tUOcaJFrQ365+P01riO69WUPHvkVV/lcyNFXqlgKUWtPYzKHOhEEkEd
Em9bvZOOHknav/soU4kpM06Abh/KgZsm9ByQf6UKwZZ687B4kbgueDV0sMZAQyAbOXcLXrrl6Wcs
Hp344kvVVapW5zd4XCUyRrmtrL68IWm6shCw/mOX7Rx7ouxhAh2fzqeAy+WFc4HRyEY9uMPogoov
c90CS9VGLk+8+lEt+CzIRfj3QSVghrzJkSRO0F7jL82See7q3A6OQOBdeiQjAzdcHMCaLANGpHd8
BU8j+XLf6CNhYHBGC2+VybVDOemvJ5sNkTBdkrPRWU+wnC3giPGvOqDke7RInfOxb6C/9xWN8ll+
oNc3Kws5jpKE/nLguWwCI5wuhTdq0JxstIZr5KIYJ50YpWSHpn8wVe7rozLxyvJzL37pE6lPORfN
V6J3o1gXixNowLPINuH13rhee3EosHvhw27YU7u8kjLEvD8MAUkZoXbFeBbCCczTufY0q6DyNhOc
f5XyZBbk1WrRoAQt8PZtp5znfaUnwXukdFxDKWPbKhXSzV9MnWqRro4eaPQo7q7Kfkih3zvACsKj
6gkLu9jtpk84hvZaCvQMukHclxuHcjc2xZSN4RWK8BCbStxFyLeqpiRY9cMy23RT6JvLUhkHV2pp
PIA1nhX1wwZDgezX4eJK7FD2jfKgnRBbt58hh7xmTVIp15KHs7N/d8RWsM70z5JJfJlrnfMK3swf
d5e85TgNdqBCpoNVBk6jNHwG9kz7wxxYWZNil236KFAmbLdRcuKBo/YbEvOirAvd425OER60Sq/b
bOjTYprk11qjVJVgesd+MnV7QtA836im595TMa11kPvIeuAOV8KZzGS/KOPtr2ouvt+2Tv5h40AR
w2+sNbKqtzUCOyjq07R/PQE4lf6eU2+yNEzXs/4f53/B4AOQvMV8hbLWfnRO7Wk5yHc4Shup96Xy
EongyXjNgiZU1eNwjr47dGZJgMNKas6anbbHGwsT3FJBhjXKtPB3E6/etXWFV4qZt/5bdi12lSwW
DqTGcDGed8LlLROLDfMSkRryY6bUqajrAJ2BfIwpYOgXRBEaaRLULDlaDmNvV8mGwRsWnmEERHJ9
QqGr1NiqYRskXkaLOVVn9EJbP2RF9dH+g0Bd11gfF+9weyBRk1yPOSGjtrSv6v4HwjORXz/mMjsj
4OJ8wxp6BACXw4N1D2H7PzbpMVVoWLxCRfig+GXu6gyWvReodPAJC2hr8NXq2UXoWy86H8Lj5t44
UxcTnKOUJrbh+FrN55sLt8dDZLQRD9NN9aYIPudh4KC86gklSPjuv3cFpkgv56BoqMYybNgaoHCi
kmNNLKVVYGQLDm83XB1coBYx3rKODsWhy2nB+7trHII609v5/S6hERbN/yGvdYTAvfBmvsCc0s7Z
6WH1k0xGc4L2Dj1wOENUepTwKG5IdDAgGl0Viu29lDtQ1ZrmeTq/rh3FevIyae0aV1jABlhxcqTV
RADFMZkKFu98r5nqhbDlumiAvIN/E4dx5Cd4upbsoy3tUyueXZCHZ5hQufU0CyqIbkBRljD03uUm
DhNe6PJolaJhIvoXItWeJaVFlsM5TagjCrrhD8k21zSdrIHGzsRi9MHR/foIfMoEv+wAqpAV1r/F
xwFRsXEVT1wJXmXnqED3PUAbVBBwIUew1hk15K9oG4mjtCcKQZ9SYDyNHHqxljbrxC2fwJ8SR0Rf
+TZVf3YOVUk16wDwaX3/H+oi6gN6Ax6t0SPLddQcmzBA13CLYgZ26XhU0d2AVnGW4xYXl8jyQV3q
QnSrHyCe44QOsKGjejGw/zkrY1gTitV8/UOZ1eyl8VHln7Ic/j65XZL240kJ42ilsDnQLIJEdMAV
/sWT/m0uVAGMUgntcZrrS0Wz+TFmtn3z2c5oC9IujhOdK51PnqlzKKRIvj1ifb6gXs9VMQ1eoWYX
vdojKqyehIUZiyU9bWFsgoFLiLW4mupMxms9B5l8Y0UJW3usXmcOICUSCZ1RvxZJLL1CRJjKaGKe
ZXdsbpYaOG4FYk5jW0rnbRmrWS7IvYdUGkdDDuxydRd6Xx9ZT9futqzv0FziyUH4UNG05GIrZCD4
5qAg7tpVZ1UFg/TqAeKsHwRieQmd0wnUau1FVnpQdMfEEV9G6QDlAPxGmzKvcVO3VbufxVePkkce
a93OqaU3Qi9j95/3EeUS/Vuz+W8fT/sOh6EJuePjUCnW6hV6FkGRG047OhBeEks9TwzNJQJkqInk
nGfy8J57uc70DmvV+f5bU8NoL3DBRpQrAUphLhSft/9pqNK+EaclG9Nv44qKLbFOYJfUA5l7aLw3
qB98GkxgVHgY73yo7X+WdiuMR3M4FqgSDh8HnaGet0cu8XQNjbUMd1kfG5Rip1RVTtfV1lVqOIcz
wYgLgkwww3VL40BkOBiFGdK0Lo2MIlWWBQGR53rfhxveVaNsY21v/dfXHyHrwYg/Z9IR53TSO4xW
eNNp/jnfHGwHN4zshn/JilrB1hdnLKN0jOzk0GdplAkFLCmvkVIuSxQmgW==