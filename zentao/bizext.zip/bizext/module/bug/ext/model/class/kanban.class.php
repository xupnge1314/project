<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cP/XWGuT9oxUehDRMfFlW04Wwm60GdSHYQCOGkiDJS8uUUzIC7ZzDj9+CsV2OpjeYY4UQd8Nu
zfnV5HSIK92RCPbB+yiVI9R6WpIooPsEt9XrUGNr6YzbQyoGdT6a7k0OChupqso7sHTR/wPrp8kc
kMprzsk1q32KLq3f69V6Te6CoyPq2bd8HBQgi9sbD21LuYaxItU7vZYGlX4H5MSx30m7EzV9M6oT
tQGakJsKwX6bX7sQm5Ch/26PZtbhxO0f8b+xPEFx5O7S3QEqBBOS98CjYMMauwmTkn23TAX0YADl
ddCGb39zof/cvO8Ui9k2km/ZH8mVkwHlHpZ7zfZwBibNeHenbBVIbeT//H78wr571T7sJjZ8jEld
Lhy3aZ+Igkzko+Ea9w18mmCqpRXeUoE5Q/NHyQMycr0dJgFCvtQlDo1XBwzG702a2bZJMmVzBdDT
Ncu2bpL5SiaUEzwpoj6cUQghUZf4YlBdipDMeucPqdAO/Gp6c4O8KUyVuLNmNyuaO+JNH7MZKmZ5
wdwlKvE2NwrpFbidEuwqdp2TCyKBv9VT4jmA5d8Jo8Y/88FI8S1xKwCvPylH0M+ujPLZcYicRlsv
1yzAup1QQHcpfg6IYPVuYzIWDJY021r8JDT6fAUpe+TakRXWIwlO75PuG7xXhJxZrxATfgnf3Had
XQFsG34asObAibDoJLH8uJv/GRPr6u6o126CwB84Lmc8omxTBdl5G3syXGckKn2a/N0qD2Z//+nq
Iz/Vw6sQp7gpRgqn+YqgO/ZogXrNdYSgjVuvsZTWtvMI0AtOGPg0in+OS5hEE0o0I4gy+NJcXxHS
YWtf0/GaxF8YonhlDO0jPlXhhTzfbJSz249kpQtrMReY5ouVhIQnElsmMZJdx4uiaXLt70gZnowI
fKvMh1InwBHY0hE6J1YS8pLjxGXzRu19MZ5CFHzuhfz04oB2qpJG5G9rp1m3zXAbpgybOmTbXlat
CWwpRBXcZznimzXsmp4O1Mnsz3bh4yOs586iYGobwW4aRgbWnKl2p2qdyE2GRSWBDN9bqf1HnIsG
0hLayJiJVeBK719MBNIn/wDx4+qGi5yN9AiftW86HQOUNnSAzNnvUg5SbHBYyH6EGx0n4Cjd1/aM
1fJrQWsVVSYJG0a81IatQu3vbgBRU0PXhV1OgPNdwrrdp23qXiDkekWpZ4Rwwf6L05kWaOINsDru
PFF9CoqLprMCj0h68QsEJB2C8PbikeXum3TCenCksMjgU1lcR48A41nuIoDzw+FPn4oSHUpqsA5V
YtwQv6ZCvYWLHtNCp4TXpEoEgSdlforeR7ssrajbcm==