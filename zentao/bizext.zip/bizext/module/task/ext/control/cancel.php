<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cP+GXYrozem+J0EuUVxF3WCV0GUX8y+qLKTWe3y8/oo7FH1wuPdWgd3sz0Np0rHiL8cxiECvz
9+36tk3iIf05eHu2S+0SoY3vPgVzxuFRWWS/Bp1HzLStHuTPdSWPFudX9+DisDfI6osaGvSgJm1q
ugPXqY1cqNl4OjfEo27qNmOU20LxfIAPXBCQbLCuMNKK/rLAaXgXo7a3shHh8jcGCz3RqMSlN7ee
ZxciGj6l88NM6iMx5Cij6KIN42F6bYMsdHc+ZqR4wD3UknaKG8jDiqt270abn0+u9krImq9bnQS1
1vX7jJjHDZ5IuTB+0xKphKGgsmeLNfcha7biX2D4rBnPaCrSClevSXfBvThRwr571T7sJjZ8jEld
Lhy3aaU8PkQhkIh6zxqC+wC8tRWN/yHWQzlZT4RW2nZuLMqZSXaO5KymDH0RWW+/1GKteKlnfyfC
03fftPN/d75bzjGgffFeiK0/1QvfKIUpcQHoJnDVqaKXdAjYZ0fzLd2Wt1xv5wDEvl0NgJwUYtgZ
fBP5bFmda4Tc6QrYAHiVWfbXMlGrhJ8V+nA1PCyz2nYP4bb9aa/f+BXzp7RDQFIikOGhxWt+NxNf
zis9AtxfiLemgrfm8kHPq7VIavhtl+072f1KA42a2mZiZjbhKm3ZkfuUFSF7+MgxX22ugGGc+V19
7/Rh7ItIA3vk4JTYQX10hrcJ56wJXtJm+FeidLWUP1HBBlePsDNnZhanAQpWvLs3JJx/W3d9kk+Q
6rz1CR7SVsQbqEYKcd9+K990CHy/Jkmed860s3dZAuQtyj4IGDDxzdBkXYjmmKexs4LhvuYaRfKU
cUhb9ZbIuEjU06+C+KSCM/Rh6HwTBUDl4UnFkA4+ZkJlAngW+OLEqo4f+4fjajj5ncaP5mZIjkug
tFdmT3GoCXcbvUyDlmPuA207nYsbR2p3+vDg/osnEm80D8w3jA/RPd5DN4Unbehj4ancX8xmAXvm
sZTgwCQDP6fl97x3W0MEehWQjQmurElbaXRoHX9ce5i8XXIQ8b0UlS5wpdc2pud12IL7TZuTc4VI
vtTWOnSuCiGg2Q/0qI9QCzMxaetrD3GriYXiGq35HkcdBTyEfDGWGIXL1AI8KoIhvDR9gl5B7z97
7ZQX+7Pky++uJY0Cby4NEopLb51b7SfybzECSjbb3IYokIITQ20tQs8gQPV8s43aPPsUXU0Q2MBh
7oOLUQMs39e3JA89yOp5ES6Pn0LXt/hWalswCbPa/3YZDKTN5Gx7NrvdVex8d8cyMVFpNbWRZEE9
/zP7TRzPUt1gciBklRk98BhBvxyW9oXJHbbLeMRstSTNS3fYLg/CNqKgnPtErMFm+VjP3Z+yr9SE
ABI9pa3DAs4JxgeKwopqxJIV5ZGgVMyR4e7U36I25kxlSU0f8Vl8IVDbKUxuVVb+ZjLxEqsEbNKn
ggWgYYUDg8TLMrkOCVl7Z/yFKuq+s4DKyKNabPPhcFTvrS4nXWV4MXM8oZZRbnsPKcEetT8QCQoo
fFy7FTdCWChnhH1A6Hybq5kbVCiefbKAqFUbQ2rgmE8E0hK3/N+QmRRJWvNvHwOC5WGYm28g61tx
Oc+HAkjbe6vmpnhjMVpU1oxVJQ2a78/tbbE4zufdL7JBd5ZGH9H3oerwi/OU9C9JEhEkjtzQ8kCw
SMtJUzqCjZzy/F6zw9aUxCsUBwMGdbCHerj0E6VN28xUUBwT1Wmiu9Xcf7WHNnbxgEugOx76yBAV
icGADR9wzkgmDF2KouN+adIRbA+oJyYWRcX8d5d7NTWJWI5AgCrA4NkzamkrRcCjuplsDXecP4v1
yvyHTZ0u3VVAFLX8sKodCW+hry6/MsffOz3IYk0mMLlAXW1XQ85++rPWwVunnSm9h4sJHCs19dYi
hljDfZt+Nx5gA/FEEVNXCYWRANqvj6LpnzrRRYdLTuUDf7Y5SFQIYNg+UMzM4D3oNnN60KIscnsj
5NX9Y+rnTxwYVTj/ajnVMGYuhPNzqBBa5dO150OfbaocGSk+Cc3cjhTj7M6MEAFTXktqW6qpEhOQ
HPyxkfLavVtAeFx4NYbu5DoQP026/wQytEPMKDGeJXEoxsvhV/DW/QKN+0AsJUofPKFswY+rlFi0
T9WlD0UoUoBnik93V/+VWe69xJF+wpMSWmToi77VhN0t4fS5XbmJ5k0NFNnU6m+cMVaMS+vA1Cn8
3o5sfEKsyxRTxALmtbPgq1FV+0I4t9fMZTPk7YjwkJ1RdoR4dbG6oOijyV05LfuaNHd64i2ChUZ+
5mtVuYNiFZIG/rne9zrX72AMz5iIanJnxZBI956c6myY4DBqSBeBuAl57UmQKcmjviEuGjSdE2xo
gEdWupiOj1BrVBVagGY3k9ZThlPmXa8NfBfA17bdaTclRTaRItOcmqBi45RMnZeq+dTZ8NbsN7fI
zOt6Ns6eojImEnavfySBDPpJ7ygso4V9Se4Nw7RXmg5tEd8oiE/S7W1WDXo2Mw+3zrXxgDvx7n1U
kqUUSN2qRJJObK/a1xg4JCjcjjHGq5Gq95CFmPWOd33yceXGx0hog83f1yXjltSPwZO/PZPdim9u
FtZfDqgZiQhGIWNcu00QXMT6ZyobTulKJSaK7PUCTJF3RQmKTArtwgpKzqePRywuczbFhk5T2iCC
xkOeCSvgCmPDmBFMiNZz5PFn2n6MTonWTa7kh3MGEDawZAqk6rVEceW1UAdIovahiaYJg7H51Po8
ta4oLb7vot/wYf9h52cU4rJmBhJl8NKtdYX2oHvgaRrpGHkfkX8P7e6u17N4AlJykR1/C7s0IGos
viUCjHeh56nqlFIey/5P66J/HGmcKD4fpRZXrm8vE9+V5yQgDjOkCXig6plCwR4c+WEy+oVKhSLX
RSk58HNdudFyUzuHReFZbBy19Vpq7SvrjSHRphsyHXAo1iV0mVQrB3DcSMyxUNt1kpLgO+3fdYa+
3xlfBQa3gZclC1jd9oi2VV8L39aY+pwsZ4tRcl63QRZiZF73UxRts3ron/nkV3tal/cyMPWDh7a5
eyU2KSA2ESIppJsRUn0Zg7DsLZLGxTzotuP8qcvwPt3Rj5g/r9zsPXZrjHNJuPhcZttb1H7WNGsh
eJPaLQHMWqoj6+So71NBS9vAsw6eA+gtJ7Y8Hq7EN/+jk+Ko3XLimidDFPGCRoOljAi202PQlMgR
jl3vBIgnErcBHngIWGQmv3uE87FR3yEzlfKIgezwFTXbJAN5gkb9ti3xfeOxVpqh/2HhtWK/EMuc
gGTZkZJ7Bek1V5cb5gWoLDJOdEYnGQ1knpxBGggH9crFcD1wV78aZ7vqbah0rKtAv7+ct8BHK/Ff
IWPPb9mkVnQIgIsRo/wGDipEEry18avVLPNbjfwuqZvpNLf1l92XSN/X7KNVEHylMzk5F/TRqSuf
VsacjqJ0GrEoCafnBfhmN6+sFcr4TbWHxy6N9cP6AQRBKobp4R+hQR1cZqTYwOO/gQ+p5Ze+bV/O
jhY2Ykacu/N6K2YP6Z/X/I867XCK44hirRQQn+2xajAe8PLAD9wKubXNAdz1ys2gaH5T4mXr9TZ0
k+v19evzx6yjLwJFG8xQZYgAdLvURRV+8iYDuzGwsuTxVwYOUbjBgDfVyVjEtsCHcNUowSqDb1RS
N2fp83UQ4fdBW0pSuASGcB5nbkAJs0wfSdoXuAch7GVDeZsU6rmu3K8medA0s5S27cvDTPYH9uvd
KOwjUPg23QpOep1DgvXCep3Z1dHRzCYOlnDr9KbXcQ9X55V2gUTR0Zsm+K8NPDjpetQ6agurV7b7
rOctWmSWL59dEJ+cUFKsbJXbOV01gWmp42/pmQ/cEIaeBccnZpL37TgcwywDRPpfLzqMP6qaRnV/
fWI4qNQWanctypGPQJVJmKvqArlzg3LN71VziRHBJRsHv8a/Y/BPZgSzmouQJPMakkwhlzDzOsfh
PC5qakwurBuOkt+efX2f5G3xB78ab89EGHCrfxkq7MlLFZrhY85kowRIWLPGVZxZIt44UL5deNEk
zLaIzRExgY1TI4zKvsDL8dfGT6ZOgm3FqxuZ5PzyTksp7ViOERF0eDaEvTH/OT+bJbpxlQNaU5y8
eb/dQ1EtrBRYCtahjWSWq1/NKE3kg2K6T0Q6nXshgy0l/GlgjoK7WXgnskJabkUR/s9uwHYTKSnQ
nW1buojRdhlqnIXN1z2+2aJS0w0u7Xmur4XIO3TUxUzXAHXwf0/8h8fWOdLAQ33waxoni2UEMMDw
rIuY1bKUGTIxw7wRpArHJj3GOin886FTIV+aiNMbOO0=