<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPzxtIIybLR80Y3ZS36rEPW+Gm2GrYAoMCzPZxXIIZv2KL/TcowmXK2dIWNrpZXLj5wD+HocU
BJ1g4tVw0f/g83wvJVqkhnC/Nt8iexoM3i9AiLxUgYA4ifCmDTcIX7U0hBAdDW3unGfgXDV8R1uT
G5Vh5rURJthOlnFaE70IefotY6C5UxfFBJ9qgG1n0uM1YW4Hi/+3QOEC74tJL+B6Ep3vj6pas8aS
WAdT1k9+5xIdrzQdFs0Viu/HPJLdGmXvfDhqv00oIIuB02h42u7tE1YZ3irQ/DQzw96jhnX3nzDD
OMQ6Or/qoD+HyAiiIK8bX92w31RkOH5IoSKOsM2MpQKZrhRyCo5xkPW+i+jHHmNHzaxOoBJhvrQ/
0v8qY5xGYHynpMrTdLkZ444OQV/5r7rwURnwQ1aTIJCmpBLQWxPv/b7+oIC82KPXwlNsA7ZamvZv
yVKulQyw4Bb1VLlUxQvg4j3ligwaC1l8EZR6VcRhAMZZOQWz+5vMwYytgmJLcrQmzIaB/jbr+0Or
idzp0Dj5+ckVZEjq4k+2YhE5DfBps1PA619YL+WCyqz/UvIHz+D2V2dImCaY1B0jq0YNp3MC0A9k
8ZWGn+biP3Oo+ki46bJdgaLxRltCfgOHWzYSDceiwL4nM/QZYye9mMtPJM3gWXUYcjVvNNpWppK+
TczxCN+AVarbGWOcA0FYVFkXZ8Ra0bCR5WhJo+TqBFdUjriM4Sg7G+CqWLhrYzy6/q+RuYHGMhDK
sfyUejpvvlinUfFrlyjm/dTseFtRa/qSKBtYPCKZlTU/LPiX6XUzOJ4wUQzNFdUAxcY/RkXIxNxF
GuJhVZHilL9m2ruXOmopk4qIt5ymimMn78VrZrrgzPLBBdIBXwtX1KBRKadcm+GL0VMHX7TK/i5F
8nKaHB+FvwXV58qRexj/fsdN2QQz3f8u4qWeEeSvEjpjzs52wePRuTf9Btyjm4ZrX0oRoeQVWY06
v38/WHNRnWmryrNZuB1SyRdNMRXPdBtmqtGtPk0dRj+phiMsG9PmRFP5cwH5d1FHTlX81Lp4qCN6
qCqznD7LTy6Xh2dE5iTC1RgcELh8RuR5ykCAn9BPmMaahPb/mwwso6zTuXme5qAzCmwsqR4fbK/8
fLkDKT7IsASGmDFKT/BkwYKEUZW1vb1sjYQePuUPAQv4UAP70xB6XA0LtTAn2AaD2B9p7n10pzSY
AgmqMR2DM1j6y1wa7GND8d5YBLZFdrk8AhI/8Wg8/CvQUYxjMnuRperQS+ACkCdiMpb4nuY662kB
u7RoyQSZg1KZLYd396lI199YvrpgY/iF28FJGK1Ub1wzJesZ7+5TX6mT2+HqIR7zZeUQycqsCEaz
etMHQwkesyuUyjEhIJUWipBf3yPcL7QLWb5P60raoeEBCrWSH2AscjiuzGzTct0omz3rIkfgbn6d
6NSQpEXeNZ2PxxPeAibCjMEB8S0jv/eESsGTk8ml+AFQDsdRshKv33uhXjb4/cmK85vNjBGoPW00
67PuGAkdlL8O6kR38vduPy34FghKACYLqSheV29d7cuTXtbzz7Y7zv3apEwFd0VtsZbm8PWzNIjA
LQCaEYeSMwUYjGj8N2tWeluvUSUTr//6bRa16YEFJw9XACmey7xDEpHTQOgnfK6YqCep7u+AOcmH
nv4MRpvKaf9wvMWmX9b7GIrtkuVd0qpgom4PLjYZPT8Ee12odmpNyT0vT9N1oY6jADsJJAcrNiDt
zboAVWSKrO+NOcxa+dh+QB3NyClmD43s+7HrLKVziTnTUW3JuqtoVr7et4IjvgWwrE98kZAyLCHj
5IpWsd8rPy9kGr0svmvR+I/IL4BXA3hNCSI8FH1+j8R6jIFgJgzFg6vkLb9ryeAVknir23ClpHYL
a2UfPvZ/2NEgPxleWS40aKkS/aUDG4ZOoDv1Gm3JVmIZNVE8irG4Ez59GLJ1RJKaC0pZ7dXFXdYK
e/TkSM98T5KPASX3s++tsaZUh8Wv15u13j4cJywUb+wQuq27ZTUC17qFGmgmbFyIpIb5uwrdUG3P
c+p4jtsRWGhuiV4WqMHO85ztae8+hCCCoEpdSm4OOI88k/MnjQ+z3X7pbE/cxNS8uaT7cdN0m8Sh
wI4YR9XJZJVgN2UZLFrJFqZFDW4L9YOlU5qkh+Z401ZLRfd72O4/QToSZsHf40wMiuRbqMRWYED1
/licxNY90vIilGKiI3BV1WolSA2zgAE0JdUL2f+q12xiLUVvdIljLFD1a2FeEtNd971iveYugNmU
WwDLNHi0BTi8VhcZ93wvqYfHsHDuLHkI1Nshlx6pdURQZC1RLIPOflpBy+vyKc2fMrkKSyz5fN5n
2eoccusw6nsjZk79sqZAXiqwZ/o0Z9s3WciUgaigX1OwfKCkx37+RlvrV9bAGgrsKo6LtnXFf9ie
qCjIAjqjGzw293K/b96qOwV8JYgxeMB3XpWDtxrfjrMn41whRz0v5kEJ8xDSR7ySLDFXQtW7OaXY
kjCcedoYWf+GH1hW12sEIXBkCNunIZ8M4lNdwJ0dDkYc/fqJv6a+1mPHzXUHOj4awXnysL+BwgVJ
P90rrU7LiyfqORrHI0easCeQj3EF+WD6cy7EwdIrupiIGI8Cc7nSHlsAWGGr8gQjYpDLooPP/37M
8h2yXa56R7emEMUyuxbeDqewwZOK2xIA0CV/VBZdDopbBdWE578QGQbSTFKpnNw76jfY/B4kbbrv
SukMCTpkgKEHuN82ynSk8xF20JLCZb9KwUu3leKwwbp82NMPcnnTFm+ACKSAbmJcJV2l/1iIXb67
t5SfsUJsn+Pd/s8xHArL0wJYbYoXJVPFoVAckam0iXPPg0GELo0xQ9OYGBUX5WGi1X2oRtrNgayM
+kXRgukEvoRi3wuJoEAuMnlzg3Q3pCqTBCT56U6Tj3VYqsWrmNTV+4iiC5QAu4OS/muvoV8qQzpt
pBazlLY1867bPls4kHjRvxZmtR60ejfPkNt5eeIIiHp+ksVY7HHSlVzx94WYGTlWiAwBg8B4BZhH
YZhTtEhLO1ZDwI9IP9PMBYITA4TXTljFJ9Q/AEpyGkKtMlzScRX48fCgzeiM0UlpCWuMzKgAQmhi
8wniuUXZsDDfcX//rMZDJH9c2i1VHhZhgaS2djJC0znK18BClNvcwZMUbWZ/fGLIEVBW5WUtJOfB
kE+ijAEma17PdZtT+s7IXGM39H4aBuVvsNeHRiY8aujNpsRH7ovkXtrDNgg4CeBOh2B0m9jdFZ7j
jDUcG6st14oC8NjAr21tmtmS4USt1Q4AekNgdafaZA5NDxj/6i9rtwvNNtOiZJirb9YAqK9z1+GR
Yw4U7i790IFlb/UGE+n6dxNtrFfK4wxSRkJs8wU4jdPMsAsqpzxRp9M5Sf++znMvMM8H9+mGRHQe
5qgQB0ZRuCVpCxkbrrpQ7G9UeMHjbTAtlKhXmqioeRqoXAATdfjj+QcJV6bGIjkwUdorIE3eEobv
XAju2y9HthUDMt7SosR0OYnCr6LqR/cT2IbtuOxyZGXEQgo8fCqxvvXGaRZdJS81KseiWqJCplMs
haY21u90IG8aQednBC+JcnuuXxIMV428gvoL9HzEwKRtjP72gjp9PoZKE5YEhHFIHnnl1pkmigqS
DsCsyiq6yXbndv2SFfrtrOY+TZzsZlywxKDPIezBEe+TIdt6lYQFPcDxPycxaQKbvuVE8H9fFnxm
KTn2X3MZ3jVCejucLIcBddD1i6CTTJU1qzr0LN+njcaF4hFaojrq7jpM9IkS6kVaba1FSXzEf2wg
3dYsKvefC6c71uwv637g6U3/Mdn3+lMqoj3tTnT+vaJh8SSk7+2lJoVBnu9X3SUrnIvwKuq9A5Iq
yGo3Wx065pIPlT3EHVJbszeISkhouown3TEpFXrEND5NpFzTcQr8hVXVn18u+VUZqF6CBG/gHD05
7gIPG/2ijZcL8fu1lfSI2mwI5Y6lcc8hAWqELDRrQ87YcYO3dtnz7uxY/AIpyx55azb4Q/eAyCEa
ZCT2SYse3F+l/8kuAY+pCcuPxScf+tiTEQSR9dY6PoK5qflroZfIkMB2WpGmtJgPZ2K9x3ikCm3s
tT2w9uecSr1W70fL+ZJz4uZOJhQARiC1QHKrihRynWLo8vZEg4iSkRUbamblgiRyBSmHZmZmIVIO
Jby2l5dmLV25QuoxqlplLgM6gFcoHg/0ZfuDYK4CNr8ANG/0OYVpVRPAwvAQ8dEU4BYKZi1jGyCM
Gh7cRZ6J7HAeiCg0DoSxMhvhNfjbDIEZuGaFAvvHYdiK+GuvZdj06GVvWQktoWWk4Ug+bb50SA08
wRmCdMAOrKmnzmLQ/1JFCvhkeo7MiS1YXW7Uv62RlVcu8BxPrEekyW2K/Rlkf7ITjp/KRAC=