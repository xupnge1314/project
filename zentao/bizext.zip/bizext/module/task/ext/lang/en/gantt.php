<?php
$lang->task->gantt                = new stdclass();
$lang->task->gantt->notice        = new stdclass();
$lang->task->gantt->notice->notSS = "After task: \"%s\" start, this task can start!";
$lang->task->gantt->notice->notFS = "After task: \"%s\" finish, this task can start!";
$lang->task->gantt->notice->notSF = "After task: \"%s\" start, this task can finish!";
$lang->task->gantt->notice->notFF = "After task: \"%s\" finish, this task can finish!";
