<?php
$lang->task->timeout = 'Timeout';
