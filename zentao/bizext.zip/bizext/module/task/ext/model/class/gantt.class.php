<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPm0K9cjnjvfCjDgpIFxv8jLIkQRndH0ztrED9roDpI/1oW8POfAxh4Y0Zk6xpMO6E8LAae0Y
zlyc9+VA41tfKjgp3V74RMTgaaVGbFtbvonRV0s0JLB3qCZvEltV2Nt0Ip7UDsrK/CgHGzTqj9gq
ZcnAycBO5Ge4rGTn5HP3wayUZFKpQDTaAeY042dUESJgM2wSNkep7sn6Wems9MdIA6lvJvZeUDbk
kgVdB2tCEphDS8AyoGurjujxd/uvdVLBKbSn/b+TqtpGarOFDOpSnQNQ+XK8DEKGYC+jXog9V4aA
OMgEWHq4Jmc6NnCcoGkl3ZRmQrY4u7VgU/1ujfAv7PKfGhb2xy4D+GoD1CRhKKS5qVPEsCYqw+TM
lmEIUuqlEucEpHi5PRIsemZTk5p/J0VlVr5iK4dHhn2FVGnXPcKECl58E1bGbsq6C7Y+ABXiGJ3Y
YV9t4yd2RjNG3B9KLuE8Gq7rKULZRj8wREOg1Aa5NNu3ouO/Urr/2Ck77jfTlkMmWTcOfm9krJHd
JBUfj2355iBI/M6517RjNE7p1WD7EDoIteZTUYNKeQ/aek2D+eFbB2MeUc0XRLvIsX251H9H4Tq7
wdGlgQMIxpgss1Gb+GRKz5bcM3MbQ/GJc+0bwaNmwXjXguheoSOvKOFnl0DH1w8jn1Xr6Gs6birU
j68x/Bcbuh0APZMGEy6rfl0B/7qDyvBqx6R9UMjTVzvoVnD47Bw2k6E+16rovzOL0lzaIUPrDKWg
pepiCN1rDzzm+mrtloBIGLeWWemXVxfp6fQlOETdSS2t4qAwYSdXHdrW3tFBogL2mVxd0RnroEos
N7j89pVkIBFIX8u6qHd3OzQ1dYuNPFBhXaSWQL+FhNouFKtSrRR2IWSIpTp54u/wEU1xN4fxT/S+
tHA6ahJ7UQyzsmmoCdvio2MrbSOQj9w4hKFPefRaRNbYefAYzbAwPff9E88ZjSWDKH857WBF6NZc
cNaMGh+wh7oDo+DxqT83cm6+ykSn93OOA8uokXIhuNEBQkC9P/dhDqCoN+g5aqdHIYe5vpU86Wm6
MWGh8vm2QQq++irmuai/75jmHciT/sdtnKCbLcpD9G3TC4NXFsMYIYxjM09A/hxiZwcuoR9zjYPB
h1naxi1CIAqsZH939SupL9Jh0TfZ0QxlZ0zBZmcwsnWTJC53ik/LpmgRRtUd7mFmsaP2eRW5kbS5
mG09wcIcK+VgSx4kyfLJhzYd6RbsDN4P47dfMPSGYRWMzDqfUFJxNg37qVkrHW9XFmuqWj2Ew/z3
+M30pjywyqevfW0t//RWJ+W7ExtZWB0orPGWoDLyCG9aEW5AHGTarV9ZB0UX0CAfBHAh25sgwdbO
ba2jZJ6XJ+S28+ar3hvxlcF4xDJtRVCZxg+Io5KE1D/lNQmkQjDvWtmpS7s3pB6MDI0XQb1H+Flt
FG/5g1QsHqHV4tHPefwhDtDmElJLlJQN4TbpWD9z9bnP238e/DSmEw49vMfrFqRfOMcBxzatkJNm
CZEXTQweZEf9sywAdObi1OfELOzRZ8XKi36KfWFu4u7wXKc3G8nG3L04T8/NuGhWGeSAuRzGANr9
4exULtotIj54CQr2o3CXTEpAbDk2HgHPvgd80F9NFTDGowdCL33Lq16NPtB4f4KB75oxeTWduWOt
hACx8vAEPkaYwW8DxcmAqp/+s+1Oq+A7E04FeadE+TSaVsCqSw020/+uS3eBWdcAUH1VutFQQUwl
udIuezX2JORzV4DZ7Zhsvb286yhQqm2VMmVMz2CZJPkJKChucMgkm/+1mdO8OQbr5kykGOwb/YLn
K7gwUf+g84pAbSv+suL2fJujtvefDkuiE5dqdWQizeNRj/8kinSvE0xrxFNLhKYYWpP0NRyNXd9R
DptWZuvtHNhplIC4LZjmYMYRSJHcDA9PlQFyPRYvZXKh47/PfUPBtPYjlGvES3Jv30m7dBbfQUJd
u4Hu3g2WAXbC+tq4KxMmhetXOsE/O4QRT1krwb9Q5YDMb7UqtQL3G+Qnr+FEZNyQA20eMv/h21I6
kdR1ds1vYOp8ghtWbgtdbJ8fxcEacp/O+1bl+M6iHEPrpphDJWWxvai925BH6ASsO6trW3vHefgD
raWCDMLV9WqWRGTUfpjz26u/VfLk5Ln3m+h1QUGIXU5lXoQYCVWR470mjaFrd/avLC2zwA6Crb2W
XnzmTyihBMIrLG9MNYpJV2ys0aJUtqo/9vnM+cYGdWHzd0HCMcyZEp1vQwarV7i9vQWr2c1mniXF
5shbsmFieNpmnrRqwwNZtLKAM9dJQozoIpuL2w2qML8/A0fXXAzjs9GvRijiSt0IhCURLJhibl6L
cm1kqmQL8yVIIlX1WujaG0OdfXZ0xZs0HsKRTHtBTu1zxkThaDgkdjPDTP7EQjOVR4G7D3hXXMrD
0xsLiusCTop8LQ1AugMhL/ZKRnIx3WZ98VtPduPWsfgleck1jAvl3OlMNIvOolg/q36sC4Z/VViG
6p55XkWKtNVDN2A7XFJ8plxCmtMijlw1ooG8Nw2trOU/6ynwuRK1viimIxIQaDAbd1MLg1rqGkuY
fmMntRaGCaUjGE6kATpmz8yHurgaZChEfVr18eL/nHtoHDXDXTt4iVyIurmfotnCb1G3ZqPXy+42
Zxb6Bf3ZTB1CHsfPpzsXzt03plvkpcNvUuE7hQNg95hBbqs77Lcj4iLh/UPwOLpUyEarnNYKZsaE
JAWIn0Duc30bZFdaufWAs8I5l6OOmpxfocRjMnm7wxz0l1Hw2ZvWSFYiEFk273t2jtWd2GBRd2Zb
q+Hr5evDXgSXUVUEn+4YARH6PkQTa412KHAKQb8VMk+vmieFCtbeANif7DoHxZxLjI87XpX5jWJR
431P9ug7xRm3BjdAeWtTSnPFwChAqDbOtSYl8WLyen1bTQFi5CZt+qPOd2FkdIvOz3b5iNt10ul0
w4N1lIUNeeKgIq1PvvcdZwBIGnsN1/DMr5tzLxY61yVc0qMXtTdcvF2Xhs0eacqw+fCsKorUYXOk
NhmQB1cC77FyUH6a/6tYO/ue6TiNH3QP0DwUPwFptXvTFtodBFw6HhsvexZL/2divLrKb4qW5Ajd
DxgNoY35wIp6R2xvjEJlP/YEYi5Qd1W51HNwB2Df5rUCdXDO5aZHVHdUGCcJ8y1FWtf1bhzC8R3e
edqW/xn6y33zu3t+OoEdaI8B8N2iuPhcJjOTsMOLkjbboTsPz661qfaB3LZCvyOesl8fXa21N+xw
9lWhFnkE0tEFOA0Fp2Lkq9KaraKijAvzeHUgdetlBQRqlR+51zdJL1Zs6wvMFhwE8ZNo2X6ZRw39
pp0EuMlVH/krJ/SOH/Qr1eybtWukbT+2zwufWjmB0NQ6Biwbna60ZBqusnYxDKQFiCnf1ITxXdFX
lsDXlcLNOxX2DXmhxFZ+5nYoC+fKnBFK4BiSPfC+ZmI+QpPmbe6E7vUlMkurwAZlxBFLeecJ/G6a
FTg7YExPjQdmgqKl8QkUcuEh4MUNZ29co1iYrnXN0rOcoBTKODxhQptDKwlRXfEI+Ws3zgUcqKOQ
VBOQlOD890dd+F8gbRwMZ7hOafkS6r7B1BqrT8UplwCjey+yRrInEShPkIyBeEJu9ddqDblLUXzF
8d4aMMgCxQSSEwbzDpJZYRzDdqjYJ79veOEFqy6pSfqR5inC6uarsrhLizkeQBKITslNq0Zu7eMY
G9hnIoe2goCcz4LhTRXDAdLhB4deN1etjUeYHBzp8Jiif6UcU0P7KHCMQvKh6oO3jcs9f3FCNr+a
xM8+EtWRzAgNglOVbaoKAu6/kMwnxSenrr0xnRkFy5w1P0Cj5DW6spfJ1iufg+SWSjArymUusJiN
uVRO0lgz2s2qp5qL8uKjUL5urT88WaNv00m0cVfEYegTxw1DcBq2IKS19xfdDubS6JjlybO578oI
sOTwfIoJAqVptUCSAUx7rIDcoPIQZ4YOjIjPvz0D8GOdxD/17NSWfoxddxj/ndEhsZbiu0==