<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPrxdTO6CIKwtyLNWekuHD7FQSwIrhtEOwbbukbICPslD6FvDP+/Q045VOMCr+7anaNPVSdJ8
GNhdbRTF6QfjDVhuNL+qoLwaNbQQ/TIiCE/2UEtKj1S3SEjZcKS/VtP7WLcZbVQaNpx4PZVQGh/k
k9PrugdiQTDhPz02+WKOvKHt7kSRMzX2J+zJG9ZLiI3kPfDN9SHO4xoy05HFPm8LWGoyWqoYnvjw
TOr0hwNkkdv53lhts8iYcMJ8mRE6zWZxaps24TAtGfKNp7l/RTh2RxNhMLXVyBzhbtntC4AJ1LkH
WmDntCxVi6WcVoZGWdTCOfZk6qhnQpHXUBci0vwn7JKpkCc85rbUICCYuidhKKS5qVPEsCYqw+TM
lmEIjPE7zdghk1Xznlz4en1165t/WhNxUnrr4cvs7pYYGTPP8gvweL807FLF3ZVytHYsXnMpvKnY
GH8HpQMI8LR0d3XXHq8h+D1D8LAx9+y2QhGSxpRN4OnMgVH4HhAf6PwrPZjjfQVPP2nN1dDEfDeD
zxv+NDrjiHuLTNvXtKs9FOieGTj6ZE7JntQf38ZVTxcvieE9nJ1b/1Fpt3T34X8YKYbEsxiMh17h
Lj6f834JAxP54OkNnECrQF3lahQdoG3mZODYZZ3WmbjCFwKj8978iR39ctwQJgmJtlRlElfUbzAJ
14DE9bQdOxeGi3+cLIjhkrbMFqcAlq7/So/jn1KuKgi3/sVSAeTBq2NB6d36yFde6V/r5+gZRf2j
9Q61z3+1rHjjTIjXnLtUdUjmOx2SQ1ybAucHL2jYLYJ4+FA4ajR90CzleC4a6N1p3ORZ1zygsjqz
lK4rhndB8l0ZDB4/zqYiB4jeamYaRp+h0OfBZ4qfUyP4HnZpSwN0fWXKNSdqYkc3LVEPoPCOXv4V
hyB6mSt37YaHK07fpvlGQWVblAfgHOsbOx6cmLNwXAY2RarFkJLOsaDVQpssiGLHGnoi3/PhBJFv
hLzS6aJ8RNI+7Wl3ij+k6Nz+XwIUAXoXoS5PmG+15YptD5j1ykoqFmqvE0z5u7c2ZvYZhUwmtkww
HtT5mLXtvOR+cMEJRu1P/t5GzTPv1lWprIqtnfde9qX7juHExxRmAHrjaoW8d5VwlKA9zyPgShV6
onLNett+72C2wRX0yKCQlxWicbqURd3AUcmK6QFuhZJ6/ZulfjaGzchHbKVGCac7wdklAgOc3Bcl
RaqD/n779JIbwbQpLARrE5bKpJQGEAKEV3GuANiKps541x4gqxxWH5Y/SW2xKXz8v6O6BaS7BJPI
6hamOPkck3+rabaK2x+vdjer6c7AlC/yZZK2AC+7ioNqDjWtyoD/8ThlRHX5Didnxc8bkJNYYtqF
QUcoQhXqxN5uSGGXpys8+z8tqsxE3oxIxJs08J+XU7hsn/vro/M7UXWnTPzzwcefVG0ctaB4e2Fb
BbYVfNPwX8m+qw39KcJlEXkgWo6C+w+3QoOQainmUYvDTS+UbgXIg4a4aOs9koy5yKsffDHns4y2
308XkGwYl9+Cl3cwKOLZhxMlO32zJq1oQj1QdBAABb9JvHAR/JhRL5AHMhE4GzSi3tGlTnJJLfLJ
jnHOQRibROEd22MxIIZXQCyG6llCi62JOe893lQMvc5lR9YN7ns8odsiMMdBLANKBw3NA6E15FTk
TIVbEum15uKxdYJxoboh7tKLLx51/M2KumXAH7oc+dWUG4hSa6CpMjOZ403ZsU0I1qZbwkB2mhCM
h8Cl5ndcGPTBPtq+lPKKjpEvuk60qfgyDZBXxP/9HV+r6DwKuPlze6j+Fb3tusc9GN0Emg6teE1G
TGuNPsxnYgdfneiJqeh6mJS3g3MRZ69akngVakV1jZd/oCl1PzIU0Srs+IfjhjP7HjwDD/WKXmYL
J7tSv6g0t9oruKIJMFOCEYosgGDJ4h4mWUwPAToVJmBMAs+TDnH63OgmziAEAxNovtpbnv0IiE55
64JiFvWJE/u9b7KnQkCeSNnNjUP1TZNb8e5Kdz+K2yyfrhf/KdSx5kI13Oy6hGOOAxDzKMI7sVp9
5D/Cx+ZgpGXBXAuIgxdghcJXcLiOs5YlrAHvTMj5f+9uYTOHZg7lAYfYXPPxe4LVvvVKSygzRWu8
LJOo/zLxdvLqi5Zde+xJgB6FUGgqcogKSdNim7bCMxF2Z27Cl+s5xqj5dxFguIUMiSpmx8+YkmJt
eE31ET+88ke4nTuwC/wZxsb1atB3g+ccpZ7+WnQqM97FIzwxodLV63YrtRAdyirhu3APbCQZOIDU
myWS5dYzhzBR0j7n4aZALSte6scPN7DFAXnFcONDzaXhVfOYQIyBNieXtan8/11zOGhEU5VPqJRI
ccSq9GDZmUB0p41t40/eDO8fZb9yht5pysBPCSM3Dun99mP0/vpNGPWiaZ/DbKjnroHQJInViAC9
6DrKWxPJTRTYcNjrNgz6OifjqJ/iIbVZLM4Dh1BkubA9tIahUBtoLUgYd8LAv8afuhU2UWjWA1dS
iUrIwNnJr19eI2Yyqh6JLrargtmegy230JvVardaLENxjtE/+078QNGLbFoJYnxokh/SyHuNyjqs
5oHZQfFw3BYjr88CyCSvnEj/xLOWrfVsZYYIfdKbHgTo0qZDnyTbYWG95iFwPX71uP7rI257Y4sv
mKjAb0==