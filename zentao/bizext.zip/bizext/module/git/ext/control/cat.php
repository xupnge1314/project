<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cP/8t/02abiGt2Vrf8regHzrF4yTgDQvjiEj/1lYocy+04dH52zf0rVqwkRaFxDERSQnj2IC0
gu63XftKZjncuRtwz70jeq9BvMeW09FY3t80TJhsq3dDxP0v0eU1Dv+ebxGJjpTMiV+FikB8Hzwt
ZNaBsosa44pm1hGwe2COXUYw4olcvkEB0bH/h3aiVX24b7UB0c6m6MG9+wA03E+JNgTtHFoQdbhF
JayokgVMnYaqJvW6z3AJA+SBGyXoFWMeK8+k9DLFZuA4UFxol2PsdA2Co+vpTIbgVBhS6MzqttqP
OY22c3BgdJEAAVo45Ywu1jUqNF36S/NTObfZdmWsioFfVErr6RA48KQz5kjHHmNHzaxOoBJhvrQ/
0v9WZTKa00Sga67knfEpVbArSz7f5yujlwIVUCLgmLDKyMywU9NNpPoFSOkKiC5gxTvi6fm9XVVk
O2tJC//mg4Uvn3M3cuMvJjqeiWnPvTXdWwzeLkEWZAHxf7FSym23c4h1eSwzSaRvwoJtSPDFw7rt
Dfwx5Z6XY7eWo6OVKbjQSyIEp/iRug3KX8gDpG1AVynZtxia0nYKKzKXDYGbggMejQvbFIoO8Cb5
UzeXE0eushkMHW8/8liLZp0urywsfxUgqRmYSFRM8EDnzek4M/XIKKSt2JNH1913rmtyDIEneZSn
S9EvUYqDwZQE0JsC0zogmzk8LTtjQxPiH964gAG0AxiIZuWtSx2UNFm+V+nPkYkmUCSIIioSIQ10
dM1KJck1/6qZX3kVhmyS3BHuRhSghDcJjqwOqoqnBg9IKtFxWuuH9ex/dT+qIVW4azrDi6JBzhRY
z+fOs+pkRGevSHxvahS5Jm1DpRTqhjcQbL2DouCiA5pYSRO72FX32Hic48od7LCTn52nUCrnfWc1
MbE79X93JZ/Amlb55ypMNT//XBgiCsXGhCWKaP1Ad+0u+8u+YGw5ENfai0/moe7KUNDAaHx1+fzI
AH3Nt1uW3K6NmMFRCN6YWkCGMoKKPETH7vg1gLtL3Oyb0tFIOHPxzrwqQJ0wtz+U3tHLiNmV1qTy
NMvJEhKsMu7FtP8u7LK4eZvUmo/KsYJDfgN5dJWob2P8VmMQhl0qvGDNUINTqdALrlsEDFL1c3Bh
gnkX0HAl58W6muxkb42+xcNN9awQXIcOuKxCqhClmzdTIL94GOb40lz6cFXhgJEDKMTApBsbNM+R
mfzHgX+wPo6NhiBYLoPehFTRLl4N8UcohC7AmrziJb9qJpLFbvVuALK21lRYMpSzo7ib504YMbtN
Jet826Bab3wBcLo+9UsOtNTe2e2Vqr3fgGkIhGKEv1q2ycUzKCDk/tSnwxk5lVFtRN/kL1k0Z+Qn
UVzjtBVdIN1YGV7ariObYFB9CqwBEuNfge18/DhdlzTkFrhH6DClilhv0gP2Evoe6AF/Rwa0n5LC
Pp4OAPMa+yGQSoQTMsmbr7BhD3CrqASQbilBwUGQ9yJGqkQyJV2gfevkmcsZtpXUFUMuy/nVkwFA
Q2kgc5s1KQox3MCYXfTWfljy7/ub/N8YDhosi8Fq0jbahgAH1N+/lKHV+8xkf7pY62137xYBuJKS
xQJweN2j88c1ZfWSS7dYxIcsM3uYXICjO47VyiD40UJBMPLQPzQ6BuclRcbq/XyLhmx6v339cC2z
tJBlGlrM09XfUN5IZUWpMphoQZSfyQ6y6B8XqcKrUybtVlFhpBia8D46u9DGIgPg3O6Nvb9ZHAsN
cKCHR6uuFVSX8ZKqrXgXdx0ZPu8tTXtB2tDAjkw8MhdbINLA/oxY+zAs+JDBd6rtI8EYzgdDWlA6
xmsYbmsok1PRLCFGew7chV1k8UBeqNBeDu5L67zBo0LWaiUiN7eTrcIwkumQDT1j5+MncwXLBPMv
o1XfbXVE817tjNasjAtK7H8Z+/DzAhC3JJz+n7LrhO4w5lEpeqmDCL2+ykE3t2IXEkdEnUEpjJhJ
aTA6xEcV2WDe8gt0INqQgjVf1Ze2PT6VQR9xOKfGgL0MRkINH6SB5WXYicI3pCqgVjbnN/g9kj3C
QBwgXjYfBHuEzmLS5LxeW1xNOSkg3gYZ0dfNO8LNH8e027QuZtVsFItAWoOeXR1Vd9i5wxMMavcs
u1mLN8mxy5yPO/Wfv7adZ8GL6g52lOEdMCU/U1B5YuQpHP/pS86krKcNgvKYuewlhiipXyysS6m/
39j55sgImAlgLEuK1qk3wi5+oYIt9eGedc7lP51zxb9GdnqTqlXIXsBS6B+BOdY+bySDDzhuMA6K
bhkS+IQhTipGkNOUbFnftYHC9Si66Eg7QnUBV1tRb22j2VB9CXT0CtEiZsWZ2gd5Sk3c5k2GK39Z
0rB7vMpj2rb31U4f1jFIAObxI/xlQsPRifxfrSqQPlVBeg8nFjgVayu9csKLyzGrhjrlnd1gL57T
fgCZ9qxMRKH30aI5ZKSoGV+0s7smC/DMiKO09ialk9xC7Jc5W6yc5r+BGpBPgI1gclNCGTgq9O2+
Q7n233/TkQvZ9sC0IdvzJhIZ9XZkUVytBaX4NPCU2R361PX3Y8E4NSnrNoxHY9XNDETVwWWYzNup
nm3JXdVbZptETnEyMsx0q20J+VNjYM+C5FRWAYEZz9na+MnFEPa8j6U9q2w8RSkR1MYZVnjIG1yh
3+K0LoBdGraNrghIhrpIOhItKgbTk+O2tsexCFFzAwIX9ag1y7G1BzOIjHcZG3DH0DMAsQ0PPF1P
zUYzGS3Kh1bcaOYdjq87r/UYq3Iqb8ykVEINVZ95FV8ItRFLVt1TOH4N3tbyAuJAaB2uL/UmIzaA
S6LIS78GFww/au0QMv/IhC8CAU0pm7AVayGGtnas5MIIedJWcJerD+m3J1mCgGuz/rJ+S4GhbCTZ
BxTQZ7qxrTEAKQMfGUrq9YQHTx3G7G3wZQsDvvQ0KKPAGyoggWw+9IVL/qail+EbmvGhvI5pWriO
zaIg2XaZcp1yKP9J8aXYw82X9DRG+nfLxGEL+udzS05Bvbq2R/Ndz8PqQ2q8/OrXMdItvhxzCcpb
nhH3m+nO/w0ZDwpvSCF3q9N5SmWAoM0azAXrWADjdJkkNJ3vQXNN++1a9kYI3PZck5N0aA3NRbPe
32URPUR4WNfvvv7bYaXEiPT8xGkfXkzPAQeTQuJCmR/qhpGh5fRs982i4eMpzRwVHNWhy9ABd+Zd
dkIOL+AugRGB26+96WdBVMdljyA7eqDkuvrRVtjD5z3e8yYqL9WEUDFPuScm+H85xSmqyYDMbK3l
UGBkZFy9f4LnN7mnoMP6FkBCCWSav4UKXIPdY2k30oX0HDUu036jyWDy77syGV+T2EHv78ZvqSAP
00Xf7WflHerkPYmPBw0/NZ0Pj06Hm9IEl4ZuwZcs7rSfqqcmwgS8c5qso07kKJCZ4JerVb4C3C+M
FS0Z9XtwYfjsa0NZwBkww/tpTSaJxGfvWCV7czkEBIJ7fGqBwM91o/x8+W5mhrRvI5FcO/QLKebD
0uQWpDcBW8JFozB9igqudieZz5Aw/Ws8E//oOcWcaXBj0Vc0PQIfVwMwxOWQaNNERGjHZwOpPc0a
nnZdD5aEORHW+Sxqbd/C6nSYB6ihzfFvkJwtUG/hiWAkkihAU17hnTNSPICh1Syd/2kgjWXS7qUO
QueQ0ZSSpMA+DUgbZidL2D7P0401TYJP90b5Xj8xym8/Rgp9mg4J/kuxUEHEjfbaQJdIExYp+yaD
5EPtFo0vgdtO2bkTtBG7HcHu5QnGQO/oz8PsjOBWLP0bckNbjFLeoyCtSJqrCyKL39hTMxG9qpjN
UAutDP8J8Llj1U9j+J+nVtVPefsdoQdEeoohO5JOhuIZFma6qQeaD4xYKa8bI4v2wrxIyIuPzRD2
HrYY+hzTtdt/Stq0PC80Rt82kSy1hR2eqQKUy1tD3ztTJ7P0Iidv9P3z9k24fpyx7ep8JnBCHnDZ
DLsonTHPOszxgS9mepA6U+lxm+e1PGk46w0g+UbFOpqk1WZqf0+v7dzAEkzKRG7NzrLusfJemfXp
rc89xYxUqYecJHWrSsXSeoFf7n0I+TLHKYfH5ABdIOiwOEWBc2OX4ZYt+RLFiWIsLJvQefQmfwq+
kd+5vDRhX4cN9mMvWF68UWpAFTwe9iD+/fQRmICLgIGieifwGa/MQdIO/s+VFtpLi1QapKbecmTv
Z24oGEMW2ythIETUz6uYcVvv2KRNk8Ws6yhFjZaWSI+joUFAUX0kkXv5MCWCAjeaxuSTRO3zQCHW
KnankRkPh1MdtZyI9h8lUyiTmDNvs+eFLGPA8HqDw4Vqv+Tnr1Bb5EfuFZYeOOlMurTL5rdft1kd
y3OHOwS+149Ac4JQgKP4ddQrHtaxD7BfpuNILT8CUEJGf/Qnmrq7a76GLHJtQJJaxUJ6TR8JMWg0
XSOeb6RjceiTsmO5KTAIoPmACkvgxACSBBelbPEdEaAxImr/vv8wqlzR4FvDgWGYvBFOG+rPzQbU
L8WKNXYL42yhBahsPkA0axJ4aw4oXUfR775hzxNztAtwg2pnS3hxcYZDJ6QWQTQE7imjSO/STWhs
3B2jVlpRMTRU5VyYLDbRPdN3wQLLs4gUX97PRlOM0yG4JTJWJB6P7Ii2jSHqjEAN4k4MKo71MUdL
D/gmQV0wKl/u0q4E+5pmirI3uLDysybaXHcxPYg6dGmmz04zlshY+6zQ/boeK93oaWd/XKLXHBH3
De7GPPnekQehn2F9YWMgtjEeNQmQh4cDeGjHkMES8OPSdWr662CYU2G4pKvptwPXReNIUbxaC5RI
gROGUxqYjdnaFNEu4JiVqwtvB73RwzXuk99AWQW6dprc8ouJXmfGqIe8qzJrUzoDZVD2ggsqnSqV
VpUhK24MwyTgVfUSm5hLXbdTQoawgUiNlegIAdwdxbMzIoVbnfaO+C91zEbnqDH1H+/SjeF9WmC/
xmnodTuEYnPsDFtNW9grs1JRcxMDDzALI6sgyFStqPNyHSPunh7RlQ2rtD0KQXiEWaXcY0l+y9I8
R1M1XDUWiEMaa2eaCS8gqmsqofLDD2HGlHEE5bTLuaBeqkpbDgHoKi2s4nDNGiDA+2aYObeVA3Aj
Gm6QPxm2z/dIMHoq1RsKlrmw/9mBYKMhh/bAZ2VVGW02dYCI85ci2ezTbDmjPIqJsWKi9tKKW4II
5ihLcrWxN9cZkkBcPVpYY2HCoKn6dvtBI+tYN6wO9DIMY02G4YiAsKbWOisY2fAreR5L5FMKfF4g
gWzdc8Hf1gfEdADzVMaIkju8OLjrlzlmEYYP6R6a4BpukUGZKc0=