<?php
$lang->testcase->importCase    = 'Case import';
