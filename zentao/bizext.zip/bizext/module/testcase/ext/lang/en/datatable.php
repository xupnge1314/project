<?php
$lang->testcase->lastRunner    = 'Run';
$lang->testcase->lastRunDate   = 'Time';
$lang->testcase->lastRunResult = 'Result';
$lang->testcase->assignedTo    = 'Assign';
