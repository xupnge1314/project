<?php
$lang->testcase->lastRunner    = '执行人';
$lang->testcase->lastRunDate   = '执行时间';
$lang->testcase->lastRunResult = '结果';
$lang->testcase->assignedTo    = '指派给';
