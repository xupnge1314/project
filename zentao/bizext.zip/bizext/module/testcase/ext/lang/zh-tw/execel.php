<?php
$lang->testcase->importCase    = '用例導入';
