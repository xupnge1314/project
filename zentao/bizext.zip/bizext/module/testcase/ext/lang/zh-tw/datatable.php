<?php
$lang->testcase->lastRunner    = '執行人';
$lang->testcase->lastRunDate   = '執行時間';
$lang->testcase->lastRunResult = '結果';
$lang->testcase->assignedTo    = '指派給';
