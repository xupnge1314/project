<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPvoYuyIaWjZh2H5svrfyL8UWRO88d/EWVycM98EQVAskltgC29BfKsWcFzHd9GtfIK+r5RVc
XO+EvGdXWj+9kJ0QA3swnfVe0w9SsD8jee3el34vf4qCCHc/UqqBSJ9R3QqjK8a715FJfQfFS2AU
wfzITn9cOY/Oer0LC1vXKjIqnfucxlXhTVXB8G0mQ9GwPn3MMfQmoCAPvTICKnQ4t3KgzwApTG4V
EmjU60RiPn8ObccPnHizlx5goEXjlhvwkfsN2bqxGAcwravjqigwEj8JsKqr/B/iddLDwmw30AgR
gYg6BCCZOoYiBSdN/WosAxjN/ATG5+ClTN0CnehSiO7F0SDYpusovXq7Q+jHHmNHzaxOoBJhvrQ/
0v8PYxnTI6grmooHC6+B5qwr6sKzeU2308hBT20levGKx2hYrjjcT29vVFlrsJwvRuI38mivQ+tB
GRfjS29w49OFo86DEg50aDEjkhBQnd4HtZCpTTdAfvrid2yGuaApO7+9ZdzloSZodRWOuuXXI6+A
pwvPRCjRA9lF19dEiDJ8qns5RSVVTRQ552WVXxiI4/fbcLdbUH8Q1foUgBcZEKlPyBIvrxBLYF5a
8ADg5FwHV6hM4ESDBCw4TdeVnT8D8lArZ9uf1RxT85QImOlUX3WV37w8XOodBH1s8a+aaFF6C0Ot
JiZiwJXwkEPGr9hju80w6UorZ5P7b/w71D0pZfDZ4mDwWk8bdrj8V60zX0WB3ueFwC0e/uS6Dcjv
WzPuZf8um7Las/u1RZSgwIAtNO9XJdNoby05kPGVg+FQTFfejrl+JEV3xZ8zDCEiOKUVssOeWcGc
QJhoQzJYtfKRWnazDFOwCLYi3+54G9Q0XGwV40w0CmPereLCpmhyDWluB8+A9mAMSdBaQa2ZxxXV
0FToPKKBcUGo2wsl7EUXJ+3GgpKrGjK004kS0nUrbGB4wD2p+Dvw6Hg9N3LeVYSHHV1m6BcfI10I
yN5GcE7UpOUNVI27roqmLsPWgOjlCuxi4xKbxA80YGYDZOGshB8i2m7fDWIxY6XyupSHV556hPeo
mFhhKWnvW9t8GoQhPnjxkW3HaZHhU5//w58AvLKzicB1RHlaLhKE9h42Xi7r9VghF/kTHfFB+aJ7
x2uNf5uNY9g5gD0FR0JDFdER2J7TA2vDBCSVl7SiPewOhhAHEslegvmEVikOFvGY0d07i1NexFdp
N8TN10nojW3Rb3b5d4BDLeXXGtdHCb03UBT2ZgA1hqBqAViUhRzv0rL4hTLdpkqkBvSCIC+KbtTg
/XTVosxLMrkxiSjv89rqSNo0ftkjwCP6kEmDXvGvJ2uiPHf3vQhGVhU1GkPjsua1v4kYQ3imXV2h
08qlOPtVaxfT6nlDXTpLl925YXmsjvGkjVHUMhCCWd1Co0Tgf/4vFMsx2klYMS9iy/dODHV7HbJX
YC4fll+Y2BeYzuHvymcNyrZHQvKm3+Uz0K0jG13EqdKxFNIlrxawKeIUPTResOXCtB26+sTGEFFT
NV9ln8oVe4ux13+tPzjDZ3VDHkp9UrfmLt6f+eVq916+rdoM4dzBUHhdWtRK7NLd3n8LEoSXXaAP
VInC04WQWlxnOgu0v+s/KMRmOtbLlvoHNoHCW1pkXom9xtvX1b1/O89ETvhNQXABctWznaj5zTtD
Z5juAXgree14zNKpPLoQ6lrXtn5h46W6tVPiOA9rUdoK2YtRQBJJnJr09kFaQREWcHmTAyApVtFZ
jfbu6x7vmHDCN83xkAtmxIyKKGz3ttQbwpru/qbGyI2VZHmZvzuJCYtZPU81oFkRS2fIiZUmHTbP
6/tW99F07YNAxO5CC2OhMD6MlsehkDZ3zqUhoUujzSff9pIHQPIZXijnP9G/rSMZHEUQovWr1nqP
iyHgfsWY2AZUvWUhHAqXS1dB8Npvu1IjpRksydxRdCbYUGVwbKzpZUfnMN0pqhHsDiTwieIPBeaT
hKhucQWA7Tj+d0awDE6rwNILK5tJMTlV1ab8sNtW/pfCDFv9bn7ovvmKzoM+qXWa3FMODR6y5OCC
XWVoO0qPamGN9pFCKXrrlcSNsop58J12czQv0eW1e0HWItDlYVR+Qqi/Aj6stEh17QCs1495t33x
PEEtdXFN1PRz5rJxO896IUx+nMnm+anarW6oxD4+77RFdONaWD7+Bbu1E7dAwctLoAfoll+G+D25
Uv9n2FrjptX3y7IALyxf97gnPDGnRGEUJh4Ab41xeEixrit4Y/xmZpZEe3z+ArzVzJ9MtSWoyO9h
M9vozVm1kq5EIG9g69n5hxLvs2jz6Z8qwhzGj8rwoHByKzo5L6lQiq9ZLo5dfiv35vkIpvewRDeJ
LIHFTtN+DZYkOVcSgn8vEvnCfRzONmlhjRu9yCjBDpwexr91/rSSyzCs4Or0nIPYDncqdcjEDHhI
gdYLcrpkwipOdly/ZiZ/Gsxn4wKIkuEGTsq3fYjYJ2t5+vrpLm63cvu5yLwvf/uB2oDNucnfqnVd
UtXNLj5WFyTKl4yHE5kjqe+8Yl2CyoYERX2r8dnAyZyS4IK0i2CxNEIaMZ4ZO6Altr0RRGajUuUt
8gmqNpHxCIdxC51SfQE2VeovPsemU1Tw/w6NyqRV03ZzWZUu3zjexWG836rMre4/rh3CxxAEnuAL
993bOlrPuN0wPTrvEipqOVmCr7rnGgJI2vyBq6+dLcfbm7+c1LxoKkVCWt6Rp71K+4aNyOYMCK8S
nQF98RUhts3orUDahj/2A5v/40j7mEaiTEIqxyAbbSJ3J0yL/cfjTR7b/cr8pyU5/Hi47VIwozIu
LgzO5vIvP51ENO+Di1Dk3i3bMbLU/6JswWyDpolveCBWBltMsFbZBVzQ19oj9XPA+TJR2SFqp6Jl
loMIu4q9w6IkbUXvNvnoDbyrgvaDFcuRi7WhRaxS1fbzlLvulDK320BPVoX8UggDiL2u