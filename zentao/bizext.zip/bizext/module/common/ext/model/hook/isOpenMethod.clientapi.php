<?php
if($module == 'api' and $method == 'mobilegetlist') return true;
if($module == 'api' and $method == 'mobilegetinfo') return true;
if($module == 'api' and $method == 'mobilegetuser') return true;
if($module == 'api' and $method == 'mobilegetusers') return true;
if($module == 'api' and $method == 'mobilegethistory') return true;
if($module == 'api' and $method == 'mobilecomment') return true;
