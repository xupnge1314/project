<?php
$lang->admin->menu->buildIndex = array('link' => '重建索引|search|buildindex|');

$lang->searchObjects['all'] = '全部';

$lang->searchTips = '';
$lang->searchAB   = '搜索';
