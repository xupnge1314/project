<?php
$lang->project->menu->task['alias'] .= ',kanban,printkanban';

$lang->project->kanban = 'kanban';
