<?php
$lang->my->effort = '我的日志';
