<?php
$lang->my->effort = 'My efforts';
