<?php

//函数入口
$lang->kevinlogin->common		 = 'KEVIN';
$lang->kevinlogin->defaultpwd	 = '默认密码';
$lang->kevinlogin->delete		 = '删除密码';
$lang->kevinlogin->userLock		 = '锁定用户';
$lang->kevinlogin->unlock		 = "解锁用户";
$lang->kevinlogin->managepriv	 = "权限管理";
$lang->kevinlogin->lockedTemp		 = "临时被锁定。";
$lang->kevinlogin->lockedLong		 = "长期被锁定。";
$lang->kevinlogin->lockedNone		 = "激活的用户。";

//界面翻译
$lang->kevinlogin->confirmLock	 = "您确定锁定该用户吗？";
$lang->kevinlogin->confirmUnlock = "您确定解除该用户的锁定状态吗？";
