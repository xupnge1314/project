<?php
include (dirname(__FILE__) . '/samelang.php');
