<?php
//kevinlogin
$lang->resource->kevinlogin = new stdclass();
$lang->resource->kevinlogin->defaultpwd = 'defaultpwd';
$lang->resource->kevinlogin->delete = 'delete';
$lang->resource->kevinlogin->userLock = 'userLock';
$lang->resource->kevinlogin->unlock = 'unlock';
$lang->resource->kevinlogin->managepriv = 'managepriv';

$lang->kevinlogin->methodOrder[5] = 'defaultpwd';
$lang->kevinlogin->methodOrder[10] = 'delete';
$lang->kevinlogin->methodOrder[15] = 'userLock';
$lang->kevinlogin->methodOrder[20] = 'unlock';
$lang->kevinlogin->methodOrder[25] = 'managepriv';