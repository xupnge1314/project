$(document).ready(function()
{
    $('#zerocaseTab').addClass('active');
});
