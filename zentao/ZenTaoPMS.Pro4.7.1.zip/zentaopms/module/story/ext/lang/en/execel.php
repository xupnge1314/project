<?php
$lang->story->importCase    = 'Story import';
$lang->story->import        = 'Import';
$lang->story->exportTemplet = 'Exprot templet';
$lang->story->showImport    = 'Show import content';

$lang->story->new    = 'New';

$lang->story->num = 'The number of stories';
