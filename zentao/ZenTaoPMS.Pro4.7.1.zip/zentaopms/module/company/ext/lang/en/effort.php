<?php
if(!isset($lang->company->effort))$lang->company->effort = new stdclass();
$lang->company->effort->common        = 'Effort';
$lang->company->effort->selectDate    = 'Date';
$lang->company->effort->projectSelect = $lang->projectCommon;
$lang->company->effort->productSelect = $lang->productCommon;
$lang->company->effort->userSelect    = 'User';
$lang->company->effort->timeStat      = 'The total estimate %01.1f hours';

$lang->company->companyEffort = 'Company effort';
