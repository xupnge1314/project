<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPp6cu45mZTbsjH1rOkdoSgZr4A9yBMgKca2k2qSFCNyUfTbLnrWHRPee/pfgc1d65vt4BU0J
/huE844tkbzcThMG72FtRBsnSaV0EOmCgwMkjzz1FlyVWeX8hrXH6I/AiFonrNoLNtm6vPsdBOpq
j3IlzpqHWTTjjn5NcDWTDvnl6cM1SuzNKenbFHROKvxLrZHvfJPhx9VTnXSziGsbH3PwWujVpCHi
JGnfAob+RvOOoBVnvBj8dY3YzdaW4gMZFPky6PqhO5Ek3XPc6F7uc8Q0FIfkuESEAcCBjCYJpnpr
gxZ0f71Mpp/l4TrCX2o2cV7CHUN2LoXoqG9z18w17VWHeELCKu9DQfhhR8a6fMLrtSKBr4QhKiyZ
EKHvHecYG5ToPJQmH4588TCxkHWq1dZAJALej0/8y8NY4+8QWreYDnXHjgcnSuFv1juxx08i+I8n
WA/W6hzRBN7bGNOEBhGFsfX1UCejAIWwhRL5Lto4nF/tevQe0BH9HDrc4kNOVSytg23uSCV5wZxS
X1pf+/06rNsYlZw5Nh2SxbaK5uRr10W8MtO6lkW02FRPqVSiN6xfpVnbRQBuAKv3SFLESKcaG7k6
9GN8veyHlv3Rj6jZko5LUg2DrCngbNOUUnnSLI72LZySDdTCNPvnMLAyKDVroLI9jKCsMspMhO+p
y+H4hEAlik9jrkYt7RKtlbDcA3k7fDXLjpkzuGoc0r3A2voVuDnSwhAp8YzIPXDfNMWmPPz5ZJvS
ZZPy22r0kD7woSGzrZ3qLtChlwsxwKe66uWTJix+qeQUn0F8eNr2no5BqRNK4UpW2se7YiWQhzia
xiYRxIBTGb4pB4d8CXlUreFVDGvR5lgp+1VP5PSe5PlVhv9cTgD7101Il6vYKBP0jKeiKOrjZs1Z
urtlYLP5U9xKdi/HsgsbVhUCQk6FvBLHlX/J7BwmbwNqbaW8WXgYWy25B4jVmw7jJpCIxZIlzGbd
NsMKbL99hcZGUXa3CDYUbOg2SDBRg1kUOdI/fI+RVwwBjeiuYIB4ip6dG26QEorowlnmFoLo0jwx
c4aSdg3beYCGCzbbYLoSSGFbzi4qwrcPEKOI1LsK1QF9acOfSDjXSevJkzH52AnNrNjjovXfCl+J
gcI7lURWWu2t3Zy3y/D82xXtPYGNSaIsabgKcUgSwEU6R8ngMirKGaWr3lB3YzQgg8qFu1wsGUnv
z69kdAF9BT2WI2PdgY2qG/DYUJjWyV8TyDV0ixl7LjiAeGwtsa7SOW==