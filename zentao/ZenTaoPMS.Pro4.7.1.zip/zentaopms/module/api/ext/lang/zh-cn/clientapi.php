<?php
$lang->api->failLogin    = '登录超时，请需要重新登录！';
$lang->api->failNoFind   = '没有该条记录。';
$lang->api->failDeleted  = '该记录已经删除';
$lang->api->failComment  = '备注内容不能为空';
