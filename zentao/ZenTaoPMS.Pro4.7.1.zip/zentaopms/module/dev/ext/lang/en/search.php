<?php
$lang->dev->tableList['searchdict']  = 'Search dict';
$lang->dev->tableList['searchindex'] = 'Search index';
