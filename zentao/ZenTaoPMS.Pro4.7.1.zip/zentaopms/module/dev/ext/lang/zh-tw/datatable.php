<?php
$lang->dev->tableList['datatable'] = '數據表格';
