<?php
$lang->dev->tableList['repo']        = '代碼';
$lang->dev->tableList['repohistory'] = '版本歷史';
$lang->dev->tableList['repofiles']   = '代碼檔案';

$lang->dev->groupList['repo'] = '代碼';
