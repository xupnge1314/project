<?php
$lang->dev->tableList['relationoftasks'] = '任務關係';
