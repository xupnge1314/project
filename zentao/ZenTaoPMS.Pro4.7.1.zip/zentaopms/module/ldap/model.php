<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPp8BD+7/gTMBre6ueiAKBtkY7xHamJ/PWUMKdrq9HkEEN2veIGmwGi0MfZM0CwH6Ac6ztyoW
ThOCHHQubjqoCgjKstNXXZ5xQmYcIaBOFkTn1VP4lWER9B335F6beQPNNvZemwMgtbY+tqTQ3S7u
NWYgvD/iQL2xuPqE/lgU6iFw0Z/NYJRQMou96hSnEpgc2DuurMRTuLJqegqU9Pe97xaIyevZZY5y
9/FC87tMpQ9hVEKZIwXmD9DwSQrWwnJwcRgvJgGgl6mBs0X1myNiTo9kEQehCmOkBjUK77fOJCu7
wPR4/GAuAAr6Cf+v3nfobpFmfeeDpNzie18Zf8vwI20WDKcpXRVjZRzyhWQbPNNTnGlKHgjIpoCv
H7bOYhyopr33E7/0q5pPBy6rPVz++aSLWV+oPeP/grrV7qhH/k7Wovu2GQ6KdQudujfwX3LXsJMc
D/jvSCbxL9VPnEWRDOxWj0sUzfjKBYXuEuNM2BtQQMLtoMMt6OpQvG5TsaioZ4oqNW3gfh9R8lL2
bT/HjHuOJOJNm/zHpIYiAbj2A/QrvUeC38fyaa0utmF+IsqCsUBCDZWW+wzq3JiYPFlXLFFMaMpj
LiVi1UPyT8qPYCsJKIpPGvnRVF/1aEk9QhhWBm646QE2NtI8tSFw4jeFRnqGaVKO6CC3Yqc/IRY7
VwVGOAr8MvglQ7YRCD03GPSr28VLYDvViwef4sePBaF9f3AS6B70nO9aDZB3i094/r0q8AAvH6j5
+y6q4Q8ohodMjLWKFTTW/Beqg6vW/oj6vcL29pcMylAlIfVeaGtEC/msYXI/483skQ7/Zi3qL74J
2An2fYSpVXBiuiicOhZ1m1N/xVxAFb1k7C1jbUjnIXZxjg0zw0MIPcwn7a69/o8SvqAJFjRK4bsO
urKMO0AQdhzvdU0wEUB7p/cvmke4sbABgHPKjTlzSeoyGXlaiuLwfl2xbBhS/QKUBveFmysUQUpk
3DJ83Z6BrXVREJO1tZ9RhSksJkhIUIeupwA5TocclxNaQeArjigtIJImmzRfygaDCvF6M+SnzuxP
U19Pzk14JZuLa0tqMBMifuUc4nB/iOnE9xjIq6evniTHJm/OL/ueXyQ7Bjlc0H8wh38sClhyJcRF
qecAQG8Ts1dvFSFER9RWygFR1I8rmXJ2YqyBlAxbMYyieIGzEpRPSBP+PtTRe+hGp158eT3KI9Yk
aUNIvGliqXEZRa5Y7nqSiDYGpoYGXcTveQSQQycEa515WdVjM9aXYKZ3Ycc/UpxV9isR4EnDINbc
4Miz1kMXIHdFwnTjBbaJJqd/5oikYmRgdpNSzqbItRRnZWr4i0S2UIc4bXxwbMr0TXgE6yVLZBsL
BSFVX7i5yE7ewP2auztXVBuBeYx81e0Obcc+xZqp0wcb2/6VhdFl3BR5e7LBuHznGlz9dUAPSNeY
2jGkTaFpUlYvBEkksMEOqIKm3yxOJuzHj86lLcKi4iqaMoem2sGxC+K9cke6+DxI0XAc5xoVvl5b
T1Hdfmz5RmtEtOgLLEKCOOWWJeAtT7p+vhgucktC4nUy1CQOO4oORny6oUQfMxLBB47RmS8Phxjf
iawclIpW/jA/z0cHzdMm5B0qMysPwerWpTUrlYDdIxgYjnpIst9r5HZ+ws+yHxT61FR9ZZ6b+3X8
xNMU0n0IPhB2T74SXtjwI3tkXtS8inxjpmUkzaqH434k7KXi9sKx+FpOfU0Tk0ndR7uxBKNKSNY6
hpkpSM25BUn/6/mRW7zjTEdL+0Su/uyMji7VuwSg+kWAQ7v9O0mW6CyqG1hYCC0GzGQ+1f/dJndT
Gl6cZTRT93PU4hwb375kriy9v5/FRYYGSQ2IBATDy5x5CrqPUz+YOYoC9sPNbfx57qdmYK7Cbsw/
4JKBlnUdqRz0rGQEP/HIlU6iuzmP1/svojW4qK70YOiEMLfd8OACkNNXbfxoyizB0wBhYiZuxARm
WHR90WgXe/FH/XntmVSrlW4M7ytFdAKN+qvvcEoKg2PB3zdINueqy+O99p9fHn9+xFQo8vaYm4ph
QxgIkxVA6pW6yDmaSaFCWEpUck5X/5/qC0MUNPCWIYQFKlxqEN7WxZ5OxuPk8mQBmn8PNygtNURb
NcbxsbeaFN5ko2p8NtIJxiQ9SfAMAZHwCK+jiMo+rkj0+aTB9RMion1mVS1Xb6jbTpDKEysnXSfj
88ntMFrHm0pWNl4E0PqVWvBsYZDYiELLCqWjzP0NddCaeUwGMiL/C8OemdrWH+80h+7xVXRouXfu
H0tMEQPXTzdN0b3eZ44BIwFvTypbcLO3QgXGVHeOpBZ0R64po9CoBrGOnpXivusDp+of+DNoc9nw
o5QAU3j6sx/nGGqMDnGkmvpYT34wrKK73swdgfGA21y68SW7ESQBmSuAaIU7fReM2NLUeZ0NmLgs
DhrxJtra6Y/QGu8ZcLZh9nbo8+VZes+LmaKMFVyxjnIiQ9iLLOLBOqtLBNxuZ+Xo/FY6nb/O74Fb
+WxPe51bkiJlQL5uqw08LzAXbLwseMmIeUqLOZ/MeOK7RfDjg6J6+Gdea/1upKqc6ItcUJuOJxut
KbsG7mgt79WpHiYmuhB13lMqoy/4/EL9pUWZPkL+XHAbUzW1R9MeHvaOZ7sK4bP994aEKO8BJ893
xC8CgcnFSLX19+ErttXa7vE3kW+oAwQT5+EqkPPI7jv7TpkGwC76l1LaQofOyRs0rhWfmkHXqde0
9Y4ldtpRFGABCn2QgFDKJpwNOVKrs2DdId82EULc2Ak160M/Asq7QKOpYMZ+/79nwtQ6E9cP+qGR
7KCSOYFefgFae59fNcMZesHSrmlf+ZgZso3XkuPYc+uzPs1JrkjgQjbDAUP5RPWrGvWJi9PbJiB3
IWW0/ggxNR0SMvEO9RbdUGlzxS5yOk3Bxh4Y3O+HLhFPm8lD7hRtziJd/OQMpU25mfKkxYfN9Kvw
8A8SPa8tKBJLRa/8W3SSuzNnunXsNfIbzy/OAm==