<?php
$config->misc->key2 = 'value2';
