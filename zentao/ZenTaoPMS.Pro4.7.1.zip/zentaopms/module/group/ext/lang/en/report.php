<?php
$lang->resource->report->testcase    = 'testcase';
$lang->resource->report->build       = 'build';
$lang->resource->report->workSummary = 'workSummary';
$lang->resource->report->roadmap     = 'roadmap';
$lang->resource->report->bugSummary  = 'bugSummary';
