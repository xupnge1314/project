<?php
$lang->resource->search->index      = 'index';
$lang->resource->search->buildIndex = 'buildIndex';
