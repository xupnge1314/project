<?php
$lang->admin->license       = 'License';
$lang->admin->uploadLicense = 'Replace License';

$lang->admin->licenseInfo['alllife'] = 'All Life';
$lang->admin->licenseInfo['nouser']  = 'No Limit';

$lang->admin->property = new stdclass();
$lang->admin->property->companyName = 'Company name';
$lang->admin->property->startDate   = 'Start date';
$lang->admin->property->expireDate  = 'Expire Date';
$lang->admin->property->user        = 'User';
$lang->admin->property->ip          = 'IP';
$lang->admin->property->mac         = 'MAC';
$lang->admin->property->domain      = 'Domain';

$lang->admin->notWritable = '<code>%s</code> can not writable, modify permissions and refresh.';
