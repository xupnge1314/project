<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPovO2mvIf8yXa+kUBTQ5P71y/UwBq+GHAi0Opb/F+/btnrzHl2JhmOOxPs2PGju0eYu9/BVq
D7Hxdiq9b3FZPqnXGsff5JRGJK+nZK24K2qHhNKY1RR+nd4Yvzc4JDM2mw4K8bhr3VYtCVms6blF
jogkpmH8XUW1ZbhkmM/LbWAxi96p7VTHpaSJBx3WpHOn8zDveBvj4lSzP2LW021nEl4PUBnp/U4u
+FzfmKpcX2mthqHa0va4Qja76moSgQmH8MPytKDBwyMDOcGC6R7/5ZWsVD92oSiANer5JAmCGbMr
TocBu57NgCqTrr2UBzEMppCLnfev+vqSkZ51EyqfXnmNCgiXOkAYUEGTZOi6fMLrtSKBr4QhKiyZ
EKHvv8Q7cuCWk9B3XFt9iSYyjMB6GseClOhidZNnwmoVcf/tvRIILlkGusHK51Ay85gk0UsSVV9u
ChGhD5UtTLDxszek0WDxTmRucLKzSIisPsl3hrL+pZ3rT9inujVSkmpnHxmlJ1xqSbYNog3+jx7f
P7g1k3AkquhCOL/bhAagcsYTpRCrQ3QPkX1zTHd+XZv/hItp375lzgMtlBc4PBPL8bwxKXHod1tO
xbNc9kcbBchMIZf1nS8hxQEtbw2yxz/7IDz9yYqzgt/Nrf+ND8Uskq11Tzl8E3M8WaGcE6k87sdv
rc3Mw8oU5O+m4SLTk0YmsRo02/P0MFKTDdjqCkAPlgM0KrCg+BodNILgRBdx8bqhw4+K78Mkdrvs
1P7RmlI/pMyvo9Sh2Yw3f9n/3zoUA7R96vCvry/DzfvFuBdVofCHXZUf3giLsSISTp1bBELcAaCa
k+ls7icZdeIgkCCv37D+zDawxWN2Stoe01G2e61p1zIdmjKj/J4kBkq5u3R2sz21Iwoo32Itj85p
ASZsxaecRT6QgcySl5ird7mgIUhHuOujlqnCuuH6MfH0dod5Nd9Hb6XITyP+AJ9s4hZ77BTpZZx7
OBwN/vae3E9QSzsdtuqWNhh676fAr3XsS9H0XbjrRPKVd2gA/K8lw+B37TiTMAq5a1Bf3urydS7K
KoL2xA7gwV7WCEuCsKQZsOjcx5KDkdRmGkmZlOun3gox4mE7r/Qt4NkwGdYHaQbdm/BVZBdbciBI
TMXM9G5qqTBmq7CekIGzXEKNu7D+LPHqaE3pSraEbhPSfn/Qg/hwC0JhfbNQWB0oklckgAmfxFF+
6F9tz3Yx5zLJuW7z674W/hKUvyjJx2MjMbo/WrSjNs6dBHgAferpfjOwhdhxrCPW0fwrsV+Z2DhM
WRKRNMxbJ+ezVWsbSUmHsP+NgzMxiVYp2NamntDm/TrNjbEE1oBRb0VrDjRSoJraVsyFxBoTXxqO
XFjtfBEzZVZxZO7OyGtbXOSBS2pPWSxbahdAq90JGA0OhCY8rhp11uBLMxJ7sLboDEfjWCZU1n0b
iOAXh2mEsm7/GHLlReD9rEnHJv92RunEqGW0tsRtgYLWgC3I97s8wiNMfyE+CSTGy6j/HRUBxrBn
E+iHWa1k71GrDO0r0WKpblscJ65ZterLNX1FqiuLEF9SvnRjui5NaraasxXG62BMxqcs3tbuJizp
3hdXYXTqT7ZMGfHjpuD00hH+1LrHq5S+XA/Vajb5ISaWVHtQLfsZBHiEE5kTCemJkzzKQuJ8Mv1a
tBJ1K7pS4VDqa3Du4GzwNRi1kx3TRfhUgMk7b/f5CZgITiGnDZQArE+F27EFEXaTeXB06UujbrY/
zJ8NlWFom3gcmx0MmE6jokNfl8GR4UeFMO2tLKbVRZiD2iwMPQf42ogYEjNK73EB1rXlxWEddaqG
1E/r6hqUDTcMfgZbBJybsdMpQFCGbLRk0Pm6V8Giofp+DYdvHP/OFlr64veY+hXmqMg5qoMaKjW7
jbYfkTh4BqS9iOuSZnwqyP/oKJRwal27R7euT13D+BQd2UPz86VacYY+OKiXw/Z1SVgCAUrCRJY1
62RuDEXWeaRZvttQg7F4RGR019Xul/4C9fpZzsnh0thg5adwguKtL45eCUiuoMKf/dv2Dy98VehL
qEgORwGcBIaM0Sq/zh0Wi2USGFP/EZ8MVki573BXsWoxJS6N8kwfPz9B9+JYpYvRE9H7JXB12HJ+
JYT8nB+sJRWGwW1qYj5hwO/5bfyj4AV345cmwJKrLi8dY5zczdgDJLSEed7wQzGDonJXBLNT6OXW
ZogbZEA5Uk0TRKlfLtf+rf0mOEaIs0IfL2nm+yoWIpW+i+R9aGGItDgEFIq0Qz6MPCPkVNXQGNvA
Op/XUOd98wQR1WCaIaLF9DEZugYDj5mAEQ452BVv2gYhCdBf+9lCl54uSUZQfmuahq80rhWLwLMu
sVV3NyuL8TgvXE3/3cpvS+2Z60eNN32Pz5LVWWOOqrGgsiX00wnLLA1tOqunDKMlAMfsXSFBx38G
HFY+5DLnmnTS6PyKilyk610+IGn/YrHf5P/Us46X5itmzVk4YzASbLeNIL3GvogyaPHh7zw1CLoJ
aPYjrF8b8liEwV3csCNblDES99OZvBnaXeYZDFH12N3qGtNAAv6xaUoG/GZ07OJUzouYxR5bQN2F
3zkFiuyDnpVOZSen3fFRR5tNj3cH6gTCxM0iuTt43xjkroQ2DeNYkSoXrG6hEygkkGQEg2NfiEYB
8Xh1u6WANSEkxAo0i/+moL6MagTZ/v58BP8G2MxPjmrhXDtXMIlMHGorcOdKsCiI2m0wHHwCvjVF
mY7SFcC5Um6AzG0Y1DyVbQXVX/RKVYfR+Y7kitRkXlRZy4Kn767WEpy1bmXYS82wK1/LQBhE9WKO
GsXLHqvQAfrzBO4eO9Nw7izlZWg6E/bHPX4VtJQbT7EmCYmHxyTiUdKCS8PhML1mk8fU8rc+hByB
7Jifnsa+UwyOWOego1O5eyiWZBGn8WuqHK6r+Wv3MnfwZsTEytuWGSxlHQn28pvfoANZGHhtOu9L
o3xrz0gBzb1mkp7y8R8Zonu4