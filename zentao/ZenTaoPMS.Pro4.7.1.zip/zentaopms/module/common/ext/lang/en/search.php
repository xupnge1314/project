<?php
$lang->admin->menu->buildIndex = array('link' => 'Build index|search|buildindex|');

$lang->searchObjects['all'] = 'All';

$lang->searchTips = '';
$lang->searchAB   = 'Search';
