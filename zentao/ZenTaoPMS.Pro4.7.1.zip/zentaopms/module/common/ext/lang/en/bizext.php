<?php
$lang->proVersion   = "";
$lang->donate       = '';
$lang->try          = ' try';
$lang->proName      = 'Pro';
$lang->expireDate   = "Expire Date : %s";
$lang->forever      = "Forever";
$lang->unlimited    = "Unlimited";
$lang->licensedUser = "Authorized: %s";

$lang->noticeLimited = "<div style='float:left;color:red' id='userLimited'>The authorized has exceeded. Please contact : 4006-8899-23, or delete users.</div>"; 

$lang->admin->menu->license = 'License|admin|license';
