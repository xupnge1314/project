<?php
$lang->report->menu->custom = array('link' => '自定義|report|browsereport', 'alias' => 'custom');
$lang->report->menu->create = array('link' => '新增報表|report|custom', 'alias' => 'custom', 'float' => 'right');
