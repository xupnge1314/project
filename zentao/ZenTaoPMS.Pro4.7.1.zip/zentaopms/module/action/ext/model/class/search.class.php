<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPzuXM1oteQ1JzktDFmlSW0ij9MYAg25LAlSlAn8RfKpv8TPhZLHV7+DVTqZG8+vxVrrjwcS2
8sidZXBU/nSY2XgBcJY5vZXsO12MEuJWhshgyuwCmllF0B2OtNVr8lnDoWkRNYCmSUAKvKvyhN8V
+6eTxG46z9v2/dz9jGFbvK9X2wX/uIR2/W6WhfFGXcaQogAfwVPM3KZgWkx53tygEsbPCtyoM20v
Sb9FoLP2gM4xdLrPByUcq1WN64wPdSk1jFlktjyxeJ9qwloBYiwmy5i9wXsBluhluvVoYYMPfqCg
4Q4iwvVGWVTaw1c9FayJPkoIR7lUMaRiI3QcTKa3jb2sO6522WOv/YKHq/fiFWQbPNNTnGlKHgjI
poCvH7a0Yo1c8V2NzSvaf5OHh3QvDKU7BXUfnR6/1rnGaQzka59vlYHTBzSZYNNaCC3bL0m0Jurj
lhA80omgEoXtdGA/feqYO7pR0XRxe6JT5fTspHnmlwVPtVNbevMYFxTEHFGlkHAK+ZSDz911w6Sq
Gc2qafoKNk4oU7jqQEbXtU1wihIh7f2TqLD1GPXr/B2s3p/tygtLMzII5YjfZ0e9xCddXOMVHPvR
ZiOnYh6x3jpNrdRiXAbt8evTWMLeJiPkabMk3jfVRpEOc7gTKmfhjkJRb2nq1/6wbRCkR3hO32un
dEaKqjNc+IB8InChwgnPCtBWiAWC7JiRRoD5k82nhm5W622bpwk4r+WesFE9OO7vFkmc37zZ/vNm
1n1VOXwyxM4BgABlaxvqQIGiehJ5OWLdyWrltrhdnR681AWEiuNrxKH9rMtmHjdLwjRZIj8hvyx8
0gO7rYk2WkFCs0eWGLCrjcfmlJBUzUfW6hy+0qckOe7TXWc+3qucVYums+n+f+X5C37V6PcHy7PN
vy7dcFVFZ6TaCKarCE5HP/hQT7zgpIODs5+shmC6EJtm746DHZXaC1sneylgBcwkVL6ouEh6znOW
d0uQo+h3p6AImS6R6uwJvUQO08B7mR6m2JdM9eKz6zNjK4hrS0xcr0c0ipEU+bscgF1mrkLxVBeg
TWn8KRtytjy2brc84JLYudhoa8TWt0w5cG3/+nCb+RkHNfJpSyfyqbNOXL0kMWPLlg4cekObXqTR
GgBAnsEjuHzn+DR2mrKTTMr2bcQJQjwBJy96zoEkAjI5W8ewFeKohieulZM6ZU+3mQ9MRkc1mvt1
QZab5SSQd25au7uzdz3L8ChqrPpt4sgUdK2WMo4Hb/+qc3kRpdt2bP2uznRRk4fQA88+UZMIjC/P
chwCuc/bhzifKclDqAAKJY8cZWDQ9tnv9HQK+0ASG2SLlLxatWyF3NQ35gNc/6ZethDhwc61FxU7
jfysca0XZyKxREbCf2EU39MD3WtsfWUEFi+ZA60Dbfv8STPNP26WeQYdUNhre38hCgZw1shw1Fzu
0ELh6mub8yFPEwTqn23+vzvwSI1AMHVqIv55kCEiAVCmIXE0948xF/T0P5ByAhKDMjpmFJbZRXyn
FbzXuQ+qIn6T8XRgsnNH8Dui5tTcAESYUI5QfFuG6Wpa5UlnfpsK8L7prchG+ST6tZW0yv307bNz
1PgzAixItY+8LsgNxm9LNnNmzP94bHFuOJfVmueYDl9cyzBB+RUhxk+QbsENfg6HPaBjmiFiafPa
Zgor66IqLobowgBnU8WXndrFYywLFRhmcON89yqHpIa2WwKuSw2NP/vyu0ID9oI0WHGrj6sNnUS+
X1iRbGZdON3EXgyjANPCT8Cs3YyUPY+S3+yU/+yuQDXzzcWD5Kh4Yuuu2cVolBRXY0kzmLzjf0K+
qb/CFeK+69OXtjhpniUN4VEvnbf75Wv1e5iRgUgV4rVV4NRmoIwlpr1yw5VCzSy94XwmnoT9+ZEq
4z7c3AldiGc593NxoK+ULHrMJ8oIHKExNPL2MTJLwKUWjBVRB5EbSAz8t3ZsC3zHNNQckGvKfQVN
Zgw1WFzMzaQEbQHYs4QBEoPbf0KthegZiLK1dvwSjoLFaUo4mQItiENnEDJhuiya3tbDmodfOshp
I2qUD6+fy23e1vcOLTmG0rhL0trkONWq8obVqOnav/KPX3DTl5ni25TWcXtOLyReJUs2lsE2gJrY
mPVRG0OqvAzYsCRT+0whaSqzR5CCRK3t/Q+4+gVM+gMhO6kfRKY4caIQAssj+AKqVtECVROFyKN8
hpQxZYWBw9dNRyjfpcR+o7BCeJaT7+A1KFRCmCMqv5OcQSZzuSC367oTnmESudxUBhU7GyZDaD/X
h/Ju3pMjltHKtDUBLAk1UG/wQ7C71rHYZNbQHg7IWx6sD3fWHybDCB54LAMj9i8AhUuvhC3hZoM9
7INmXu0l3qkDINbQsKIS1NpA5JascarV1Zf/xTFoOXbzPOiEhEvOmi7mRsBEN4OF7kKHCt2bmRoU
vZ6m5/CgueCoq1e4ljdW+Cu1OQ6+p3s3vwQsOVLoG40vcwvwN+7pER2mytzsrIha71FoR0A09Wma
F+Pl88Is4o5nRT9GFSRplysR8xx4ECwXb8MQIYTK/1+jHcvTJkpuWAmIlbYpP+gnhXTE3yWsl+bU
6F67fB7ghqi4wPgspHrLeEEFhYWNM9SlrMWqZTun1F6ADprS250YYZdXy+BVdgVY9YcsCCNuj6iM
zIuceW6ORzMClhKHTS+L5aBaGB/i5IFOOGbd6bHPCF/0MdmA+LiAfVYBpIk7RbkinB+tRAqwWZgi
ZSHqzF1r2qNQYPynBH/8RTrZ1BSese1Xg8k9C5TA93sXuTyzfN2QCpeUVMDI34id4dZGq1ZNaxYr
gcCW3MHVCzVuUp+RaBm0OpS5cpbAeuJmlVEGDNyrdkG1XOfO5aep/CCzRgbbIFuklbbwSnYeM4qT
ffy31Sl9A81Pq6wLu/AjnOeFi206fQQsJCNbIAEscpGi0miNlzlt/qa3vqVjiPMmJm/0IS/Vfyhf
XpyznPgZw0vKqLWnpqXhSGeGeN9lUAFxXTLN1ja3bC6ehjINrI5GfhlhMMcQPxxyIvpREq+IrH6R
CW5i2aa3Wfz/jyx292koHweYNHlgypgygPdBEyBLTkatuovntrPShWLq1ZeXfhMQUY+oAZNpKACr
IxU2H044fLyOTw9afEL11hsoB4Nd+TX1X5JbFxjhciEFgFu0srx/urUxu9bLHEo+gDNriqGzi4Uc
hEdO/rb1WACbRdbRp3DNrzL4utMt2VkOZlxx6sNBJyjoe4YS6NlAEhaJrJ2qwij5dAXbV1HlO2Q3
q6+eVhT4sM9SMbje/SqrtGgUYiTcH4u6cju59GZ22d1pMUr4ovUfxMymxsLBf8hP5U4oFpymDk42
+DToK7FxxrRnTqHxsdxx/+4bCjxTgEIfS2Rr8SOdH3vTQCnnAFMz2h0Nooc5L5w6TaWFZr4q+h6d
x69dutkmQ+YF0MgO8Dg5q3Vl6cZWv6Fa/riMns4j/8PDOC9YKuNLgbS8eRn2pU9cik6Dre9sOCTJ
UvSOXFZcZa4CEmOaBhZ+ukArL9hxrW==