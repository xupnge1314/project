<?php
$lang->action->desc->repocreated  = '$date, created by <strong>$actor</strong>: $extra.' . "\n";
$lang->action->label->repocreated = "created";
