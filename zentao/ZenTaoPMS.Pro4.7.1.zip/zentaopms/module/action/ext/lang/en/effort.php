<?php
$lang->action->objectTypes['effort'] = "Effort";
$lang->action->label->effort = 'Effort|effort|view|effortID=%s';
