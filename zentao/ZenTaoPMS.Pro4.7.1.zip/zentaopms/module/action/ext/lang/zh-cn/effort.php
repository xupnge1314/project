<?php
$lang->action->objectTypes['effort'] = "日志";
$lang->action->label->effort = '日志|effort|view|effortID=%s';
