<?php
$lang->action->desc->repocreated  = '$date, 由 <strong>$actor</strong> 评审创建：$extra。' . "\n";
$lang->action->label->repocreated = "创建评审";
