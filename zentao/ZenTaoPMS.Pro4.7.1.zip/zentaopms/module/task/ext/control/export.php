<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cP//m7CbgTCmnJRdJN4d5pLEClBkHQcFffDH54DcRjrsUl34UQR6tdJ+448gfvPfCHVnxAHVA
zWnQqfHn57ZhImEp7adJFjq1xAiHow17LaTICOlmsGoKVZg6Mt9n3rREjxfQIEoHuH8DzBqWlu6g
YLCbfHx2bLUEHaQ9Ep5UOe+UQfyVtC6yncCXf/5EGaszGSTIlkw8l8c9BhQtD90kAvMZNoJgpsy1
GDaCoEXo1WM2IVCqPqL4Pz4wU1IfQLQ2J7S08IB0ZuGm3KBD+kzEdJgQD/zrdlFtV7EmYuaEz0Kr
UljBkE0PydXTU4O5ra3no/87lNC4NbO/tkPbFiROrQmIlM+vi2Al5BuGRWQbPNNTnGlKHgjIpoCv
H7cpYXWPV9JreaXWpfR9DKkvCITpegkXMvYz8MnCcjGG48bLrin1JaiLYLKfccE/dDJ5yuK1k2mi
dKQHEnX6vz3ytj/Tkf4gvZW3bBlLa5Yju0PvuTHWi3e+zhgoKw3XqZG92/8525eE6EWAh6g5tCN7
q54DHXj1lP151c/aPyrA6IiEqfZk20DhgJI8xdECwvK/1pemlo71ZdAqDGr81UWzU4zGz9ZrWT2A
GIi9O9U1hwDwHL5v3+2660UpaNBmOpOkqzytLQKAjsuWHf3Xa24cOOI3Rq1+EKiF6gW5yjSJ+sZL
TUrSlDOlFam7nSVvRqmemBCw+s82Fpf6WGLngM5zOMzgSQRh0Rjqeo/49SNpaXmlhV728cnsfm0a
/tMAFKrXNmN4n0IuuKhk/tc2sO5emkDLQwErWHbFTanl0yBpDuv7p9DHZ0O5dzilPTjJvCjUXLF6
1aEtPCZ/jofYBTYHleA9RSVcbaNOteZsbS9O7gvaZGSmiI99QN5OZjnrj8VEMRpYVeSBCIsM4wfJ
2noaZa0TrtUZDvJBSmYcvM4UBCS4+svbbytpT1j8Z5YStmHB2uo7ufjhKg5s66JQkViuAZlkRTM9
6spulmeFSoc6970rAsOih4AHetQEKq/ExYqdPI2ZxLYjCC4VSvGoNsg2SOil18NKnZVDXjadN0Gn
HicPbr/mVSz6izDUkeMfRxphrRYO0ORLXQgY3H06DX2J/D83a95n+DHPcROFKkmLlq9xJlMzP0P0
MV3oh45NTlan/dFAKb7NYA4PmgCVglYfkvhpxk5Hzq37i6UxCcNhEa1Ecflw9NwMHkWTi44bh18u
n1GHTkfc7Ri9G4dOXuKA3C+xinSnsujBhajurnPTluzIqvR015RgglbTc3PuhYHgg43EsGqOKar1
UjoKKYc6eQWJ7bVb5s23HldPzF3PsevEcEG5fkZsRCh3mdzOKnQBpTVCusyNoE8H4oBm5api2XBF
M4p5ed16dh4i7PwBudE4n8s7UDF/Fr9vblK1wvr4KyiTZdp5DF9RA5EYAILq7mRY5/rXpoudiPfz
4F0HRPYQexQaOV8czDPtxvrgVyfS/Q4rjUw7bNCtXVvsmOBYYQDz8OcEwh3jveImKoMJaQRKUDbd
sumHo2u1lPENZBX2RSaaOjTYPW/ly/ArJpNmFm237+KtvxFIYY4+IbHmkPI3XntsTFEzp0ov35C3
B7PlQEOM3tMOj7Pj7quadz5CwXsY5gcGFoAEmjiS2C5ehxJx0jkQETYSKusOMsRyJSzT1XkUDPvU
wlDWYQppEcaYit8gwAMxEUd64jxbx9sCUF3GwjGXjs88xnNi6g3OztE2EWScLR+9wW3X7xOOFVtw
59ygJdG83DhWJBbdGgkdGF8pzbT9u4xLyKVrZiHxLJaHUPDSxUKpXVYvYI4HIjKazh7owUiDLDz0
t8cJ3BaoKKEhVxICWQprv9c1zcM2s90sO39PyHQvPQh+xvuXzV4XIjjkZGjtPIoGhHc5TWOvaDon
4jX5LE3SGTrpjfVdL2QTW9IbNCD1q21AzLoOL28PG2pGEQtav+wcBygOOieJbJ5oT3gDWn/vFnGw
au0hIg2w/vULIQb86v+LLxWAXnl9HBsXyhPmWNq5RbE37ewmu+b1kEueDq1WNO5ukZ0lKEZ4c7/S
DWtc08eOWxxTCcl68gntITqEJlSTgyJgawJ1D2ngcnf+Gl/JxWAgi9D24MUEp9nn8H64E9l59ujP
FXgLkMwdXOcwNaBrVufVslw7bxbEvXnmj3fY+CP9W0zpFpiGkFd3aOL2qRC1RlwhfbdKy5ofZ4oj
Kyb5j3rrh5eQreUtev7ejfBfXU4EnCbdYPRZ+B0wWH5lQQ9RBX7GFOyspS5pTgMH8lbkOKpuBne9
vmzeiHDeOQWV4XO087BA9SkbHzbXSjiOAHkw1zOM67jV+f5XYGSZEBePNLycPLD9iLg3tfElvgxw
R0jZxmwNdfWLiDALRfm3Pa1mTUZwTN8kiOCkwEtEvpwroD/EI66ky0penX1flUHztdZiX/NqWzxJ
feZ4Myo9MVWuPs8LxWvOP29aYBrvaJiRbEhzaH62uoq9BEq95CiNJYj2NlzZOUYRVqq89nFJDYCY
jo26ZNug16JQIu9+JrF3hSvrHWyNV0dqpyw2W+dIaWjKrq/t3YPPH4VDPl72KljgA+aWnnUtVUv5
DGLrjLOYVl4JkFnza0Sq0g4ZukQ6VzA6YW6UXJr+rVln7XmVSYEo6sEuOiXLJO63izPBWLeWpSvY
lfAwirWV8mxBAW6JAlzD5GgSc9fVNUUzlWdmLPDVb5u0hD2bRhr1l4JBYq0ivolJIcip/j8Vwlzc
nmH6bkAWha0zyRhodTCMdTxvq8r5eiSqyMaQBiImPLOQhY6QSFAViwFh0wIJBhWaZTmpqww7ZI+A
ZCora3GfwI+XdHuI5yHNXdOxrlvyi5eZ1e2C3d9Sy2qsHxy4aI/LfvlGzHVD30lwzxCp6uCMYFPW
+YaXfZwhi/Hf1PZ6hr/4fltcDFBvKWp/LORGt5yC/kMcSCL3CespacQktA4+vb3JQhWAkUdf9Y1h
ZCsZ7xBUlhD3MrRzUsXHScYtxQGML5OBRFT2cod4kdmSk6Cobqy5ARt6D0ccQy81+YKmz6rW2UQb
FI8vTWvjDIlSCiwjjsRgJIKaBwbzVgvMXGiGJd3w0cFDPmBqrF7G/CGdLwAdbUGuxfxrxt6CACM8
wcYnrrlyj+Ly2Hf5pO9U9CK6QYKS0LW3ffKoARsYARASXhxxoflIj7P+7IgCf/aWork0LTY30yUE
imwDzEesrSxIiheO64lCjXaflyNIL7KF4q6SY2kiW6em3PGBbP5dql+SJZaE5wFZN6Twa3NyLrrq
Ccn5EUoD/rqvD5bcI3r0RgJUcHExiNSIy2c789uAT+Icj6ve0nFZPhKsBpvse1tkjf45R0hctsLn
zCVhCMTKG3gRA7f+t4SwzNC7Lh7jcXbCSXd7e7HuHz2eh6PcN5qIxsWwDkNVGZjwpR9yDytsRcm3
GXmkP4vOPGR4Eh8N0tsRWrg2fHd8THjcbUZTuGd4rG/61U4vC06/Qk3wBantNYUUohC5IlQL+Ia4
pY//br3hL9Q+2Vl5+Jrf0jD5rq2KODXSJV+l8NJCW/e9XLInngxx3zqped/Nk0xyEg1/Beov94WA
U4m+ZsvUPuMN2+MCvjqpw2voKINGNbm0vzfJwQQcQuMhqj3rqABtq8FU0wDf6X7aYrBnWm6krnz4
HXuIcei0Be7uCj1SODb9vnUf2un0xC6B28oJ7rBEc615nq9JUU46aR6hia1uYYIFyQZHCXDPifhb
H0BTzUObYJ4S7YmF/6aS82cWeHzBK2eR578qcmwhHfr0CHZ+52eFxP9qu9CvH2ZC8x4W1GzLRXCn
k9S0ChSBV2GjvLTNN/hkQss2BmOBwTMCP6o+qRvUa7O8XHFujIhAIA/j4TafAnxUDANIPbe//vA8
ZS4cHRaTj0lQzbfXIa6wvCIz+3yrrdiKgPUxc59EtOdmOkuBzlxhTukUbze86D6HreXXfPKEW6mD
8qmtGy/pTwsd3k9qQOTCqOnNYwsSaOVKylgG32JTvoiqSmss1sg5rA3CKGtKpDU4AnyZ3bItxFbd
A2SjlBPesuHo0M0up1t2P/kXguKz1muYkJLeclu+praxubPj5WP7gqEDXqgf/zdMhIxb7hFC8Xfg
5EsCzH2d/kOiDrzehusEtn2knBIwrt2sALGt9H4LG5fsYjHQxAvqBMzB2rAVrgQJs5ot/8BVmipb
7Qi1MnSHBjo9xXs5Ad0L/V8bMFoHX5pyI1uCCDvWj8KLFZ0YOndhdWGN0Xsjbuz6H3/SDimwGBwI
iwAJ9yrijt26XRah82twM8JQJkmpc+rOEgXR9xMCbdicUcQVMq+bJ+fJifWh0IHe+vyQjwl/iKBQ
Pn5ajaog7Ye=