<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cP+0d2jO/fOuPVkYVzHaPBXOWjLbXUgBL8y1z2/KZhrPlHczA9jp8ugZdReebYcfvekaImfu0
GtsYTlHk4jw2CaGfXWL+qbAN+PYmpVPNTb8j239EXOlhkwlWLiXcn8uNKu64d+veJHbGSCSrcrUw
WWLalQQNzoBRHHwKYcWfFgTyK9c6IA4Xy0HGQ23n5wRcykQO/83McWIqWlXVAdGAYmXaOVuiZqwU
SLTVuaw5y5bo1ylGwT1ihlTFvri2ZDNW3g7K6MupcuAxFYDxHBlOwHEOOVCJq99YEO9GzCrqFzN+
El6Jj0c6Gro7HjVGyl7TUtCUkY/B74sNa/0Kbu+NJVARiizXIuK57NH/GGQbPNNTnGlKHgjIpoCv
H7czZECqraHuwvzs2gN9kKkv9tSK4NpApTP1Ozys3AneSO2hjF5VPOTD/8mSxtuz1vXvkPtxdsfU
CeymH3czynalX/m0rNG29eSq0FwnlfOUolEw/XpnwbbzXGsdPwh9if+p35sGa12DlAmaGIhdP1U4
/68vyiK3IlvinEMmVFzLbsP1tCYlY9JuxOS0Zm0DXWe9f020b01dBz8TLgUg+b+2tPcRUMFrjdnT
+/WSDFfMYUz/Sbfb+IiCjS/jfQAcvbgD2K68IMXr1Dtk/HToHqSKJzdhltzAn666ByA6JJxJN3wA
CyRXLteaKoY6kExhK9EH4vVznWVBt0uZWSzA6aRv9s4RTiEvmzt34dL4gH3VqGJWSWbiM4BC433e
iiM+EE3nG3bvuUaK855OGCyMejD17AVZ4laQk92M5ZsKoFwachIWf+euZhYxekLexYPSLA24i3JU
XQss9IIOq6UyLrT4mpaThfKj4Y6n+Q4vlcjx1WBvc6l7S6HsmI52yu8WfP1VC7gSdDe9/1CrypJZ
z94Vi7yUSweJwoCbW0x1WblNfBMWKKVEp90V+iRKvw3RegzjnCehEUVmwQo6paI+RnjWos1qdvOs
7jjEnCTpKj/oRisZsxzICBMviJkuXRKAyRN+l1435b0VKcuqE+t7P+YKKlVs3Dkfgvj5KHzGQhuX
IpVASGK8YxA+K3iRGBfWwLIzDEQ/L1hphW0m/t8bhhxgMT9uADc0JSBdJViv/9/HL6bkTu7MuGxM
TuHrT4TSMaXaFMm1yHmWrCnl5dkGNyjZ1UjjD5U0HBKxU0LCInlB3831KWTYoNuGr8FPuS8jPwMw
HxufKSFT7FT63TBF3A0h/I+XLkH2Q6M9CsMXLHvtupULmfhpzSQRmJqEGBjAw243/RlkPxhUlSnr
kgY7QCnFQw5V6iB+UrsmLPVQqCvAmBZxDbbBNI6eoDDZOp9oZ1xlkEwJYg3a3dVOdN+V0Kfl27YX
ODMkDuIY6HpwMi1cEVBKYPf5B4QhoaW9v03SkOO+hcAy2obSoq051Bt57NB7flTpUIwsRPmwL6Gv
KXJqL32vDl0HZS9nQ7ph0T8vREzUVP+oBijCLz9vG5WOlBxyRVFI/ISAJ7Km1kIokehfvb+D1tWs
XEjxbCRbXp1AoD8H0WRMzD+RL4JaMzpt81DsGP/qbhEPWljzqtrao1W5ijLe7SifLPgodiHVwLtE
7RlxYLJ7Dl5Nn+quafNTjhFxamwNiOxNRJUpUpOF0SuuRR7fujVj563sU9wRujfYaS76j0/eh+Rd
e/TApSuHVdqHTpMEYwLcxGBFd+pxjqmIdZS6UfJvlrC18o789zoR3mSmHpYVWWFxMGR+BAeC+uB4
cU/jwN1f+dlzRsasGJ7ytW7dS+oguMvJcVavg0UCFSu81dhtJWJSH4jIYTNTcE9L+vBxxXBsSsNi
rTXm/fAciPyspxSTOTofM4DK9IxJbseZo72UKZTgqRmfFsg9wu4K3yaXMzMXm77jaLeInCxl8bD8
5JsGtTeCvwUtHcm/m2/fTncnGydCgPl7eg67d2E25cMWH5dgVreHOZXz+uQAKdkxAsXTnd/ty9HN
AjPij4fIhWsVjOxgcgItKFuEWYdFfT3H5+o7vCpke0HjNg8IPr9c4P7LS69KI2yYGQSNZEr/xs9P
9TJy6lh0AHSmRBkvsmst6vxCV3kgEZcy3iPKa+2/QKN2YqzufW2yl08ZIY7SJ2leqIl/POJDimcI
WIu8tglbflilTOvLrF2yNaex7mAtGYxEr0TpHEpGbzs7zvys+8qZK/HxUKDfTnfjbPWpW0B2rqw5
wNMJ96Pc90RxZF7wMDvTe6trVXR7mYllvMIhduUS1Fw9yYEHUzrTee5004oCeNPH9sRkhJWuQgpA
M6guBhrcWcUifL2apsqmDBEtdaF/1c5Z47TOWgGwtsvOoJUwSBkgnJQNcf7yhzrbAfKWdR0dzr31
s5M14T+ojZNPTNyvmt2HbGg+uslFqEoXVlUZsU6bNVBftYviT01oGW5RbaT6jcJnoCVqAl5bbKSt
AW2Yyzsl8ZJ1L53a85GsRUDAyz8UJgPk7oJN3z0YSufCFxr9FvvkQj/eYHN/IRFwtAJGoTiwqM5L
ZhraYRVFqMjQg61xMv2AYowrbiGguGXPucasJkV8f+5xKsf7OjWVSMXuUtjKst7CrjIz+IMw5ijV
+ucezEW1uUj3Vs7dQikZQRVi4QZyQPEsYs6x6i04WDg73bpLAtB2RebVshHO39ZVO/TYzcQsAuBT
rmYijWBlxjsU1eA+P/1U/Tnh27Jx8C090QnbbYOq+M39Y1kAIE+KosklYD5oreDnTtEMRRFWiBlm
hPa/l0R4/Iv5pHXimTM5xB6+2q6dA0O9CATorO2WyOOPiF2NX0bCWxRJts7xM7Xk09QDPxkNO7FR
mBMBrJ+MG0+mJW5XDn1uSF//+L864DRZXWRqMLxcVigCwPKVc+kboqUMDoGfk9oZA5TU46JrLrYo
/xK1dVZE12fvc6u11IP8CP828wz9z6bp35q3PP+Z1z9SjF7zqkbY/uO/j34ZBHNXPtfogd/cZjbV
XlWpZ1dYDmk8FyAuwTOLg+2E1t9HY+dLO+pa7kHERJj952p2H5kI5nR7h1asUXGcUUogZxYmjE5R
u1LYpyUv2NIv9V1Bmqrrtm7iNPymXjfm8gAm2admzTmc4xW0czko+zl3Ka/ADKa+qjvtWbZQFNuZ
qGj3l744lUj4+sFbtR6093UkTjuMMwPuv7ITf8XSXiC6lMDvcFf3XZxLXoWYYWTS0ZB7Z5fFOO9U
Nn/kOLo2RY/TUg8SBSIUiFI05lIF0D/PnCAd0z0YR7NNLJbCQ3JBCJf23Nt3jJi2uMXpB/u1ZTvF
lsfrvUYZWgEHUp0ra3uV9jlWv8e1mK9BQ7Ck6/OY7mKZCFqz7/mRGh5Ed14aEvfudFTOuCG3MCgM
am6PC2eAhpkgMpLtDOBx3NHaVJt8YDOKiNwcEQau3FEdaFxSwhmQiNJNPkz7z5CZy5IUV30Rk91T
znEfsuHJx7ObwCsT/imG+0z1Twefs79BcxsqQOM7evo8hwCNFLtJVAQLf6RaUsw+6wBd0sBRQuWV
JIJnaW2hZNRCCOxD+RO1JzKL1XnvAogs2e/CmyaU3sPlB5eaHIMeYAOBTop45orn3A6B4qdl+8Kj
Ux0FeHZQWluhOsXeezHarcwuyDpi16TLPXqYFH9tOoOAlPz7NpWaJOQRXzvCkfrr5SWYdyfkprny
+lQMxj9VDOd0QiaaQABfZlBbzPyh9FDgqWhSTvpVB24Edr5xDcHCIhZ38xqid5eCh654EPW7QYG/
301HDHyCwcYCpayJpJjsb//oQmq6YRFNIL67vohkuu+zJq/t5QdYG5I/04N+X2DHEifRGiio2SXI
TR43eB1YmuoVyT4vEFzdpuDmLevx/bsGi0Q33nqBh2IwV5bhZ496Wgz4kUvoJu6tlST2HO3Uyevz
7lzOGKi2+aQ+UhlPIJcwS4rM7iR928pHBX1azKMc9GulHoK+y5N1KLapre0RXQSKEV1fD13NQfaC
6aeYOha1yJljcpveuXWsKFI8wBKbUXPiyR9MdkPQkktz9sXNnR2W1+GqBLwpWj772CGGkmunxeYS
f/GL307RlWfC2FvsAlaC9k9GkgjYU81dcKR2E6bZXVhcO2B+vlpcH0QpG7rZHzMQ6m2ePJVFDeHe
DC2ohOsv1U5Xdpvck+6gMaqDb/kf57uSZzUHwUzUDslfmHaHK0I5NahJzf1NpH/1sTFeyNOw2zU0
1vf6u/rGVD+OqRozxkQKPCsvd+q5rpKaoGv+iaalEy+Eaa39qpyg80+rAMgi0H4bX8ZSRlYIY5bp
q4QqyzdYWCaLGhaWEtPp4i4iu8jZe9nUINpqETWO3Vu9eCl325i=