<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPnnjhUPni1N9jDyunQRW1x2bfqRs2N19gk28Dq0Oh2qe+aYvnMGr5oodH0KA/+KhsGjvL7U6
p68mUWqXh1Nvq6WFTL1ibRyovG09UDElHkX9BXpFPBNOnaYg60tQolyt87BeJx1V1hiJe703CfBJ
M1tSv7WPu036Ej9as8hLlXnV3f5DuNE+RHpraKz/tqdOuqBdJiuPm/3/thcH0wOr0tNSfiyZebXL
+8XW7he1OM43QrSPobwEIuNxfomQIkjfcrpg6FUdpGUPKqfBfPmJ7VPlUFMJNnt2smdM5CFfRpNT
Ghox4PHGT4cs5Z4bNAGXlyHuMLiArZ4uxjemE+y2aJbTI7unucIsGvZx8Lq6fMLrtSKBr4QhKiyZ
EKHva8TH5nNA7tLV+1ldoS6VjqXUSnv2z4XBmWYKsCyC7U0TH3SswLk/cG3a2UNcSTCuJeb8WmBK
Nn1qpzc0aN7XFNgc+n2emud0cIb7Cq4Wa5aJna3K60AxWDH4HXSnuyi0N6LvaN8v3IEuxFB0f3IP
AuWcTQ1KC4cO5RXscQJU2Yvt5SGhOCW+OBbpdsP1G7FbzaXmQQbpzPztzD9HOuDYSBIjODqtSIfo
YjqKToCJ3mDejgTplS1JecihmFZaId0FxEWFV00AtcFgex5b44kxyAoUFxevIxT3Pl4LdOId7p6c
J5LDwszPCeWRppQzq6DAPd9+ayefzO/oV52CGbPCb2s6K3gzaDItBtKjQLV3y1HwD/JCMYo9pc6l
j0hBLnG03/kkUdbi0p8FUpc2QzcICRT8MgXyWaZAujeTxq7dLnH0dPh8QD8IwzfLIrXNLP4dhcBQ
MbEtndleJCxigjSTxWIV/CxPFVvQM0bd4SLNSgvLe7XOkJrxETc6PsQAaZiBEHLQ6JHuQpO83sL+
3MY2Okdesix1n61xup49zabn4cbWH+sjEjBgk/TGRpx4i0pIHI8lnxlgpx1cCggsVOIj2cvj9bCI
BqFvBUTQHd7q6in35b4PXrzZD6h13B8BD7S4TNYDTQdmOnjqQ2TAxo2s13y93qfU8oBCMM2DVnu+
dDAGP3eBlBCBFzA3RT9OU7OvwMBmZk1VQ1Ke/zNFONawPu7rvXJI6O54Hg9f9zIb5c7u5U5OdgwY
s2Z3jWBRcfP0ZK447YpTpubb5PC9ocVHysm9M1GI/gAoNWFNX7t8XDLX9EU4OlnJdko8Vp7Uehyg
XiAuAxMmqtxFIXRiobCcFPcAw6dk31uId7JLCf8HeUAWYSkeD02BrjnSD8BkjfM+y0b6+hicqACF
EXJmf25Wz2i7Lh/xPgzjgnEmzr7fFmOWjSqKWKQGhL0eZYc0k0tveZ9CUkL8anrsDYbiPBs4WPht
9OoO9baiKUm0wiKud2kGXThZb5aW+iqtGlLSfEKt9aCnjNhXtd4Ax8KubyF01pHEVYOoQwbZUden
/sEqnXTiVfD7zdFxlch/OFwRGQmsluEffY8rTZ5K3gBrA/nrr0y55actTP9thFb0wfhaT12ahODM
HzMNgFXWFGba+CeEbB4KlDMqTA9UShcJHrKR0fsamRQDh7MayVDsOoKo5Ye794+yINxYBeyYq2Ub
u0KX+AT6Gs2KNpQ/mgtGqSzGyqunnYrw/7CIcf9OYBz1IyFeubRkho4sUkYx6Q/l6EeFCw3X8wiF
+O7xezKsvugRI4AZdhJkCL7TrXjD0sF+qFbsgsDdzezGjP6eyaIxEJheYc2u31wU5Y+W7eDk1bhN
9tgV0QM9TnSKm7SHmyoQ2/ydzFvfoZORfLm/kwCn185x7FyMgVQPDUEdzh+aTy0/6w5p9qa7Jd1Q
akdWdR4nIMOFrwJOBjCWqRCx6afQwEOZzNHoK5GFOsHXhJ6oI/0r2ydgPjk/KoNKaFDghJdEOIP/
467owPE+3WcUZqqYpd+zNQzsUGvBUoSFXTthDhNFf5ZEL8OGjczNCfB/SaptwqPIAU0F20qlhZQK
sBqmWiFgpTf3DTWfgZCMqVFBbTg54WQCQd0E8mFNmfyBpwCJ6zPRSnHe3DAPFr0a7axypQd6ozWo
YU1GMQ3C/9nwoe36B2ujEs99EBh+Ps8a560uR80dStS2yAF8VepqWnz3n6gmuW56t9wlaqkijus1
DpG7ybj5C/qEWhzXnDZO6UCelE9QvB2e9ZbFDrR7D6NA/jaUJ/pORa2WJq3+WHQmc6iBOIA9CxDM
heNmByiIIiC3wpf2wQRBDSW8517vbHw6WaY4g7pvyjgFXiCPXI++IBN3yBlbmDMmuLPmxbwmEnws
z6gbhhVo6kfx0cw4MHIXKxQhSVrR1hSrPzOrLDh/128qgiin5PlOb7GC3wrq/pce2x7QyCaB/Eme
lrGM43IYN49ia1cu2R+Vf9jBLdjjX4X/CGjkStEXO3BWq0VKHl0N+ojbgjm8padUcoNjuwbK+U/t
lzSpAMYZZOr2yaKkcQHjEt8tty+C2w2w+BYcKQrslOnh7yq9oH68bQZ0uShkxFZJiVhPOcFrqW1e
oO/YGc72NrwkNF7APx+WRjJI4UWGTj5oykG5ELrjzquENsBH2OF9WYF2MezD2tNmH9ucWDCblaYY
+Hp7DSAWWVaiLqrYzbdXUiJC2x1FhgjOj/9tO624tCCa/m/6IptJHf0wXzPKWM7eYUNy0yID88Cf
sjMtMQGZHCfk