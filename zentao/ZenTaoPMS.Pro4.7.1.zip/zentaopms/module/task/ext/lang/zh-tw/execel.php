<?php
$lang->task->importCase    = '導入任務';
$lang->task->import        = '導入Excel';
$lang->task->exportTemplet = '導出模板';
$lang->task->showImport    = '顯示導入內容';

$lang->task->new = '新增';

$lang->task->num = '任務記錄數：';
