<?php
$lang->task->importCase    = '导入任务';
$lang->task->import        = '导入Excel';
$lang->task->exportTemplet = '导出模板';
$lang->task->showImport    = '显示导入内容';

$lang->task->new = '新增';

$lang->task->num = '任务记录数：';
