<?php
$lang->task->importCase    = 'Task import';
$lang->task->import        = 'Import Excel';
$lang->task->exportTemplet = 'Exprot templet';
$lang->task->showImport    = 'Show import content';

$lang->task->new = 'new';

$lang->task->num = 'The number of tasks';
