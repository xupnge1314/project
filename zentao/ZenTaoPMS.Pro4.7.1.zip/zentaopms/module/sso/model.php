<?php
class ssoModel extends model
{
}
